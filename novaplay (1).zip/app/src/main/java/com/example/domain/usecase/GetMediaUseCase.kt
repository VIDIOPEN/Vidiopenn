package com.example.domain.usecase

import com.example.data.model.MediaEntity
import com.example.data.repository.MediaRepository
import kotlinx.coroutines.flow.Flow

class GetMediaUseCase(private val repository: MediaRepository) {
    operator fun invoke(): Flow<List<MediaEntity>> {
        return repository.allMedia
    }
}
