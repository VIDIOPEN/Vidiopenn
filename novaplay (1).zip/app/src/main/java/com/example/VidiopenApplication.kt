package com.example

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.example.di.AppContainer
import com.example.di.AppContainerImpl
import timber.log.Timber

class VidiopenApplication : Application(), ImageLoaderFactory {
    lateinit var container: AppContainer

    override fun onCreate() {
        super.onCreate()
        container = AppContainerImpl(this)
        
        // Initialize Timber logging
        Timber.plant(Timber.DebugTree())
        Timber.d("VidiopenApplication: Initialized successfully with manual DI and Timber")
    }

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .components {
                add(com.example.utils.VideoThumbnailFetcher.Factory(this@VidiopenApplication))
                add(VideoFrameDecoder.Factory())
            }
            .memoryCache {
                coil.memory.MemoryCache.Builder(this)
                    .maxSizePercent(0.20)
                    .build()
            }
            .diskCache {
                coil.disk.DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache"))
                    .maxSizeBytes(150L * 1024L * 1024L)
                    .build()
            }
            .allowRgb565(true)
            .crossfade(true)
            .build()
    }
}
