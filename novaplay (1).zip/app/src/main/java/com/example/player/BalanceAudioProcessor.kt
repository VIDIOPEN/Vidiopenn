package com.example.player

import androidx.annotation.OptIn
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import androidx.media3.common.audio.AudioProcessor.UnhandledAudioFormatException
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import java.nio.ByteOrder

@OptIn(UnstableApi::class)
class BalanceAudioProcessor : AudioProcessor {
    private var leftVolume = 1.0f
    private var rightVolume = 1.0f
    private var balanceValue = 0.0f
    private var pendingInputAudioFormat = AudioFormat.NOT_SET
    private var inputAudioFormat = AudioFormat.NOT_SET
    private var buffer = AudioProcessor.EMPTY_BUFFER
    private var outputBuffer = AudioProcessor.EMPTY_BUFFER
    private var inputEnded = false

    fun setBalance(balance: Float) {
        balanceValue = balance
        // balance ranges from -1.0f (full left) to 1.0f (full right)
        if (balance < 0) {
            leftVolume = 1.0f
            rightVolume = 1.0f + balance
        } else {
            leftVolume = 1.0f - balance
            rightVolume = 1.0f
        }
    }

    fun getBalance(): Float = balanceValue

    override fun configure(inputAudioFormat: AudioFormat): AudioFormat {
        if (inputAudioFormat.encoding != androidx.media3.common.C.ENCODING_PCM_16BIT) {
            throw UnhandledAudioFormatException(inputAudioFormat)
        }
        pendingInputAudioFormat = inputAudioFormat
        return if (inputAudioFormat.channelCount == 2) inputAudioFormat else AudioFormat.NOT_SET
    }

    override fun isActive(): Boolean {
        return pendingInputAudioFormat.channelCount == 2
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        if (!inputBuffer.hasRemaining()) return
        val position = inputBuffer.position()
        val limit = inputBuffer.limit()
        val size = limit - position
        
        if (buffer.capacity() < size) {
            buffer = ByteBuffer.allocateDirect(size).order(ByteOrder.nativeOrder())
        } else {
            buffer.clear()
        }

        // Process stereo 16-bit PCM audio samples
        while (inputBuffer.hasRemaining()) {
            if (inputBuffer.remaining() < 4) {
                // Not enough bytes for a full stereo sample, copy remaining
                while (inputBuffer.hasRemaining()) {
                    buffer.put(inputBuffer.get())
                }
                break
            }
            val leftSample = inputBuffer.getShort()
            val rightSample = inputBuffer.getShort()

            val processedLeft = (leftSample * leftVolume).toInt().coerceIn(-32768, 32767).toShort()
            val processedRight = (rightSample * rightVolume).toInt().coerceIn(-32768, 32767).toShort()

            buffer.putShort(processedLeft)
            buffer.putShort(processedRight)
        }
        buffer.flip()
        outputBuffer = buffer
    }

    override fun queueEndOfStream() {
        inputEnded = true
    }

    override fun getOutput(): ByteBuffer {
        val out = outputBuffer
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        return out
    }

    override fun isEnded(): Boolean {
        return inputEnded && outputBuffer == AudioProcessor.EMPTY_BUFFER
    }

    override fun flush() {
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        inputEnded = false
        inputAudioFormat = pendingInputAudioFormat
    }

    override fun reset() {
        flush()
        buffer = AudioProcessor.EMPTY_BUFFER
        pendingInputAudioFormat = AudioFormat.NOT_SET
        inputAudioFormat = AudioFormat.NOT_SET
    }
}
