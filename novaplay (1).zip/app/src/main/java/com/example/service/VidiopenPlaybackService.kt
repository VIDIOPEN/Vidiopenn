package com.example.service

import android.content.Context
import android.content.Intent
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.LibraryResult
import androidx.media3.session.SessionResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaLibraryService.MediaLibrarySession
import androidx.media3.session.MediaSession
import com.example.VidiopenApplication
import com.example.player.BalanceAudioProcessor
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import timber.log.Timber

@OptIn(UnstableApi::class)
class VidiopenPlaybackService : MediaLibraryService() {

    private var player: ExoPlayer? = null
    private var mediaSession: MediaLibrarySession? = null

    override fun onCreate() {
        super.onCreate()
        Timber.d("VidiopenPlaybackService: Created")

        val app = application as? VidiopenApplication
        val balanceAudioProcessor = app?.container?.balanceAudioProcessor

        // Initialize ExoPlayer with AudioAttributes and automatic focus handling
        val audioAttributes = androidx.media3.common.AudioAttributes.Builder()
            .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MUSIC)
            .setUsage(androidx.media3.common.C.USAGE_MEDIA)
            .build()

        // Configure renderers factory with custom balance audio processor
        val renderersFactory = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink? {
                return if (balanceAudioProcessor != null) {
                    DefaultAudioSink.Builder(context)
                        .setAudioProcessors(arrayOf(balanceAudioProcessor))
                        .build()
                } else {
                    super.buildAudioSink(context, enableFloatOutput, enableAudioTrackPlaybackParams)
                }
            }
        }

        player = ExoPlayer.Builder(this, renderersFactory)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()

        // Register listener for audio session changes to enable equalizer/bassboost/virtualizer
        val notifyAudioSession = {
            val sid = player?.audioSessionId ?: 0
            if (sid != 0) {
                val appInstance = application as? VidiopenApplication
                appInstance?.container?.musicPlayerManager?.onAudioSessionIdChanged(sid)
            }
        }

        player?.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                Timber.d("VidiopenPlaybackService: AudioSessionId changed to $audioSessionId")
                notifyAudioSession()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                notifyAudioSession()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                notifyAudioSession()
            }
        })

        notifyAudioSession()

        // Initialize MediaLibrarySession
        val callback = object : MediaLibrarySession.Callback {
            override fun onConnect(
                session: MediaSession,
                controller: MediaSession.ControllerInfo
            ): MediaSession.ConnectionResult {
                val connectionResult = super.onConnect(session, controller)
                val sessionCommands = connectionResult.availableSessionCommands.buildUpon()
                return MediaSession.ConnectionResult.accept(
                    sessionCommands.build(),
                    connectionResult.availablePlayerCommands
                )
            }

            override fun onPlayerCommandRequest(
                session: MediaSession,
                controller: MediaSession.ControllerInfo,
                playerCommand: Int
            ): Int {
                val p = session.player
                when (playerCommand) {
                    Player.COMMAND_PLAY_PAUSE -> {
                        if (p.isPlaying) {
                            p.pause()
                        } else {
                            if (p.playbackState == Player.STATE_ENDED || p.playbackState == Player.STATE_IDLE) {
                                if (p.mediaItemCount > 0) {
                                    p.prepare()
                                }
                            }
                            p.play()
                        }
                        return SessionResult.RESULT_SUCCESS
                    }
                    Player.COMMAND_SEEK_TO_NEXT, Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM -> {
                        if (p.hasNextMediaItem()) {
                            p.seekToNextMediaItem()
                        } else if (p.mediaItemCount > 0) {
                            p.seekTo(0, 0L)
                        }
                        p.prepare()
                        p.play()
                        return SessionResult.RESULT_SUCCESS
                    }
                    Player.COMMAND_SEEK_TO_PREVIOUS, Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM -> {
                        if (p.currentPosition > 3000L) {
                            p.seekTo(0L)
                        } else if (p.hasPreviousMediaItem()) {
                            p.seekToPreviousMediaItem()
                        } else if (p.mediaItemCount > 0) {
                            p.seekTo(p.mediaItemCount - 1, 0L)
                        }
                        p.prepare()
                        p.play()
                        return SessionResult.RESULT_SUCCESS
                    }
                }
                return super.onPlayerCommandRequest(session, controller, playerCommand)
            }

            override fun onGetLibraryRoot(
                session: MediaLibrarySession,
                browser: MediaSession.ControllerInfo,
                params: LibraryParams?
            ): ListenableFuture<LibraryResult<MediaItem>> {
                val rootItem = MediaItem.Builder()
                    .setMediaId("ROOT")
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setIsPlayable(false)
                            .setIsBrowsable(true)
                            .build()
                    )
                    .build()
                return Futures.immediateFuture(LibraryResult.ofItem(rootItem, params))
            }

            override fun onGetChildren(
                session: MediaLibrarySession,
                browser: MediaSession.ControllerInfo,
                parentId: String,
                page: Int,
                pageSize: Int,
                params: LibraryParams?
            ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> {
                val future = SettableFuture.create<LibraryResult<ImmutableList<MediaItem>>>()
                CoroutineScope(Dispatchers.Main).launch {
                    try {
                        val app = application as? VidiopenApplication
                        val musicRepository = app?.container?.musicRepository
                        if (parentId == "ROOT" && musicRepository != null) {
                            val songs = kotlinx.coroutines.withContext(Dispatchers.IO) {
                                musicRepository.scanAudio()
                            }
                            val items = songs.map { song ->
                                val metadata = MediaMetadata.Builder()
                                    .setTitle(song.title)
                                    .setArtist(song.artist)
                                    .setAlbumTitle(song.album)
                                    .setArtworkUri(if (song.artworkUri != null) android.net.Uri.parse(song.artworkUri) else null)
                                    .setIsPlayable(true)
                                    .setIsBrowsable(false)
                                    .build()

                                MediaItem.Builder()
                                    .setMediaId(song.id.toString())
                                    .setUri(android.net.Uri.parse(song.path))
                                    .setMediaMetadata(metadata)
                                    .build()
                            }
                            future.set(LibraryResult.ofItemList(ImmutableList.copyOf(items), params))
                        } else {
                            future.set(LibraryResult.ofItemList(ImmutableList.of(), params))
                        }
                    } catch (e: Exception) {
                        future.set(LibraryResult.ofItemList(ImmutableList.of(), params))
                    }
                }
                return future
            }

            override fun onPlaybackResumption(
                mediaSession: MediaSession,
                controller: MediaSession.ControllerInfo
            ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
                Timber.d("VidiopenPlaybackService: onPlaybackResumption requested")
                val future = SettableFuture.create<MediaSession.MediaItemsWithStartPosition>()
                CoroutineScope(Dispatchers.Main).launch {
                    try {
                        val app = application as? VidiopenApplication
                        val musicRepository = app?.container?.musicRepository

                        val prefs = getSharedPreferences("music_player_prefs", Context.MODE_PRIVATE)
                        val lastSongId = prefs.getLong("last_song_id", -1L)
                        val position = prefs.getLong("playback_position", 0L)
                        val queueIdsStr = prefs.getString("queue_ids", "") ?: ""

                        if (queueIdsStr.isNotEmpty() && musicRepository != null) {
                            val ids = queueIdsStr.split(",").mapNotNull { it.toLongOrNull() }
                            val allScannedSongs = kotlinx.coroutines.withContext(Dispatchers.IO) {
                                musicRepository.scanAudio()
                            }
                            val restoredSongs = ids.mapNotNull { id -> allScannedSongs.find { it.id == id } }
                            if (restoredSongs.isNotEmpty()) {
                                val mediaItems = restoredSongs.map { song ->
                                    val metadata = androidx.media3.common.MediaMetadata.Builder()
                                        .setTitle(song.title)
                                        .setArtist(song.artist)
                                        .setAlbumTitle(song.album)
                                        .setArtworkUri(if (song.artworkUri != null) android.net.Uri.parse(song.artworkUri) else null)
                                        .build()

                                    androidx.media3.common.MediaItem.Builder()
                                        .setMediaId(song.id.toString())
                                        .setUri(android.net.Uri.parse(song.path))
                                        .setMediaMetadata(metadata)
                                        .build()
                                }
                                val targetIndex = restoredSongs.indexOfFirst { it.id == lastSongId }
                                val startIndex = if (targetIndex != -1) targetIndex else 0
                                future.set(MediaSession.MediaItemsWithStartPosition(mediaItems, startIndex, position))
                                return@launch
                            }
                        }
                        future.set(MediaSession.MediaItemsWithStartPosition(emptyList(), 0, 0L))
                    } catch (e: Exception) {
                        Timber.e(e, "VidiopenPlaybackService: Error resuming playback")
                        future.set(MediaSession.MediaItemsWithStartPosition(emptyList(), 0, 0L))
                    }
                }
                return future
            }
        }

        player?.let {
            mediaSession = MediaLibrarySession.Builder(this, it, callback)
                .setId("VidiopenPlaybackServiceSession")
                .build()
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player != null && !player.playWhenReady) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        Timber.d("VidiopenPlaybackService: Destroying service and releasing player")
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}
