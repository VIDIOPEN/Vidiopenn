package com.example.service

import android.content.Context
import com.example.data.model.ActiveTransfer
import com.example.data.model.TransferFile
import com.example.data.model.TransferStatus
import com.example.utils.FileScannerUtil
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import timber.log.Timber
import java.io.*
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.util.*
import java.util.concurrent.ConcurrentHashMap

class WifiTransferServer(
    private val context: Context,
    private val port: Int = 8080,
    private val onConnectionRequest: (ip: String, code: String, onResponse: (Boolean) -> Unit) -> Unit,
    private val onTransferUpdated: (ActiveTransfer) -> Unit,
    private val onTransferSaved: (name: String, size: Long, isIncoming: Boolean, success: Boolean) -> Unit
) {
    private var serverSocket: ServerSocket? = null
    private val serverScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var isRunning = false

    var boundPort: Int = port
        private set

    val allowedIps = ConcurrentHashMap.newKeySet<String>()
    val pendingApprovals = ConcurrentHashMap<String, String>() // ip -> "pending" | "approved" | "rejected"
    private val activeSockets = ConcurrentHashMap<String, Socket>()
    private val cancelledTransfers = ConcurrentHashMap.newKeySet<String>()

    // Generate a temporary 4-digit session code
    val sessionCode = String.format("%04d", Random().nextInt(10000))

    fun start(): Int {
        if (isRunning) return boundPort

        var currentPort = port
        var socket: ServerSocket? = null
        while (currentPort <= port + 20) {
            try {
                socket = ServerSocket(currentPort)
                boundPort = currentPort
                break
            } catch (e: Exception) {
                currentPort++
            }
        }
        if (socket == null) {
            try {
                socket = ServerSocket(0)
                boundPort = socket.localPort
            } catch (e: Exception) {
                Timber.e(e, "Could not open server socket on any port")
                return 0
            }
        }
        serverSocket = socket
        isRunning = true

        serverScope.launch {
            try {
                Timber.d("WifiTransferServer started on port $boundPort, sessionCode: $sessionCode")
                while (isRunning) {
                    val clientSocket = serverSocket?.accept() ?: break
                    launch {
                        handleClient(clientSocket)
                    }
                }
            } catch (e: Exception) {
                Timber.e(e, "Error in server socket loop")
            } finally {
                isRunning = false
            }
        }
        return boundPort
    }

    fun stop() {
        isRunning = false
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            Timber.e(e, "Error closing server socket")
        }
        for (socket in activeSockets.values) {
            try {
                socket.close()
            } catch (e: Exception) {
                // ignore
            }
        }
        activeSockets.clear()
        serverScope.cancel()
    }

    fun cancelTransfer(id: String) {
        cancelledTransfers.add(id)
        // Close sockets to abort immediately
        activeSockets[id]?.close()
    }

    private fun readHeaderLine(input: InputStream): String? {
        val byteArrayOutputStream = ByteArrayOutputStream()
        var lastByte = -1
        while (true) {
            val b = input.read()
            if (b == -1) {
                if (byteArrayOutputStream.size() == 0) return null
                break
            }
            if (lastByte == 13 && b == 10) {
                val bytes = byteArrayOutputStream.toByteArray()
                return String(bytes, 0, bytes.size - 1, Charsets.UTF_8)
            }
            byteArrayOutputStream.write(b)
            lastByte = b
        }
        return String(byteArrayOutputStream.toByteArray(), Charsets.UTF_8)
    }

    private suspend fun handleClient(socket: Socket) {
        val clientIp = socket.inetAddress.hostAddress ?: ""
        try {
            socket.tcpNoDelay = true
            socket.receiveBufferSize = 1024 * 1024
            socket.sendBufferSize = 1024 * 1024
        } catch (e: Exception) {
            // ignore socket opt errors
        }
        val rawInput = BufferedInputStream(socket.inputStream, 1024 * 1024)
        val outputStream = BufferedOutputStream(socket.outputStream, 1024 * 1024)

        try {
            val requestLine = readHeaderLine(rawInput) ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return
            val method = parts[0]
            val fullPath = parts[1]

            // Handle HTTP OPTIONS preflight
            if (method == "OPTIONS") {
                val header = "HTTP/1.1 204 No Content\r\n" +
                        "Access-Control-Allow-Origin: *\r\n" +
                        "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n" +
                        "Access-Control-Allow-Headers: Content-Type, Range\r\n" +
                        "Connection: close\r\n\r\n"
                outputStream.write(header.toByteArray(Charsets.UTF_8))
                outputStream.flush()
                socket.close()
                return
            }

            // Parse simple query params
            val urlParts = fullPath.split("?")
            val path = urlParts[0]
            val queryParams = if (urlParts.size > 1) parseQueryParams(urlParts[1]) else emptyMap()

            // Read headers
            val headers = mutableMapOf<String, String>()
            var headerLine: String?
            while (readHeaderLine(rawInput).also { headerLine = it } != null) {
                if (headerLine!!.isEmpty()) break
                val index = headerLine!!.indexOf(":")
                if (index != -1) {
                    val key = headerLine!!.substring(0, index).trim().lowercase()
                    val value = headerLine!!.substring(index + 1).trim()
                    headers[key] = value
                }
            }

            // Check security for non-public paths
            val isPublic = path == "/" || path == "/api/auth" || path == "/api/auth/status" || path == "/api/info"
            if (!isPublic && !allowedIps.contains(clientIp)) {
                sendResponse(outputStream, "HTTP/1.1 401 Unauthorized", "application/json", "{\"error\":\"Unauthorized. Enter session code on the app first.\"}")
                socket.close()
                return
            }

            when {
                method == "GET" && path == "/api/info" -> {
                    val rawManufacturer = android.os.Build.MANUFACTURER ?: "Android"
                    val manufacturer = rawManufacturer.replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.getDefault()) else it.toString() }
                    val model = android.os.Build.MODEL ?: "Phone"
                    val deviceName = if (model.lowercase().contains(manufacturer.lowercase())) model else "$manufacturer $model"
                    val deviceId = "VDP-${kotlin.math.abs(deviceName.hashCode() + port) % 9000 + 1000}"
                    val json = "{\"name\":\"$deviceName\",\"model\":\"$model\",\"deviceId\":\"$deviceId\",\"code\":\"$sessionCode\",\"app\":\"vidiopen\"}"
                    sendResponse(outputStream, "HTTP/1.1 200 OK", "application/json", json)
                }
                method == "GET" && path == "/" -> {
                    sendResponse(outputStream, "HTTP/1.1 200 OK", "text/html; charset=utf-8", getHtmlContent())
                }
                method == "POST" && path == "/api/auth" -> {
                    val code = queryParams["code"] ?: ""
                    if (code == sessionCode) {
                        if (allowedIps.contains(clientIp)) {
                            sendResponse(outputStream, "HTTP/1.1 200 OK", "application/json", "{\"status\":\"approved\"}")
                        } else {
                            pendingApprovals[clientIp] = "pending"
                            onConnectionRequest(clientIp, code) { approved ->
                                if (approved) {
                                    allowedIps.add(clientIp)
                                    pendingApprovals[clientIp] = "approved"
                                } else {
                                    allowedIps.remove(clientIp)
                                    pendingApprovals[clientIp] = "rejected"
                                }
                            }
                            sendResponse(outputStream, "HTTP/1.1 200 OK", "application/json", "{\"status\":\"pending\"}")
                        }
                    } else {
                        sendResponse(outputStream, "HTTP/1.1 400 Bad Request", "application/json", "{\"status\":\"rejected\",\"error\":\"Invalid session code\"}")
                    }
                }
                method == "GET" && path == "/api/auth/status" -> {
                    val status = pendingApprovals[clientIp] ?: if (allowedIps.contains(clientIp)) "approved" else "pending"
                    sendResponse(outputStream, "HTTP/1.1 200 OK", "application/json", "{\"status\":\"$status\"}")
                }
                method == "GET" && path == "/api/files" -> {
                    val files = mutableListOf<TransferFile>()
                    files.addAll(FileScannerUtil.scanFiles(context, "VIDEO"))
                    files.addAll(FileScannerUtil.scanFiles(context, "PHOTO"))
                    files.addAll(FileScannerUtil.scanFiles(context, "MUSIC"))
                    files.addAll(FileScannerUtil.scanFiles(context, "DOCUMENT"))
                    files.addAll(FileScannerUtil.scanFiles(context, "APK"))

                    val json = buildFilesJson(files)
                    sendResponse(outputStream, "HTTP/1.1 200 OK", "application/json; charset=utf-8", json)
                }
                method == "GET" && path == "/api/download" -> {
                    val filePath = queryParams["path"]
                    if (filePath != null) {
                        val file = File(filePath)
                        if (file.exists() && file.isFile) {
                            streamFile(socket, outputStream, file, headers)
                        } else {
                            sendResponse(outputStream, "HTTP/1.1 404 Not Found", "application/json", "{\"error\":\"File not found\"}")
                        }
                    } else {
                        sendResponse(outputStream, "HTTP/1.1 400 Bad Request", "application/json", "{\"error\":\"Missing path parameter\"}")
                    }
                }
                method == "POST" && path == "/api/upload" -> {
                    val fileName = queryParams["filename"] ?: "uploaded_file_${System.currentTimeMillis()}"
                    val contentLength = headers["content-length"]?.toLongOrNull() ?: 0L
                    receiveFile(socket, rawInput, outputStream, fileName, contentLength)
                }
                else -> {
                    sendResponse(outputStream, "HTTP/1.1 404 Not Found", "text/plain", "Not Found")
                }
            }

        } catch (e: Exception) {
            Timber.e(e, "Error handling client request")
        } finally {
            try {
                socket.close()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    private fun parseQueryParams(query: String): Map<String, String> {
        val result = mutableMapOf<String, String>()
        val pairs = query.split("&")
        for (pair in pairs) {
            val idx = pair.indexOf("=")
            if (idx != -1) {
                result[URLDecoder.decode(pair.substring(0, idx), "UTF-8")] = URLDecoder.decode(pair.substring(idx + 1), "UTF-8")
            }
        }
        return result
    }

    private fun sendResponse(out: BufferedOutputStream, statusLine: String, contentType: String, body: String) {
        try {
            val bodyBytes = body.toByteArray(Charsets.UTF_8)
            val header = "$statusLine\r\n" +
                    "Content-Type: $contentType\r\n" +
                    "Content-Length: ${bodyBytes.size}\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Connection: close\r\n\r\n"
            out.write(header.toByteArray(Charsets.UTF_8))
            out.write(bodyBytes)
            out.flush()
        } catch (e: Exception) {
            Timber.e(e, "Error sending HTTP response")
        }
    }

    private fun streamFile(socket: Socket, out: BufferedOutputStream, file: File, headers: Map<String, String>) {
        val transferId = file.absolutePath
        activeSockets[transferId] = socket
        cancelledTransfers.remove(transferId)

        val totalSize = file.length()
        var startRange = 0L
        var endRange = totalSize - 1

        val rangeHeader = headers["range"] ?: headers["Range"]
        val isPartial = rangeHeader != null && rangeHeader.startsWith("bytes=")

        if (isPartial) {
            val rangeStr = rangeHeader!!.substring(6)
            val parts = rangeStr.split("-")
            if (parts.isNotEmpty() && parts[0].isNotEmpty()) {
                startRange = parts[0].toLongOrNull() ?: 0L
            }
            if (parts.size > 1 && parts[1].isNotEmpty()) {
                endRange = parts[1].toLongOrNull() ?: (totalSize - 1)
            }
        }

        val contentLength = endRange - startRange + 1
        val statusLine = if (isPartial) "HTTP/1.1 206 Partial Content" else "HTTP/1.1 200 OK"
        val contentRangeHeader = if (isPartial) "Content-Range: bytes $startRange-$endRange/$totalSize\r\n" else ""

        try {
            val header = "$statusLine\r\n" +
                    "Content-Type: application/octet-stream\r\n" +
                    "Content-Length: $contentLength\r\n" +
                    "Content-Disposition: attachment; filename=\"${file.name}\"\r\n" +
                    contentRangeHeader +
                    "Accept-Ranges: bytes\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Connection: keep-alive\r\n\r\n"
            out.write(header.toByteArray(Charsets.UTF_8))
            out.flush()

            val randomAccessFile = RandomAccessFile(file, "r")
            randomAccessFile.seek(startRange)

            val buffer = ByteArray(1024 * 1024)
            var bytesRead: Int
            var totalBytesSent = startRange
            var lastUpdate = System.currentTimeMillis()
            var lastBytes = startRange

            onTransferUpdated(
                ActiveTransfer(
                    id = transferId,
                    fileName = file.name,
                    fileSize = totalSize,
                    bytesTransferred = totalBytesSent,
                    isIncoming = false,
                    status = TransferStatus.IN_PROGRESS
                )
            )

            while (totalBytesSent <= endRange && !cancelledTransfers.contains(transferId)) {
                val bytesToRead = Math.min(buffer.size.toLong(), endRange - totalBytesSent + 1).toInt()
                bytesRead = randomAccessFile.read(buffer, 0, bytesToRead)
                if (bytesRead == -1) break

                out.write(buffer, 0, bytesRead)
                totalBytesSent += bytesRead

                val now = System.currentTimeMillis()
                if (now - lastUpdate >= 200) {
                    val speed = ((totalBytesSent - lastBytes) * 1000) / (now - lastUpdate)
                    val remainingBytes = totalSize - totalBytesSent
                    val eta = if (speed > 0) remainingBytes / speed else 0L

                    onTransferUpdated(
                        ActiveTransfer(
                            id = transferId,
                            fileName = file.name,
                            fileSize = totalSize,
                            bytesTransferred = totalBytesSent,
                            isIncoming = false,
                            status = TransferStatus.IN_PROGRESS,
                            speedBytesPerSecond = speed,
                            remainingTimeSeconds = eta
                        )
                    )
                    lastUpdate = now
                    lastBytes = totalBytesSent
                }
            }
            out.flush()
            randomAccessFile.close()

            val success = !cancelledTransfers.contains(transferId) && totalBytesSent > endRange
            onTransferUpdated(
                ActiveTransfer(
                    id = transferId,
                    fileName = file.name,
                    fileSize = totalSize,
                    bytesTransferred = totalBytesSent,
                    isIncoming = false,
                    status = if (success) TransferStatus.SUCCESS else TransferStatus.CANCELLED
                )
            )
            onTransferSaved(file.name, totalSize, false, success)

        } catch (e: Exception) {
            Timber.e(e, "Error streaming file download")
            onTransferUpdated(
                ActiveTransfer(
                    id = transferId,
                    fileName = file.name,
                    fileSize = totalSize,
                    bytesTransferred = totalSize,
                    isIncoming = false,
                    status = TransferStatus.FAILED
                )
            )
            onTransferSaved(file.name, totalSize, false, false)
        } finally {
            activeSockets.remove(transferId)
        }
    }

    private fun receiveFile(socket: Socket, input: InputStream, out: BufferedOutputStream, fileName: String, contentLength: Long) {
        val transferId = fileName
        activeSockets[transferId] = socket
        cancelledTransfers.remove(transferId)

        val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
        val vidiopenDir = File(downloadsDir, "Vidiopen")
        if (!vidiopenDir.exists()) vidiopenDir.mkdirs()

        val destFile = File(vidiopenDir, fileName)

        try {
            val fileOut = BufferedOutputStream(FileOutputStream(destFile), 1024 * 1024)
            val buffer = ByteArray(1024 * 1024)
            var bytesRead: Int
            var totalBytesReceived = 0L
            var lastUpdate = System.currentTimeMillis()
            var lastBytes = 0L

            onTransferUpdated(
                ActiveTransfer(
                    id = transferId,
                    fileName = fileName,
                    fileSize = contentLength,
                    bytesTransferred = totalBytesReceived,
                    isIncoming = true,
                    status = TransferStatus.IN_PROGRESS
                )
            )

            // Read raw bytes stream
            if (contentLength > 0L) {
                while (totalBytesReceived < contentLength && !cancelledTransfers.contains(transferId)) {
                    val bytesToRead = Math.min(buffer.size.toLong(), contentLength - totalBytesReceived).toInt()
                    bytesRead = input.read(buffer, 0, bytesToRead)
                    if (bytesRead == -1) break

                    fileOut.write(buffer, 0, bytesRead)
                    totalBytesReceived += bytesRead

                    val now = System.currentTimeMillis()
                    if (now - lastUpdate >= 200) {
                        val timeDiff = Math.max(1L, now - lastUpdate)
                        val speed = ((totalBytesReceived - lastBytes) * 1000) / timeDiff
                        val remainingBytes = contentLength - totalBytesReceived
                        val eta = if (speed > 0) remainingBytes / speed else 0L

                        onTransferUpdated(
                            ActiveTransfer(
                                id = transferId,
                                fileName = fileName,
                                fileSize = contentLength,
                                bytesTransferred = totalBytesReceived,
                                isIncoming = true,
                                status = TransferStatus.IN_PROGRESS,
                                speedBytesPerSecond = speed,
                                remainingTimeSeconds = eta
                            )
                        )
                        lastUpdate = now
                        lastBytes = totalBytesReceived
                    }
                }
            } else {
                while (!cancelledTransfers.contains(transferId)) {
                    bytesRead = input.read(buffer, 0, buffer.size)
                    if (bytesRead == -1) break

                    fileOut.write(buffer, 0, bytesRead)
                    totalBytesReceived += bytesRead

                    val now = System.currentTimeMillis()
                    if (now - lastUpdate >= 200) {
                        val timeDiff = Math.max(1L, now - lastUpdate)
                        val speed = ((totalBytesReceived - lastBytes) * 1000) / timeDiff

                        onTransferUpdated(
                            ActiveTransfer(
                                id = transferId,
                                fileName = fileName,
                                fileSize = totalBytesReceived,
                                bytesTransferred = totalBytesReceived,
                                isIncoming = true,
                                status = TransferStatus.IN_PROGRESS,
                                speedBytesPerSecond = speed,
                                remainingTimeSeconds = 0L
                            )
                        )
                        lastUpdate = now
                        lastBytes = totalBytesReceived
                    }
                }
            }
            fileOut.flush()
            fileOut.close()

            val success = !cancelledTransfers.contains(transferId) && totalBytesReceived > 0L && (contentLength == 0L || totalBytesReceived == contentLength)
            if (!success && destFile.exists()) {
                destFile.delete() // delete partial downloads
            } else if (success) {
                try {
                    android.media.MediaScannerConnection.scanFile(
                        context,
                        arrayOf(destFile.absolutePath),
                        null,
                        null
                    )
                } catch (e: Exception) {
                    Timber.e(e, "Error scanning transferred media file")
                }
            }

            onTransferUpdated(
                ActiveTransfer(
                    id = transferId,
                    fileName = fileName,
                    fileSize = contentLength,
                    bytesTransferred = totalBytesReceived,
                    isIncoming = true,
                    status = if (success) TransferStatus.SUCCESS else TransferStatus.CANCELLED
                )
            )

            onTransferSaved(fileName, contentLength, true, success)

            // Respond back to the browser
            val responseBody = "{\"status\":\"success\",\"file\":\"${destFile.absolutePath}\"}"
            sendResponse(out, "HTTP/1.1 200 OK", "application/json", responseBody)

        } catch (e: Exception) {
            Timber.e(e, "Error receiving file upload")
            if (destFile.exists()) destFile.delete()
            onTransferUpdated(
                ActiveTransfer(
                    id = transferId,
                    fileName = fileName,
                    fileSize = contentLength,
                    bytesTransferred = 0L,
                    isIncoming = true,
                    status = TransferStatus.FAILED
                )
            )
            onTransferSaved(fileName, contentLength, true, false)
            sendResponse(out, "HTTP/1.1 500 Internal Server Error", "application/json", "{\"error\":\"${e.message}\"}")
        } finally {
            activeSockets.remove(transferId)
        }
    }

    private fun buildFilesJson(files: List<TransferFile>): String {
        val sb = StringBuilder()
        sb.append("[")
        for (i in files.indices) {
            val file = files[i]
            sb.append("{")
            sb.append("\"id\":\"").append(escapeJson(file.id)).append("\",")
            sb.append("\"name\":\"").append(escapeJson(file.name)).append("\",")
            sb.append("\"size\":").append(file.size).append(",")
            sb.append("\"path\":\"").append(escapeJson(file.path)).append("\",")
            sb.append("\"type\":\"").append(escapeJson(file.type)).append("\",")
            sb.append("\"mimeType\":\"").append(escapeJson(file.mimeType ?: "")).append("\",")
            sb.append("\"dateModified\":").append(file.dateModified)
            sb.append("}")
            if (i < files.size - 1) sb.append(",")
        }
        sb.append("]")
        return sb.toString()
    }

    private fun escapeJson(str: String): String {
        return str.replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
    }

    private fun getHtmlContent(): String {
        return """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Vidiopen Wi-Fi Transfer Hub</title>
            <style>
                :root {
                    --bg-gradient: linear-gradient(135deg, #020205 0%, #0c0a18 100%);
                    --primary: #00d9ff;
                    --primary-glow: rgba(0, 217, 255, 0.4);
                    --accent: #bc3cf2;
                    --accent-glow: rgba(188, 60, 242, 0.4);
                    --glass: rgba(16, 14, 30, 0.75);
                    --glass-border: rgba(255, 255, 255, 0.08);
                }
                * {
                    box-sizing: border-box;
                    margin: 0;
                    padding: 0;
                    font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
                }
                body {
                    background: var(--bg-gradient);
                    color: #ffffff;
                    min-height: 100vh;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    padding: 20px;
                    overflow-x: hidden;
                }
                .container {
                    width: 100%;
                    max-width: 1000px;
                    display: none;
                }
                .auth-card {
                    width: 100%;
                    max-width: 420px;
                    background: var(--glass);
                    border: 1.5dp solid var(--glass-border);
                    backdrop-filter: blur(25px);
                    border-radius: 24px;
                    padding: 35px;
                    text-align: center;
                    box-shadow: 0 15px 35px rgba(0,0,0,0.5), 0 0 40px rgba(0,217,255,0.05);
                }
                h1, h2, h3 {
                    font-weight: 700;
                    letter-spacing: 0.5px;
                    background: linear-gradient(90deg, var(--primary), var(--accent));
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                }
                h1 { font-size: 26px; margin-bottom: 8px; }
                p { color: #8fa0b5; font-size: 14px; line-height: 1.5; }
                .auth-input-container {
                    margin: 25px 0;
                }
                .pin-input {
                    background: rgba(255,255,255,0.04);
                    border: 2px solid var(--glass-border);
                    border-radius: 12px;
                    color: white;
                    font-size: 24px;
                    letter-spacing: 12px;
                    text-align: center;
                    padding: 12px;
                    width: 100%;
                    outline: none;
                    transition: all 0.3s ease;
                }
                .pin-input:focus {
                    border-color: var(--primary);
                    box-shadow: 0 0 15px var(--primary-glow);
                }
                .btn {
                    width: 100%;
                    background: linear-gradient(90deg, #00d9ff, #bc3cf2);
                    border: none;
                    color: white;
                    padding: 14px;
                    border-radius: 12px;
                    font-size: 16px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: transform 0.2s, opacity 0.2s;
                }
                .btn:hover { transform: translateY(-2px); }
                .btn:active { transform: translateY(0); }
                .pending-auth {
                    display: none;
                    margin-top: 20px;
                }
                /* Main Dashboard Styles */
                .navbar {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    background: var(--glass);
                    border: 1px solid var(--glass-border);
                    padding: 15px 25px;
                    border-radius: 16px;
                    margin-bottom: 20px;
                    backdrop-filter: blur(10px);
                }
                .main-grid {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 20px;
                    width: 100%;
                }
                @media(max-width: 768px) {
                    .main-grid { grid-template-columns: 1fr; }
                }
                .card {
                    background: var(--glass);
                    border: 1px solid var(--glass-border);
                    border-radius: 20px;
                    padding: 24px;
                    backdrop-filter: blur(15px);
                    box-shadow: 0 10px 25px rgba(0,0,0,0.3);
                }
                /* Tabs Styles */
                .tabs {
                    display: flex;
                    gap: 8px;
                    margin-bottom: 15px;
                    overflow-x: auto;
                    padding-bottom: 5px;
                }
                .tab {
                    background: rgba(255,255,255,0.04);
                    border: 1px solid var(--glass-border);
                    border-radius: 10px;
                    color: #8fa0b5;
                    padding: 8px 16px;
                    cursor: pointer;
                    font-size: 13px;
                    font-weight: 500;
                    white-space: nowrap;
                    transition: all 0.2s ease;
                }
                .tab.active {
                    background: var(--primary);
                    color: black;
                    font-weight: 600;
                    border-color: var(--primary);
                }
                .file-list {
                    height: 380px;
                    overflow-y: auto;
                }
                .file-item {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 12px;
                    border-radius: 10px;
                    background: rgba(255,255,255,0.02);
                    margin-bottom: 8px;
                    border: 1px solid transparent;
                    transition: all 0.2s ease;
                }
                .file-item:hover {
                    background: rgba(255,255,255,0.05);
                    border-color: rgba(0,217,255,0.2);
                }
                .file-info {
                    max-width: 80%;
                }
                .file-name {
                    font-size: 14px;
                    font-weight: 500;
                    color: #fff;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }
                .file-size {
                    font-size: 12px;
                    color: #8fa0b5;
                    margin-top: 2px;
                }
                .download-btn {
                    background: rgba(0,217,255,0.1);
                    color: var(--primary);
                    border: 1px solid rgba(0,217,255,0.2);
                    padding: 6px 12px;
                    border-radius: 8px;
                    cursor: pointer;
                    font-size: 12px;
                    font-weight: 500;
                    text-decoration: none;
                }
                .download-btn:hover {
                    background: var(--primary);
                    color: black;
                }
                /* Upload Area Styles */
                .dropzone {
                    border: 2px dashed rgba(188, 60, 242, 0.4);
                    background: rgba(188, 60, 242, 0.02);
                    border-radius: 16px;
                    padding: 40px 20px;
                    text-align: center;
                    cursor: pointer;
                    transition: all 0.3s ease;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    height: 250px;
                }
                .dropzone.hover {
                    border-color: var(--primary);
                    background: rgba(0,217,255,0.04);
                }
                .upload-icon {
                    font-size: 40px;
                    color: var(--accent);
                    margin-bottom: 15px;
                }
                .progress-panel {
                    margin-top: 20px;
                }
                .progress-header {
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: 8px;
                    font-size: 13px;
                }
                .progress-track {
                    height: 8px;
                    background: rgba(255,255,255,0.05);
                    border-radius: 4px;
                    overflow: hidden;
                    margin-bottom: 12px;
                }
                .progress-bar {
                    height: 100%;
                    width: 0;
                    background: linear-gradient(90deg, var(--primary), var(--accent));
                    transition: width 0.1s linear;
                }
                .transfer-metrics {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 10px;
                    font-size: 12px;
                    color: #8fa0b5;
                }
                .loader {
                    border: 3px solid rgba(255,255,255,0.1);
                    border-radius: 50%;
                    border-top: 3px solid var(--primary);
                    width: 30px;
                    height: 30px;
                    animation: spin 1s linear infinite;
                    margin: 15px auto;
                }
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            </style>
        </head>
        <body>
            <!-- Security Auth Card -->
            <div id="auth-screen" class="auth-card">
                <h2>Vidiopen Secure</h2>
                <p style="margin-bottom: 25px;">Enter the 4-digit temporary code displayed on Vidiopen to connect.</p>
                <div class="auth-input-container">
                    <input type="text" id="pin" class="pin-input" maxlength="4" placeholder="••••">
                </div>
                <button class="btn" onclick="authenticate()">Authenticate</button>
                <div id="pending-spinner" class="pending-auth">
                    <div class="loader"></div>
                    <p id="pending-msg">Please check your phone to approve the connection...</p>
                </div>
            </div>

            <!-- Main Hub Content -->
            <div id="main-hub" class="container">
                <div class="navbar">
                    <div>
                        <h2>Vidiopen Transfer</h2>
                        <p id="connection-details">Connected securely</p>
                    </div>
                    <button class="btn" style="width: auto; padding: 8px 16px;" onclick="location.reload()">Disconnect</button>
                </div>

                <div class="main-grid">
                    <!-- Files Browser Card (DOWNLOAD) -->
                    <div class="card">
                        <h3>Device Downloads</h3>
                        <p style="margin-bottom: 15px;">Browse and download files from Vidiopen</p>
                        <div class="tabs">
                            <div class="tab active" onclick="switchCategory('VIDEO', this)">Videos 🎬</div>
                            <div class="tab" onclick="switchCategory('PHOTO', this)">Photos 📸</div>
                            <div class="tab" onclick="switchCategory('MUSIC', this)">Music 🎵</div>
                            <div class="tab" onclick="switchCategory('DOCUMENT', this)">Docs 📄</div>
                            <div class="tab" onclick="switchCategory('APK', this)">Apps 📦</div>
                        </div>
                        <div id="files-container" class="file-list">
                            <!-- Files populated dynamically -->
                        </div>
                    </div>

                    <!-- Upload Station Card (UPLOAD) -->
                    <div class="card">
                        <h3>Upload Station</h3>
                        <p style="margin-bottom: 15px;">Drag files here to send them directly to Vidiopen</p>
                        <div id="drop-area" class="dropzone" onclick="document.getElementById('fileElem').click()">
                            <div class="upload-icon">📥</div>
                            <p style="font-size: 15px; font-weight: 600; color: #fff;">Drag & Drop files here</p>
                            <p style="margin-top: 5px;">or click to browse local files</p>
                            <input type="file" id="fileElem" multiple style="display:none" onchange="handleSelectedFiles(this.files)">
                        </div>

                        <!-- Progress Metrics Panel -->
                        <div id="progress-panel" class="progress-panel" style="display: none;">
                            <div class="progress-header">
                                <span id="transfer-title" style="font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 70%;">file.mp4</span>
                                <span id="upload-percent">0%</span>
                            </div>
                            <div class="progress-track">
                                <div id="progress-indicator" class="progress-bar"></div>
                            </div>
                            <div class="transfer-metrics">
                                <div>Speed: <span id="transfer-speed" style="color: #fff;">0.0 MB/s</span></div>
                                <div>ETA: <span id="transfer-eta" style="color: #fff;">0s</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <script>
                let currentCategory = 'VIDEO';
                let allFiles = [];
                let isPolling = false;

                function authenticate() {
                    const pin = document.getElementById('pin').value;
                    if(pin.length !== 4) {
                        alert('Please enter a 4-digit code');
                        return;
                    }
                    document.getElementById('pending-spinner').style.display = 'block';
                    document.getElementById('pending-msg').innerText = 'Validating authentication code...';

                    fetch('/api/auth?code=' + encodeURIComponent(pin), { method: 'POST' })
                        .then(res => res.json())
                        .then(data => {
                            if (data.status === 'approved') {
                                document.getElementById('auth-screen').style.display = 'none';
                                document.getElementById('main-hub').style.display = 'block';
                                loadFiles();
                            } else if (data.status === 'pending') {
                                document.getElementById('pending-msg').innerText = 'Waiting for your approval on Vidiopen app...';
                                startPollingAuth();
                            } else {
                                alert(data.error || 'Authentication rejected');
                                document.getElementById('pending-spinner').style.display = 'none';
                            }
                        })
                        .catch(err => {
                            alert('Authentication error: ' + err.message);
                            document.getElementById('pending-spinner').style.display = 'none';
                        });
                }

                function startPollingAuth() {
                    if (isPolling) return;
                    isPolling = true;
                    const interval = setInterval(() => {
                        fetch('/api/auth/status')
                            .then(res => res.json())
                            .then(data => {
                                if (data.status === 'approved') {
                                    clearInterval(interval);
                                    document.getElementById('auth-screen').style.display = 'none';
                                    document.getElementById('main-hub').style.display = 'block';
                                    loadFiles();
                                }
                            })
                            .catch(err => {
                                console.error('Polling auth error', err);
                            });
                    }, 2000);
                }

                function loadFiles() {
                    fetch('/api/files')
                        .then(res => res.json())
                        .then(files => {
                            allFiles = files;
                            renderFiles();
                        })
                        .catch(err => {
                            console.error('Error loading files', err);
                        });
                }

                function renderFiles() {
                    const container = document.getElementById('files-container');
                    container.innerHTML = '';
                    const filtered = allFiles.filter(f => f.type === currentCategory);

                    if (filtered.length === 0) {
                        container.innerHTML = '<div style="text-align: center; padding: 40px; color: #8fa0b5;">No files found in this category</div>';
                        return;
                    }

                    filtered.forEach(file => {
                        const div = document.createElement('div');
                        div.className = 'file-item';
                        div.innerHTML = 
                            '<div class="file-info">' +
                                '<div class="file-name" title="' + file.name + '">' + file.name + '</div>' +
                                '<div class="file-size">' + formatBytes(file.size) + '</div>' +
                            '</div>' +
                            '<a class="download-btn" href="/api/download?path=' + encodeURIComponent(file.path) + '" target="_blank">Download</a>';
                        container.appendChild(div);
                    });
                }

                function switchCategory(cat, tabEl) {
                    currentCategory = cat;
                    document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
                    tabEl.classList.add('active');
                    renderFiles();
                }

                function formatBytes(bytes) {
                    if (bytes === 0) return '0 Bytes';
                    const k = 1024;
                    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
                    const i = Math.floor(Math.log(bytes) / Math.log(k));
                    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
                }

                // Dropzone drag-and-drop actions
                const dropArea = document.getElementById('drop-area');
                ['dragenter', 'dragover'].forEach(eventName => {
                    dropArea.addEventListener(eventName, e => {
                        e.preventDefault();
                        dropArea.classList.add('hover');
                    }, false);
                });
                ['dragleave', 'drop'].forEach(eventName => {
                    dropArea.addEventListener(eventName, e => {
                        e.preventDefault();
                        dropArea.classList.remove('hover');
                    }, false);
                });
                dropArea.addEventListener('drop', e => {
                    const dt = e.dataTransfer;
                    const files = dt.files;
                    handleSelectedFiles(files);
                }, false);

                function handleSelectedFiles(files) {
                    if (files.length === 0) return;
                    uploadFilesSequentially(Array.from(files));
                }

                async function uploadFilesSequentially(files) {
                    const progressPanel = document.getElementById('progress-panel');
                    progressPanel.style.display = 'block';

                    for (let file of files) {
                        await uploadFile(file);
                    }
                    setTimeout(() => {
                        progressPanel.style.display = 'none';
                        loadFiles(); // reload lists
                    }, 2000);
                }

                function uploadFile(file) {
                    return new Promise((resolve, reject) => {
                        document.getElementById('transfer-title').innerText = file.name;
                        let startTime = Date.now();
                        let lastTime = startTime;
                        let lastBytes = 0;

                        let xhr = new XMLHttpRequest();
                        xhr.open('POST', '/api/upload?filename=' + encodeURIComponent(file.name), true);

                        xhr.upload.onprogress = function(e) {
                            if (e.lengthComputable) {
                                let percent = Math.round((e.loaded / e.total) * 100);
                                document.getElementById('progress-indicator').style.width = percent + '%';
                                document.getElementById('upload-percent').innerText = percent + '%';

                                let now = Date.now();
                                let elapsed = (now - startTime) / 1000;
                                if (elapsed > 0) {
                                    let speed = e.loaded / elapsed; // bytes/sec
                                    document.getElementById('transfer-speed').innerText = formatBytes(speed) + '/s';
                                    let remainingBytes = e.total - e.loaded;
                                    let eta = speed > 0 ? Math.round(remainingBytes / speed) : 0;
                                    document.getElementById('transfer-eta').innerText = eta + 's';
                                }
                            }
                        };

                        xhr.onload = function() {
                            if (xhr.status === 200) {
                                document.getElementById('upload-percent').innerText = '100% (Done)';
                                resolve();
                            } else {
                                alert('Upload failed for file: ' + file.name);
                                resolve(); // continue next file regardless
                            }
                        };

                        xhr.onerror = function() {
                            alert('Network error during upload');
                            resolve();
                        };

                        xhr.send(file);
                    });
                }
            </script>
        </body>
        </html>
        """.trimIndent()
    }
}
