package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "media_items")
data class MediaEntity(
    @PrimaryKey val id: String,
    val title: String,
    val url: String,
    val duration: Long,
    val artist: String?,
    val thumbnailUrl: String?,
    val category: String, // "Movie", "TV Show", "Music", "Downloaded", "Added"
    val isFavorite: Boolean = false,
    val lastPlayedPosition: Long = 0L,
    val addedDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "vault_items")
data class VaultEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val path: String,
    val type: String, // "VIDEO", "PHOTO", "AUDIO", "DOCUMENT"
    val size: Long = 0L,
    val isFavorite: Boolean = false,
    val addedDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "config_items")
data class ConfigEntity(
    @PrimaryKey val key: String,
    val value: String
)

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey val id: String,
    val title: String,
    val url: String,
    val duration: Long,
    val artist: String?,
    val thumbnailUrl: String?,
    val category: String,
    val watchedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "pinned_folders")
data class PinnedFolderEntity(
    @PrimaryKey val folderPath: String,
    val pinnedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "recycle_bin")
data class RecycleBinEntity(
    @PrimaryKey val id: String,
    val title: String,
    val path: String,
    val duration: Long,
    val size: Long,
    val dateAdded: Long,
    val uriString: String,
    val thumbnailUrl: String?,
    val type: String, // "SCANNED" or "STREAM"
    val deletedAt: Long = System.currentTimeMillis()
)

