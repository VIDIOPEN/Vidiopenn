package com.example.data.database
import com.example.data.model.MediaEntity
import com.example.data.model.VaultEntity
import com.example.data.model.ConfigEntity
import com.example.data.model.WatchHistoryEntity
import com.example.data.model.PinnedFolderEntity
import com.example.data.model.VideoBookmarkEntity
import com.example.data.model.CapturedFrameEntity
import com.example.data.model.RecycleBinEntity

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MediaDao {
    @Query("SELECT * FROM media_items ORDER BY addedDate DESC")
    fun getAllMedia(): Flow<List<MediaEntity>>

    @Query("SELECT * FROM media_items WHERE category = :category ORDER BY addedDate DESC")
    fun getMediaByCategory(category: String): Flow<List<MediaEntity>>

    @Query("SELECT * FROM media_items WHERE isFavorite = 1")
    fun getFavorites(): Flow<List<MediaEntity>>

    @Query("SELECT * FROM media_items WHERE lastPlayedPosition > 0 ORDER BY addedDate DESC")
    fun getContinueWatching(): Flow<List<MediaEntity>>

    @Query("SELECT * FROM media_items WHERE id = :id")
    suspend fun getMediaById(id: String): MediaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedia(media: MediaEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllMedia(mediaList: List<MediaEntity>)

    @Update
    suspend fun updateMedia(media: MediaEntity)

    @Query("UPDATE media_items SET lastPlayedPosition = :position WHERE id = :id")
    suspend fun updatePlaybackPosition(id: String, position: Long)

    @Query("UPDATE media_items SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun toggleFavorite(id: String, isFavorite: Boolean)

    @Query("DELETE FROM media_items WHERE id = :id")
    suspend fun deleteMedia(id: String)
}

@Dao
interface VaultDao {
    @Query("SELECT * FROM vault_items ORDER BY addedDate DESC")
    fun getVaultItems(): Flow<List<VaultEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaultItem(item: VaultEntity)

    @Query("UPDATE vault_items SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun toggleFavorite(id: Int, isFavorite: Boolean)

    @Query("DELETE FROM vault_items WHERE id = :id")
    suspend fun deleteVaultItem(id: Int)
}

@Dao
interface ConfigDao {
    @Query("SELECT * FROM config_items WHERE `key` = :key LIMIT 1")
    suspend fun getConfig(key: String): ConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConfig(config: ConfigEntity)
}

@Dao
interface WatchHistoryDao {
    @Query("SELECT * FROM watch_history ORDER BY watchedTimestamp DESC")
    fun getWatchHistory(): Flow<List<WatchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWatchHistory(history: WatchHistoryEntity)

    @Query("DELETE FROM watch_history WHERE id = :id")
    suspend fun deleteWatchHistoryById(id: String)

    @Query("DELETE FROM watch_history")
    suspend fun clearWatchHistory()
}

@Dao
interface PinnedFolderDao {
    @Query("SELECT folderPath FROM pinned_folders")
    fun getPinnedFolderPaths(): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun pinFolder(folder: PinnedFolderEntity)

    @Query("DELETE FROM pinned_folders WHERE folderPath = :folderPath")
    suspend fun unpinFolder(folderPath: String)
}

@Dao
interface VideoBookmarkDao {
    @Query("SELECT * FROM video_bookmarks WHERE videoId = :videoId ORDER BY timestampMs ASC")
    fun getBookmarksForVideo(videoId: String): Flow<List<VideoBookmarkEntity>>

    @Query("SELECT * FROM video_bookmarks ORDER BY dateCreated DESC")
    fun getAllBookmarks(): Flow<List<VideoBookmarkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: VideoBookmarkEntity)

    @Update
    suspend fun updateBookmark(bookmark: VideoBookmarkEntity)

    @Query("DELETE FROM video_bookmarks WHERE id = :id")
    suspend fun deleteBookmark(id: Int)

    @Query("UPDATE video_bookmarks SET bookmarkName = :newName WHERE id = :id")
    suspend fun renameBookmark(id: Int, newName: String)
}

@Dao
interface CapturedFrameDao {
    @Query("SELECT * FROM captured_frames ORDER BY dateCreated DESC")
    fun getAllCapturedFrames(): Flow<List<CapturedFrameEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCapturedFrame(frame: CapturedFrameEntity): Long

    @Query("DELETE FROM captured_frames WHERE id = :id")
    suspend fun deleteCapturedFrame(id: Long)

    @Query("SELECT * FROM captured_frames WHERE videoId = :videoId ORDER BY timestampMs ASC")
    fun getCapturedFramesForVideo(videoId: String): Flow<List<CapturedFrameEntity>>
}

@Dao
interface RecycleBinDao {
    @Query("SELECT * FROM recycle_bin ORDER BY deletedAt DESC")
    fun getAllDeletedVideos(): Flow<List<RecycleBinEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDeletedVideo(item: RecycleBinEntity)

    @Query("DELETE FROM recycle_bin WHERE id = :id")
    suspend fun deleteDeletedVideo(id: String)

    @Query("DELETE FROM recycle_bin")
    suspend fun clearRecycleBin()

    @Query("SELECT * FROM recycle_bin WHERE id = :id")
    suspend fun getDeletedVideoById(id: String): RecycleBinEntity?
}



