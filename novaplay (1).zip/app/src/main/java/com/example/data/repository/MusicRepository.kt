package com.example.data.repository

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import com.example.data.model.ScannedSong
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File

class MusicRepository(private val context: Context) {

    private val audioExtensions = setOf(
        "mp3", "m4a", "aac", "flac", "wav", "ogg", "opus", "wma",
        "m4p", "mid", "amr", "aiff", "alac", "3gp", "webm"
    )

    private fun isRingtoneOrSystemAudio(
        path: String,
        title: String,
        isRingtone: Boolean = false,
        isNotification: Boolean = false,
        isAlarm: Boolean = false,
        isMusic: Boolean = true,
        durationMs: Long = 0L
    ): Boolean {
        // Explicit MediaStore flags
        if (isRingtone || isNotification || isAlarm) return true

        val lowerPath = path.lowercase()
        val lowerTitle = title.lowercase()
        val fileName = try { File(path).name.lowercase() } catch (_: Exception) { "" }

        // Explicit path checks for system audio or ringtone directories
        if (lowerPath.contains("/system/media/") ||
            lowerPath.contains("/system/audio/") ||
            lowerPath.contains("/ringtones/") ||
            lowerPath.contains("/ringtone/") ||
            lowerPath.contains("/notifications/") ||
            lowerPath.contains("/notification/") ||
            lowerPath.contains("/alarms/") ||
            lowerPath.contains("/alarm/") ||
            lowerPath.contains("/audiotrimmer/") ||
            (lowerPath.contains("android/data/") && lowerPath.contains("ringtones"))
        ) {
            return true
        }

        // Filename / title checks
        if (fileName.startsWith("ringtone_") ||
            fileName.contains("_ringtone") ||
            fileName.startsWith("notification_") ||
            fileName.startsWith("alarm_") ||
            lowerTitle.startsWith("ringtone_") ||
            lowerTitle.contains("_ringtone")
        ) {
            return true
        }

        // Short audio clip filter (< 15 seconds) that contain ringtone keywords or are not flagged as music
        if (durationMs in 1..14999L) {
            if (!isMusic || lowerPath.contains("ringtone") || lowerPath.contains("notification") || lowerTitle.contains("ringtone")) {
                return true
            }
        }

        return false
    }

    suspend fun scanAudio(): List<ScannedSong> = withContext(Dispatchers.IO) {
        val songMap = LinkedHashMap<String, ScannedSong>()
        val newScanPaths = mutableListOf<String>()

        // 1. Query MediaStore Audio External only (INTERNAL contains system ringtones/notifications)
        val collections = arrayOf(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        )

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.IS_RINGTONE,
            MediaStore.Audio.Media.IS_NOTIFICATION,
            MediaStore.Audio.Media.IS_ALARM,
            MediaStore.Audio.Media.IS_MUSIC
        )

        for (collection in collections) {
            try {
                context.contentResolver.query(
                    collection,
                    projection,
                    "${MediaStore.Audio.Media.IS_RINGTONE} = 0 AND ${MediaStore.Audio.Media.IS_NOTIFICATION} = 0 AND ${MediaStore.Audio.Media.IS_ALARM} = 0",
                    null,
                    "${MediaStore.Audio.Media.DATE_ADDED} DESC"
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndex(MediaStore.Audio.Media._ID)
                    val titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                    val artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                    val albumCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM)
                    val durationCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                    val sizeCol = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE)
                    val pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                    val dateAddedCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)
                    val albumIdCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)
                    val nameCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                    val isRingtoneCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_RINGTONE)
                    val isNotifCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_NOTIFICATION)
                    val isAlarmCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_ALARM)
                    val isMusicCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_MUSIC)

                    while (cursor.moveToNext()) {
                        val path = if (pathCol != -1) cursor.getString(pathCol) ?: "" else ""
                        if (path.isEmpty()) continue

                        val file = File(path)
                        if (!file.exists() || file.length() < 1024) continue

                        val ext = file.extension.lowercase()
                        if (!audioExtensions.contains(ext) && !ext.contains("mp3")) continue

                        val isRingtone = isRingtoneCol != -1 && cursor.getInt(isRingtoneCol) == 1
                        val isNotif = isNotifCol != -1 && cursor.getInt(isNotifCol) == 1
                        val isAlarm = isAlarmCol != -1 && cursor.getInt(isAlarmCol) == 1
                        val isMusic = isMusicCol == -1 || cursor.getInt(isMusicCol) == 1

                        val durationVal = if (durationCol != -1) cursor.getLong(durationCol) else 0L

                        var title = if (titleCol != -1) cursor.getString(titleCol) else null
                        if (title.isNullOrBlank() || title == MediaStore.UNKNOWN_STRING) {
                            val dispName = if (nameCol != -1) cursor.getString(nameCol) else null
                            title = if (!dispName.isNullOrBlank()) file.nameWithoutExtension else file.nameWithoutExtension
                        }

                        if (isRingtoneOrSystemAudio(
                                path = path,
                                title = title ?: file.nameWithoutExtension,
                                isRingtone = isRingtone,
                                isNotification = isNotif,
                                isAlarm = isAlarm,
                                isMusic = isMusic,
                                durationMs = durationVal
                            )
                        ) {
                            continue
                        }

                        val canonicalKey = try { file.canonicalPath.lowercase() } catch (e: Exception) { path.lowercase() }
                        if (songMap.containsKey(canonicalKey)) continue

                        val id = if (idCol != -1) cursor.getLong(idCol) else Math.abs(canonicalKey.hashCode().toLong())

                        val artistVal = if (artistCol != -1) cursor.getString(artistCol) else null
                        val artist = if (artistVal.isNullOrBlank() || artistVal == MediaStore.UNKNOWN_STRING) "Unknown Artist" else artistVal

                        val albumVal = if (albumCol != -1) cursor.getString(albumCol) else null
                        val album = if (albumVal.isNullOrBlank() || albumVal == MediaStore.UNKNOWN_STRING) "Unknown Album" else albumVal

                        var duration = durationVal
                        val size = if (sizeCol != -1 && cursor.getLong(sizeCol) > 0) cursor.getLong(sizeCol) else file.length()
                        val dateAdded = if (dateAddedCol != -1 && cursor.getLong(dateAddedCol) > 0) cursor.getLong(dateAddedCol) else file.lastModified() / 1000
                        val albumId = if (albumIdCol != -1) cursor.getLong(albumIdCol) else 0L

                        val artworkUri = if (albumId > 0) {
                            ContentUris.withAppendedId(
                                Uri.parse("content://media/external/audio/albumart"),
                                albumId
                            ).toString()
                        } else null

                        songMap[canonicalKey] = ScannedSong(
                            id = id,
                            title = title ?: file.nameWithoutExtension,
                            artist = artist,
                            album = album,
                            duration = if (duration > 0) duration else 180000L,
                            size = size,
                            path = file.absolutePath,
                            dateAdded = dateAdded,
                            albumId = albumId,
                            artworkUri = artworkUri
                        )
                    }
                }
            } catch (e: Exception) {
                Timber.e(e, "MusicRepository: Error querying audio collection $collection")
            }
        }

        // 2. Query MediaStore.Files for any audio MIME types or extensions missed by Audio.Media
        try {
            val fileCollection = MediaStore.Files.getContentUri("external")
            val fileProjection = arrayOf(
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.DATE_MODIFIED,
                MediaStore.Files.FileColumns.DISPLAY_NAME
            )
            val fileSelection = "${MediaStore.Files.FileColumns.MIME_TYPE} LIKE 'audio/%' OR " +
                    audioExtensions.joinToString(" OR ") { "${MediaStore.Files.FileColumns.DATA} LIKE '%.$it'" }

            context.contentResolver.query(
                fileCollection,
                fileProjection,
                fileSelection,
                null,
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val pathCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA)
                val sizeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.SIZE)
                val dateCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATE_MODIFIED)
                val nameCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)

                while (cursor.moveToNext()) {
                    val path = if (pathCol != -1) cursor.getString(pathCol) ?: "" else ""
                    if (path.isEmpty()) continue

                    val file = File(path)
                    if (!file.exists() || file.length() < 1024) continue

                    val canonicalKey = try { file.canonicalPath.lowercase() } catch (e: Exception) { path.lowercase() }
                    if (songMap.containsKey(canonicalKey)) continue

                    val ext = file.extension.lowercase()
                    if (!audioExtensions.contains(ext)) continue

                    val name = if (nameCol != -1) cursor.getString(nameCol) else null
                    val title = if (!name.isNullOrBlank()) file.nameWithoutExtension else file.nameWithoutExtension

                    if (isRingtoneOrSystemAudio(path, title)) continue

                    val size = if (sizeCol != -1 && cursor.getLong(sizeCol) > 0) cursor.getLong(sizeCol) else file.length()
                    val dateAdded = if (dateCol != -1 && cursor.getLong(dateCol) > 0) cursor.getLong(dateCol) else file.lastModified() / 1000

                    songMap[canonicalKey] = ScannedSong(
                        id = Math.abs(canonicalKey.hashCode().toLong()),
                        title = title,
                        artist = "Unknown Artist",
                        album = "Unknown Album",
                        duration = 180000L,
                        size = size,
                        path = file.absolutePath,
                        dateAdded = dateAdded,
                        albumId = 0L,
                        artworkUri = null
                    )
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "MusicRepository: Error querying MediaStore Files")
        }

        // 3. Direct Storage Scan for common directories (Music, Downloads, Audio, WhatsApp, Telegram, etc.)
        val scanDirs = mutableListOf<File>()
        try {
            val root = Environment.getExternalStorageDirectory()
            if (root != null && root.exists()) {
                val commonNames = listOf(
                    "Music", "Download", "Downloads", "Audio", "Bluetooth", "Documents",
                    "Podcasts", "Snaptube", "Vidmate",
                    "UCDownloads", "WhatsApp/Media/WhatsApp Audio", "Telegram/Telegram Audio", "VidiopenAudio"
                )
                for (name in commonNames) {
                    val d = File(root, name)
                    if (d.exists() && d.isDirectory) {
                        scanDirs.add(d)
                    }
                }
                scanDirs.add(root) // Also root
            }
        } catch (e: Exception) {
            Timber.e(e, "MusicRepository: Error resolving external storage directories")
        }

        fun traverseDirectory(dir: File, depth: Int) {
            if (depth > 4 || !dir.isDirectory || !dir.canRead()) return
            val files = dir.listFiles() ?: return
            for (f in files) {
                if (f.isDirectory) {
                    val name = f.name
                    if (!name.startsWith(".") && name != "Android" && name != "cache" &&
                        !name.equals("ringtones", ignoreCase = true) &&
                        !name.equals("notifications", ignoreCase = true) &&
                        !name.equals("alarms", ignoreCase = true)
                    ) {
                        traverseDirectory(f, depth + 1)
                    }
                } else if (f.isFile && f.length() >= 1024) {
                    val ext = f.extension.lowercase()
                    if (audioExtensions.contains(ext)) {
                        val canonicalKey = try { f.canonicalPath.lowercase() } catch (e: Exception) { f.absolutePath.lowercase() }
                        if (!songMap.containsKey(canonicalKey)) {
                            if (!isRingtoneOrSystemAudio(f.absolutePath, f.nameWithoutExtension)) {
                                val song = ScannedSong(
                                    id = Math.abs(canonicalKey.hashCode().toLong()),
                                    title = f.nameWithoutExtension,
                                    artist = "Unknown Artist",
                                    album = "Unknown Album",
                                    duration = 180000L,
                                    size = f.length(),
                                    path = f.absolutePath,
                                    dateAdded = f.lastModified() / 1000,
                                    albumId = 0L,
                                    artworkUri = null
                                )
                                songMap[canonicalKey] = song
                                newScanPaths.add(f.absolutePath)
                            }
                        }
                    }
                }
            }
        }

        for (dir in scanDirs) {
            traverseDirectory(dir, 0)
        }

        // 4. Extract real metadata (duration, title, artist, album) via MediaMetadataRetriever for songs missing details
        val retriever = MediaMetadataRetriever()
        val resultList = songMap.values.map { song ->
            if (song.duration == 180000L || song.artist == "Unknown Artist" || song.title == "Unknown Song") {
                try {
                    val file = File(song.path)
                    if (file.exists()) {
                        retriever.setDataSource(song.path)
                        val metaDuration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                        val metaTitle = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                        val metaArtist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                        val metaAlbum = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)

                        val finalDuration = if (metaDuration != null && metaDuration > 0) metaDuration else song.duration
                        val finalTitle = if (!metaTitle.isNullOrBlank()) metaTitle else song.title
                        val finalArtist = if (!metaArtist.isNullOrBlank()) metaArtist else song.artist
                        val finalAlbum = if (!metaAlbum.isNullOrBlank()) metaAlbum else song.album

                        song.copy(
                            title = finalTitle,
                            artist = finalArtist,
                            album = finalAlbum,
                            duration = finalDuration
                        )
                    } else song
                } catch (e: Exception) {
                    song
                }
            } else song
        }
        try {
            retriever.release()
        } catch (e: Exception) {
            // Ignore release error
        }

        // Final filter to remove any detected ringtones or system audio
        val filteredList = resultList.filterNot { song ->
            isRingtoneOrSystemAudio(
                path = song.path,
                title = song.title,
                durationMs = song.duration
            )
        }

        // Trigger MediaScanner for any newly found files from direct storage scan
        if (newScanPaths.isNotEmpty()) {
            try {
                MediaScannerConnection.scanFile(
                    context,
                    newScanPaths.take(50).toTypedArray(),
                    null,
                    null
                )
            } catch (e: Exception) {
                Timber.e(e, "MusicRepository: Failed to trigger MediaScannerConnection")
            }
        }

        filteredList.sortedByDescending { it.dateAdded }
    }
}

