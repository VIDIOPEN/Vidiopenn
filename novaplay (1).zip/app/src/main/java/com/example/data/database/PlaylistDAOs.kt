package com.example.data.database

import androidx.room.*
import com.example.data.model.VideoPlaylistEntity
import com.example.data.model.PlaylistVideoEntity
import com.example.data.model.QueueVideoEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM video_playlists ORDER BY createdAt DESC")
    fun getAllPlaylists(): Flow<List<VideoPlaylistEntity>>

    @Query("SELECT * FROM video_playlists WHERE id = :playlistId")
    suspend fun getPlaylistById(playlistId: Long): VideoPlaylistEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: VideoPlaylistEntity): Long

    @Query("UPDATE video_playlists SET name = :newName WHERE id = :playlistId")
    suspend fun renamePlaylist(playlistId: Long, newName: String)

    @Query("DELETE FROM video_playlists WHERE id = :playlistId")
    suspend fun deletePlaylist(playlistId: Long)

    @Query("DELETE FROM playlist_videos WHERE playlistId = :playlistId")
    suspend fun deletePlaylistVideos(playlistId: Long)

    @Transaction
    suspend fun deletePlaylistWithVideos(playlistId: Long) {
        deletePlaylistVideos(playlistId)
        deletePlaylist(playlistId)
    }

    @Query("SELECT * FROM playlist_videos WHERE playlistId = :playlistId ORDER BY orderIndex ASC")
    fun getVideosForPlaylist(playlistId: Long): Flow<List<PlaylistVideoEntity>>

    @Query("SELECT * FROM playlist_videos WHERE playlistId = :playlistId ORDER BY orderIndex ASC")
    suspend fun getVideosForPlaylistList(playlistId: Long): List<PlaylistVideoEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistVideo(video: PlaylistVideoEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistVideos(videos: List<PlaylistVideoEntity>)

    @Query("DELETE FROM playlist_videos WHERE id = :id")
    suspend fun deletePlaylistVideo(id: Long)

    @Update
    suspend fun updatePlaylistVideo(video: PlaylistVideoEntity)

    @Transaction
    suspend fun reorderVideos(playlistId: Long, reorderedList: List<PlaylistVideoEntity>) {
        deletePlaylistVideos(playlistId)
        val updated = reorderedList.mapIndexed { index, video ->
            video.copy(id = 0L, orderIndex = index)
        }
        insertPlaylistVideos(updated)
    }
}

@Dao
interface QueueDao {
    @Query("SELECT * FROM queue_videos ORDER BY orderIndex ASC")
    fun getQueueVideos(): Flow<List<QueueVideoEntity>>

    @Query("SELECT * FROM queue_videos ORDER BY orderIndex ASC")
    suspend fun getQueueVideosList(): List<QueueVideoEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQueueVideo(video: QueueVideoEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQueueVideos(videos: List<QueueVideoEntity>)

    @Query("DELETE FROM queue_videos WHERE id = :id")
    suspend fun deleteQueueVideo(id: Long)

    @Query("DELETE FROM queue_videos")
    suspend fun clearQueue()

    @Transaction
    suspend fun reorderQueue(reorderedList: List<QueueVideoEntity>) {
        clearQueue()
        val updated = reorderedList.mapIndexed { index, video ->
            video.copy(id = 0L, orderIndex = index)
        }
        insertQueueVideos(updated)
    }
}
