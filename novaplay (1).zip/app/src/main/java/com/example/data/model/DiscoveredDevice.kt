package com.example.data.model

data class DiscoveredDevice(
    val ip: String,
    val deviceName: String,
    val deviceModel: String,
    val deviceId: String,
    val sessionCode: String = "1234",
    val port: Int = 8080
)
