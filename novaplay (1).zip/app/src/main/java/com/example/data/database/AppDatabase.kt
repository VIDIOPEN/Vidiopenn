package com.example.data.database
import com.example.data.model.MediaEntity
import com.example.data.model.VaultEntity
import com.example.data.model.ConfigEntity
import com.example.data.model.WatchHistoryEntity
import com.example.data.model.PinnedFolderEntity
import com.example.data.model.VideoBookmarkEntity
import com.example.data.model.VideoPlaylistEntity
import com.example.data.model.PlaylistVideoEntity
import com.example.data.model.QueueVideoEntity
import com.example.data.model.CapturedFrameEntity
import com.example.data.model.TransferHistoryEntity
import com.example.data.model.RecycleBinEntity

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [MediaEntity::class, VaultEntity::class, ConfigEntity::class, WatchHistoryEntity::class, PinnedFolderEntity::class, VideoBookmarkEntity::class, VideoPlaylistEntity::class, PlaylistVideoEntity::class, QueueVideoEntity::class, CapturedFrameEntity::class, TransferHistoryEntity::class, RecycleBinEntity::class], version = 7, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun mediaDao(): MediaDao
    abstract fun vaultDao(): VaultDao
    abstract fun configDao(): ConfigDao
    abstract fun watchHistoryDao(): WatchHistoryDao
    abstract fun pinnedFolderDao(): PinnedFolderDao
    abstract fun videoBookmarkDao(): VideoBookmarkDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun queueDao(): QueueDao
    abstract fun capturedFrameDao(): CapturedFrameDao
    abstract fun transferHistoryDao(): TransferHistoryDao
    abstract fun recycleBinDao(): RecycleBinDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "vidiopen_database"
                )
                .fallbackToDestructiveMigration(true)
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
