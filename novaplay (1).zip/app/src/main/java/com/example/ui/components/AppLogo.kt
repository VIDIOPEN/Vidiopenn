package com.example.ui.components

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.dp

@Composable
fun AppLogo(
    modifier: Modifier = Modifier,
    showContainer: Boolean = true
) {
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val minSize = minOf(w, h)

            if (showContainer) {
                // 1. Outer Glassmorphic Squircle Background
                val cornerPx = minSize * 0.28f
                val glassPath = Path().apply {
                    addRoundRect(
                        RoundRect(
                            rect = androidx.compose.ui.geometry.Rect(0f, 0f, w, h),
                            cornerRadius = CornerRadius(cornerPx, cornerPx)
                        )
                    )
                }

                // Deep Midnight Blue-Black Glass Body
                drawPath(
                    path = glassPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF090D1A),
                            Color(0xFF04060E),
                            Color(0xFF070B16)
                        )
                    )
                )

                // Background Ambient Glow Aura (Cyan + Neon Magenta center radial glow)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF00F0FF).copy(alpha = 0.25f),
                            Color(0xFFBD00FF).copy(alpha = 0.18f),
                            Color.Transparent
                        ),
                        center = Offset(w * 0.5f, h * 0.42f),
                        radius = minSize * 0.55f
                    ),
                    center = Offset(w * 0.5f, h * 0.42f),
                    radius = minSize * 0.55f
                )

                // Glass Sheen Reflection (Top-Left sheen)
                val sheenPath = Path().apply {
                    moveTo(0f, 0f)
                    lineTo(w, 0f)
                    lineTo(w, h * 0.45f)
                    quadraticTo(w * 0.5f, h * 0.28f, 0f, h * 0.45f)
                    close()
                }
                drawPath(
                    path = sheenPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.20f),
                            Color.White.copy(alpha = 0.02f)
                        )
                    )
                )

                // Neon Outer Rim Glow (Cyan -> Electric Blue -> Neon Purple -> Hot Pink)
                drawPath(
                    path = glassPath,
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            Color(0xFF00F0FF),
                            Color(0xFF0066FF),
                            Color(0xFFBD00FF),
                            Color(0xFFFF007A),
                            Color(0xFF00F0FF)
                        ),
                        center = Offset(w * 0.5f, h * 0.5f)
                    ),
                    style = Stroke(width = minSize * 0.035f)
                )
            }

            // 2. THE GLOWING OUTER NEON PLAY TRIANGLE FRAME
            // Rounded play triangle coordinates (centered vertically and horizontally)
            val outerPlayPath = Path().apply {
                val leftX = w * 0.23f
                val rightX = w * 0.78f
                val topY = h * 0.17f
                val bottomY = h * 0.61f
                val centerY = h * 0.39f

                moveTo(leftX + w * 0.08f, topY)
                lineTo(rightX - w * 0.06f, centerY - h * 0.03f)
                quadraticTo(rightX, centerY, rightX - w * 0.06f, centerY + h * 0.03f)
                lineTo(leftX + w * 0.08f, bottomY)
                quadraticTo(leftX, bottomY + h * 0.02f, leftX, bottomY - h * 0.06f)
                lineTo(leftX, topY + h * 0.06f)
                quadraticTo(leftX, topY - h * 0.02f, leftX + w * 0.08f, topY)
                close()
            }

            // Outer Play Button Thick Gradient Stroke
            drawPath(
                path = outerPlayPath,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF00F0FF),  // Electric Cyan (Left)
                        Color(0xFF0077FF),  // Deep Blue (Top)
                        Color(0xFFBD00FF),  // Purple (Right)
                        Color(0xFFFF00A0)   // Magenta / Hot Pink (Bottom)
                    ),
                    start = Offset(w * 0.2f, h * 0.2f),
                    end = Offset(w * 0.8f, h * 0.6f)
                ),
                style = Stroke(
                    width = minSize * 0.085f,
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )

            // Inner Accent Highlight Line on Outer Frame
            drawPath(
                path = outerPlayPath,
                brush = Brush.verticalGradient(
                    colors = listOf(Color.White.copy(alpha = 0.6f), Color.Transparent)
                ),
                style = Stroke(width = minSize * 0.02f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            // 3. INNER SOLID WHITE/GLASS PLAY TRIANGLE
            val innerPlayPath = Path().apply {
                val leftX = w * 0.38f
                val rightX = w * 0.61f
                val topY = h * 0.29f
                val bottomY = h * 0.49f
                val centerY = h * 0.39f

                moveTo(leftX + w * 0.04f, topY)
                lineTo(rightX - w * 0.03f, centerY - h * 0.015f)
                quadraticTo(rightX, centerY, rightX - w * 0.03f, centerY + h * 0.015f)
                lineTo(leftX + w * 0.04f, bottomY)
                quadraticTo(leftX, bottomY + h * 0.015f, leftX, bottomY - h * 0.03f)
                lineTo(leftX, topY + h * 0.03f)
                quadraticTo(leftX, topY - h * 0.015f, leftX + w * 0.04f, topY)
                close()
            }

            // Soft glow behind inner play button
            drawPath(
                path = innerPlayPath,
                color = Color(0xFF00F0FF).copy(alpha = 0.35f)
            )

            // Solid Pure White Play Triangle
            drawPath(
                path = innerPlayPath,
                color = Color.White
            )

            // 4. "VIDIOPEN" BRAND TYPOGRAPHY BELOW PLAY BUTTON
            if (minSize >= 40.dp.toPx()) {
                val textPaint = Paint().apply {
                    color = android.graphics.Color.WHITE
                    textSize = minSize * 0.105f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    isAntiAlias = true
                    textAlign = Paint.Align.CENTER
                    letterSpacing = 0.28f
                }

                drawContext.canvas.nativeCanvas.drawText(
                    "VIDIOPEN",
                    w * 0.5f,
                    h * 0.77f,
                    textPaint
                )

                // 5. NEON PROGRESS SLIDER LINE & DOT
                val lineY = h * 0.86f
                val lineStartX = w * 0.28f
                val lineEndX = w * 0.72f
                val dotX = w * 0.50f

                // Left Half Pink Line
                drawLine(
                    brush = Brush.horizontalGradient(
                        colors = listOf(Color(0xFFFF00A0), Color(0xFFBD00FF)),
                        startX = lineStartX,
                        endX = dotX
                    ),
                    start = Offset(lineStartX, lineY),
                    end = Offset(dotX, lineY),
                    strokeWidth = minSize * 0.022f,
                    cap = StrokeCap.Round
                )

                // Right Half Cyan Line
                drawLine(
                    brush = Brush.horizontalGradient(
                        colors = listOf(Color(0xFF00F0FF), Color(0xFF0088FF)),
                        startX = dotX,
                        endX = lineEndX
                    ),
                    start = Offset(dotX, lineY),
                    end = Offset(lineEndX, lineY),
                    strokeWidth = minSize * 0.022f,
                    cap = StrokeCap.Round
                )

                // Center Glowing Dot Handle
                drawCircle(
                    color = Color(0xFF00F0FF).copy(alpha = 0.4f),
                    radius = minSize * 0.032f,
                    center = Offset(dotX, lineY)
                )
                drawCircle(
                    color = Color.White,
                    radius = minSize * 0.020f,
                    center = Offset(dotX, lineY)
                )
            }
        }
    }
}


