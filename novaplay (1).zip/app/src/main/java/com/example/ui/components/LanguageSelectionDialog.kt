package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LocalIsLightTheme
import com.example.ui.theme.RoyalPurple

import androidx.compose.material.icons.rounded.Close

@Composable
fun LanguageSelectionOverlay(
    currentLanguage: String = "en",
    onDismiss: (() -> Unit)? = null,
    onLanguageSelected: (String) -> Unit
) {
    var selectedLang by remember { mutableStateOf(if (currentLanguage.isEmpty()) "en" else currentLanguage) }
    val isLight = LocalIsLightTheme.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isLight) Color.White.copy(alpha = 0.98f) else Color.Black.copy(alpha = 0.95f))
            .clickable(enabled = false) {}, // Intercept clicks
        contentAlignment = Alignment.Center
    ) {
        // Glowing background elements
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            RoyalPurple.copy(alpha = 0.15f),
                            Color.Transparent
                        ),
                        radius = 1200f
                    )
                )
        )

        if (onDismiss != null) {
            IconButton(
                onClick = { onDismiss() },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp)
                    .statusBarsPadding()
            ) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "Close",
                    tint = if (isLight) Color.Black else Color.White
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Icon header with animated pulse
            val infiniteTransition = rememberInfiniteTransition(label = "LanguagePulse")
            val pulseScale by infiniteTransition.animateFloat(
                initialValue = 0.95f,
                targetValue = 1.05f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1500, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "PulseScale"
            )

            Box(
                modifier = Modifier
                    .size(72.dp)
                    .scale(pulseScale)
                    .background(ElectricBlue.copy(alpha = 0.15f), CircleShape)
                    .border(2.dp, ElectricBlue.copy(alpha = 0.4f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Language,
                    contentDescription = "Language Selection",
                    tint = ElectricBlue,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Choose Language\nभाषा चुनें",
                color = if (isLight) Color.Black else Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
                lineHeight = 34.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Select your preferred language to customize your experience.\nअपनी पसंदीदा भाषा का चयन करें।",
                color = if (isLight) Color(0xFF444444) else Color.LightGray,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp),
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Options inside a premium GlassCard
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 24.dp,
                glowing = true
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.padding(8.dp)
                ) {
                    // English Option
                    LanguageOptionRow(
                        title = "English",
                        subtitle = "System Default",
                        isSelected = selectedLang == "en",
                        onClick = { selectedLang = "en" }
                    )

                    // Hindi Option
                    LanguageOptionRow(
                        title = "हिन्दी",
                        subtitle = "संस्कृत / देवनागरी लिपि",
                        isSelected = selectedLang == "hi",
                        onClick = { selectedLang = "hi" }
                    )
                }
            }

            Spacer(modifier = Modifier.height(36.dp))

            // Confirm Button
            GlassButton(
                text = if (selectedLang == "hi") "सुरक्षित करें (Save)" else "Confirm & Save",
                onClick = { onLanguageSelected(selectedLang) },
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(56.dp)
            )
        }
    }
}

@Composable
fun LanguageOptionRow(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val isLight = LocalIsLightTheme.current
    val borderColor = if (isSelected) ElectricBlue else if (isLight) Color.Black.copy(alpha = 0.1f) else Color.White.copy(alpha = 0.1f)
    val backgroundAlpha = if (isSelected) 0.15f else 0.05f
    val backgroundColor = if (isSelected) ElectricBlue else if (isLight) Color.Black else Color.White

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(backgroundColor.copy(alpha = backgroundAlpha))
            .border(1.5.dp, borderColor, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = title,
                color = if (isLight) Color.Black else Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = if (isSelected) ElectricBlue.copy(alpha = 0.8f) else Color.Gray,
                fontSize = 11.sp
            )
        }

        if (isSelected) {
            Icon(
                imageVector = Icons.Rounded.CheckCircle,
                contentDescription = "Selected",
                tint = ElectricBlue,
                modifier = Modifier.size(24.dp)
            )
        } else {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .border(2.dp, Color.Gray.copy(alpha = 0.5f), CircleShape)
            )
        }
    }
}
