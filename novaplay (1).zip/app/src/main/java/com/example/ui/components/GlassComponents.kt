package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.material3.LocalContentColor
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GlassWhite
import com.example.ui.theme.GlassWhiteBorder
import com.example.ui.theme.LocalIsLightTheme
import com.example.ui.theme.RoyalPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun Icon(
    imageVector: ImageVector,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current
) {
    val isLight = LocalIsLightTheme.current
    val effectiveTint = if (isLight) {
        if (tint == Color.Unspecified) {
            Color.Black
        } else if (tint == Color.White || tint == Color(0xFFFFFFFF) || (tint.red > 0.8f && tint.green > 0.8f && tint.blue > 0.8f && tint.alpha > 0.5f)) {
            Color.Black
        } else if (tint == Color.White.copy(alpha = 0.8f) || tint == Color.White.copy(alpha = 0.7f) || tint == Color.White.copy(alpha = 0.9f)) {
            Color.Black.copy(alpha = tint.alpha)
        } else if (tint == Color.LightGray) {
            Color(0xFF475569)
        } else {
            tint
        }
    } else {
        tint
    }
    androidx.compose.material3.Icon(
        imageVector = imageVector,
        contentDescription = contentDescription,
        modifier = modifier,
        tint = effectiveTint
    )
}

@Composable
fun Icon(
    painter: Painter,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current
) {
    val isLight = LocalIsLightTheme.current
    val effectiveTint = if (isLight) {
        if (tint == Color.Unspecified) {
            Color.Black
        } else if (tint == Color.White || tint == Color(0xFFFFFFFF) || (tint.red > 0.8f && tint.green > 0.8f && tint.blue > 0.8f && tint.alpha > 0.5f)) {
            Color.Black
        } else if (tint == Color.White.copy(alpha = 0.8f) || tint == Color.White.copy(alpha = 0.7f) || tint == Color.White.copy(alpha = 0.9f)) {
            Color.Black.copy(alpha = tint.alpha)
        } else if (tint == Color.LightGray) {
            Color(0xFF475569)
        } else {
            tint
        }
    } else {
        tint
    }
    androidx.compose.material3.Icon(
        painter = painter,
        contentDescription = contentDescription,
        modifier = modifier,
        tint = effectiveTint
    )
}

@Composable
fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    onTextLayout: (TextLayoutResult) -> Unit = {},
    style: TextStyle = LocalTextStyle.current
) {
    val isLight = LocalIsLightTheme.current
    val effectiveColor = if (isLight) {
        if (color == Color.Unspecified || color == Color.White || color == TextPrimary || color == Color(0xFFFFFFFF)) {
            Color.Black
        } else if (color == Color.LightGray || color == TextSecondary || color == Color(0xFF9E9E9E) || color == Color.Gray) {
            Color(0xFF333333)
        } else if (color.red > 0.8f && color.green > 0.8f && color.blue > 0.8f) {
            Color.Black.copy(alpha = color.alpha)
        } else {
            color
        }
    } else {
        color
    }

    androidx.compose.material3.Text(
        text = text,
        modifier = modifier,
        color = effectiveColor,
        fontSize = fontSize,
        fontStyle = fontStyle,
        fontWeight = fontWeight,
        fontFamily = fontFamily,
        letterSpacing = letterSpacing,
        textDecoration = textDecoration,
        textAlign = textAlign,
        lineHeight = lineHeight,
        overflow = overflow,
        softWrap = softWrap,
        maxLines = maxLines,
        minLines = minLines,
        onTextLayout = onTextLayout,
        style = style
    )
}

@Composable
fun Text(
    text: androidx.compose.ui.text.AnnotatedString,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    inlineContent: Map<String, androidx.compose.foundation.text.InlineTextContent> = mapOf(),
    onTextLayout: (TextLayoutResult) -> Unit = {},
    style: TextStyle = LocalTextStyle.current
) {
    val isLight = LocalIsLightTheme.current
    val effectiveColor = if (isLight) {
        if (color == Color.Unspecified || color == Color.White || color == TextPrimary || color == Color(0xFFFFFFFF)) {
            Color.Black
        } else if (color == Color.LightGray || color == TextSecondary || color == Color(0xFF9E9E9E) || color == Color.Gray) {
            Color(0xFF333333)
        } else if (color.red > 0.8f && color.green > 0.8f && color.blue > 0.8f) {
            Color.Black.copy(alpha = color.alpha)
        } else {
            color
        }
    } else {
        color
    }

    androidx.compose.material3.Text(
        text = text,
        modifier = modifier,
        color = effectiveColor,
        fontSize = fontSize,
        fontStyle = fontStyle,
        fontWeight = fontWeight,
        fontFamily = fontFamily,
        letterSpacing = letterSpacing,
        textDecoration = textDecoration,
        textAlign = textAlign,
        lineHeight = lineHeight,
        overflow = overflow,
        softWrap = softWrap,
        maxLines = maxLines,
        minLines = minLines,
        inlineContent = inlineContent,
        onTextLayout = onTextLayout,
        style = style
    )
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 24.dp,
    borderWidth: Dp = 1.dp,
    glowing: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    val isLight = LocalIsLightTheme.current
    val scaleSource = remember { MutableInteractionSource() }
    val isPressed by scaleSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.96f else 1.0f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "PressScale"
    )

    Box(
        modifier = modifier
            .shadow(
                elevation = if (glowing) 16.dp else 4.dp,
                shape = RoundedCornerShape(cornerRadius),
                clip = false,
                ambientColor = if (glowing) ElectricBlue else Color.Black,
                spotColor = if (glowing) RoyalPurple else Color.Black
            )
            .border(
                width = borderWidth,
                brush = Brush.linearGradient(
                    colors = if (isLight) {
                        listOf(
                            Color.Black.copy(alpha = 0.12f),
                            Color.Black.copy(alpha = 0.04f),
                            RoyalPurple.copy(alpha = 0.15f)
                        )
                    } else {
                        listOf(
                            GlassWhiteBorder,
                            Color.White.copy(alpha = 0.05f),
                            RoyalPurple.copy(alpha = 0.15f)
                        )
                    }
                ),
                shape = RoundedCornerShape(cornerRadius)
            )
            .clip(RoundedCornerShape(cornerRadius))
            .background(
                brush = Brush.linearGradient(
                    colors = if (isLight) {
                        listOf(
                            Color.White.copy(alpha = 0.85f),
                            Color.White.copy(alpha = 0.65f)
                        )
                    } else {
                        listOf(
                            Color.White.copy(alpha = 0.08f),
                            Color.White.copy(alpha = 0.02f)
                        )
                    }
                )
            )
            .background(if (isLight) Color.White.copy(alpha = 0.60f) else GlassWhite)
            .padding(16.dp)
    ) {
        content()
    }
}

@Composable
fun GlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 20.dp,
    text: String,
    icon: @Composable (() -> Unit)? = null,
    glowColor: Color = ElectricBlue
) {
    val isLight = LocalIsLightTheme.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1.0f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "ButtonPress"
    )

    Box(
        modifier = modifier
            .shadow(
                elevation = if (isPressed) 8.dp else 12.dp,
                shape = RoundedCornerShape(cornerRadius),
                ambientColor = glowColor,
                spotColor = RoyalPurple
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        if (isLight) Color.Black.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.25f),
                        glowColor.copy(alpha = 0.4f)
                    )
                ),
                shape = RoundedCornerShape(cornerRadius)
            )
            .clip(RoundedCornerShape(cornerRadius))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        if (isLight) Color.Black.copy(alpha = 0.05f) else Color.White.copy(alpha = 0.12f),
                        glowColor.copy(alpha = 0.18f)
                    )
                )
            )
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(color = glowColor),
                onClick = onClick
            )
            .padding(horizontal = 24.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                icon()
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                color = if (isLight) Color.Black else Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                style = TextStyle(
                    shadow = if (isLight) null else Shadow(
                        color = glowColor.copy(alpha = 0.6f),
                        offset = Offset(0f, 0f),
                        blurRadius = 8f
                    )
                )
            )
        }
    }
}

@Composable
fun GlowText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    glowColor: Color = ElectricBlue,
    fontSize: androidx.compose.ui.unit.TextUnit = 16.sp,
    fontWeight: FontWeight = FontWeight.Normal,
    style: TextStyle = TextStyle.Default
) {
    val isLight = LocalIsLightTheme.current
    val effectiveColor = if (isLight && (color == Color.White || color == TextPrimary || color == Color(0xFFFFFFFF) || (color.red > 0.8f && color.green > 0.8f && color.blue > 0.8f))) {
        Color.Black
    } else {
        color
    }

    Text(
        text = text,
        modifier = modifier,
        color = effectiveColor,
        fontSize = fontSize,
        fontWeight = fontWeight,
        style = style.copy(
            shadow = if (isLight) null else Shadow(
                color = glowColor.copy(alpha = 0.8f),
                offset = Offset(0f, 0f),
                blurRadius = 12f
            )
        )
    )
}


fun Modifier.springPress(
    onPress: () -> Unit = {},
    onRelease: () -> Unit = {}
) = pointerInput(Unit) {
    detectTapGestures(
        onPress = {
            onPress()
            try {
                awaitRelease()
            } finally {
                onRelease()
            }
        }
    )
}
