package com.example.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun StartAppBannerAd(
    modifier: Modifier = Modifier
) {
    // Start.io banner ads removed
}

