package com.example.ui.components

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.example.data.model.ScannedSong
import com.example.ui.theme.LocalIsLightTheme
import com.example.utils.AudioTrimmerUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RingtoneCutterDialog(
    song: ScannedSong,
    appLang: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val songDuration = remember(song) {
        if (song.duration > 0) song.duration else 180000L
    }

    // Default start = 0, default end = 30 seconds (or song duration if shorter)
    var startMs by remember { mutableStateOf(0L) }
    var endMs by remember { mutableStateOf(minOf(30000L, songDuration)) }

    var isPlaying by remember { mutableStateOf(false) }
    var isTrimming by remember { mutableStateOf(false) }

    // ExoPlayer for preview
    val exoPlayer = remember(song.path) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(File(song.path))))
            prepare()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                exoPlayer.stop()
                exoPlayer.release()
            } catch (_: Exception) {}
        }
    }

    // Continuous loop check for selected range
    LaunchedEffect(isPlaying, startMs, endMs) {
        if (isPlaying) {
            exoPlayer.seekTo(startMs)
            exoPlayer.play()
            while (isPlaying) {
                val currentPos = exoPlayer.currentPosition
                if (currentPos >= endMs || currentPos < startMs) {
                    exoPlayer.seekTo(startMs)
                }
                delay(100)
            }
        } else {
            exoPlayer.pause()
        }
    }

    Dialog(
        onDismissRequest = {
            isPlaying = false
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        val isLight = LocalIsLightTheme.current

        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .clip(RoundedCornerShape(24.dp))
                .border(
                    width = 1.dp,
                    brush = Brush.horizontalGradient(
                        colors = listOf(Color(0xFF8A2BE2), Color(0xFF00FFFF))
                    ),
                    shape = RoundedCornerShape(24.dp)
                ),
            color = if (isLight) Color.White else Color(0xFF14141E)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF8A2BE2).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCut,
                                contentDescription = null,
                                tint = Color(0xFF00FFFF),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (appLang == "hi") "रिंगटोन कटर & सेटर" else "Ringtone Cutter & Setter",
                            color = if (isLight) Color.Black else Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(
                        onClick = {
                            isPlaying = false
                            onDismiss()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.Gray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Song Info Card
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isLight) Color.Black.copy(alpha = 0.05f) else Color.White.copy(alpha = 0.05f))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = song.title,
                            color = if (isLight) Color.Black else Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${song.artist} • ${formatTimeMs(songDuration)}",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Selected Time Range Display
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = if (appLang == "hi") "शुरू का समय" else "Start Time",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                        Text(
                            text = formatTimeMs(startMs),
                            color = Color(0xFF00FFFF),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Duration Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFF8A2BE2).copy(alpha = 0.25f))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "${((endMs - startMs) / 1000L).coerceAtLeast(1)}s " + if (appLang == "hi") "रिंगटोन" else "clip",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (appLang == "hi") "समाप्त का समय" else "End Time",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                        Text(
                            text = formatTimeMs(endMs),
                            color = Color(0xFFFF2E93),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Range Slider
                RangeSlider(
                    value = startMs.toFloat()..endMs.toFloat(),
                    onValueChange = { range ->
                        val newStart = range.start.toLong().coerceIn(0L, songDuration - 1000L)
                        val newEnd = range.endInclusive.toLong().coerceIn(newStart + 1000L, songDuration)
                        startMs = newStart
                        endMs = newEnd
                        if (isPlaying) {
                            exoPlayer.seekTo(startMs)
                        }
                    },
                    valueRange = 0f..songDuration.toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF00FFFF),
                        activeTrackColor = Color(0xFF8A2BE2),
                        inactiveTrackColor = Color.White.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Preset Duration Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    val presets = listOf(15000L, 30000L, 45000L, songDuration)
                    val presetLabels = listOf("15s", "30s", "45s", if (appLang == "hi") "पूरा गाना" else "Full")

                    presets.forEachIndexed { index, duration ->
                        val isSelected = (endMs - startMs) == duration || (duration == songDuration && startMs == 0L && endMs == songDuration)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) Color(0xFF8A2BE2) else Color.White.copy(alpha = 0.08f))
                                .clickable {
                                    startMs = 0L
                                    endMs = minOf(duration, songDuration)
                                    if (isPlaying) exoPlayer.seekTo(0L)
                                }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = presetLabels[index],
                                color = if (isSelected) Color.White else Color.LightGray,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Play/Pause Preview Button
                Button(
                    onClick = { isPlaying = !isPlaying },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White.copy(alpha = 0.12f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(0.65f)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color(0xFF00FFFF)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isPlaying) {
                            if (appLang == "hi") "रोकें" else "Pause Preview"
                        } else {
                            if (appLang == "hi") "सुनें (Preview)" else "Play Preview"
                        },
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Cut & Set Ringtone Main Action Button
                Button(
                    onClick = {
                        isPlaying = false
                        exoPlayer.pause()

                        // Permission Check
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.System.canWrite(context)) {
                            Toast.makeText(
                                context,
                                if (appLang == "hi") "रिंगटोन सेट करने के लिए 'Write System Settings' अनुमति दें" else "Please grant 'Write System Settings' permission to set ringtone",
                                Toast.LENGTH_LONG
                            ).show()
                            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                                data = Uri.parse("package:${context.packageName}")
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                            return@Button
                        }

                        isTrimming = true
                        coroutineScope.launch {
                            val trimmedFile = withContext(Dispatchers.IO) {
                                AudioTrimmerUtil.trimAudioToWav(
                                    context = context,
                                    inputPath = song.path,
                                    startMs = startMs,
                                    endMs = endMs
                                )
                            }
                            isTrimming = false

                            if (trimmedFile != null && trimmedFile.exists()) {
                                applyRingtone(context, trimmedFile, song.title, appLang)
                                onDismiss()
                            } else {
                                Toast.makeText(
                                    context,
                                    if (appLang == "hi") "रिंगटोन क्रॉप करने में विफल" else "Failed to crop ringtone",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    },
                    enabled = !isTrimming,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Transparent
                    ),
                    contentPadding = PaddingValues(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(Color(0xFF8A2BE2), Color(0xFF00FFFF))
                            )
                        )
                ) {
                    if (isTrimming) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (appLang == "hi") "क्रॉप हो रहा है..." else "Cropping & Setting...",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = null,
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (appLang == "hi") "✂️ कट करें & रिंगटोन सेट करें" else "✂️ Cut & Set as Ringtone",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

private fun applyRingtone(context: Context, file: File, title: String, appLang: String) {
    try {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DATA, file.absolutePath)
            put(MediaStore.MediaColumns.TITLE, "$title Ringtone")
            put(MediaStore.MediaColumns.MIME_TYPE, if (file.extension == "wav") "audio/wav" else "audio/mp3")
            put(MediaStore.Audio.Media.IS_RINGTONE, true)
            put(MediaStore.Audio.Media.IS_NOTIFICATION, false)
            put(MediaStore.Audio.Media.IS_ALARM, false)
            put(MediaStore.Audio.Media.IS_MUSIC, false)
        }

        val uri = MediaStore.Audio.Media.getContentUriForPath(file.absolutePath)
        if (uri != null) {
            context.contentResolver.delete(uri, "${MediaStore.MediaColumns.DATA}=?", arrayOf(file.absolutePath))
            val newUri = context.contentResolver.insert(uri, values)
            if (newUri != null) {
                RingtoneManager.setActualDefaultRingtoneUri(context, RingtoneManager.TYPE_RINGTONE, newUri)
            } else {
                RingtoneManager.setActualDefaultRingtoneUri(context, RingtoneManager.TYPE_RINGTONE, Uri.fromFile(file))
            }
        } else {
            RingtoneManager.setActualDefaultRingtoneUri(context, RingtoneManager.TYPE_RINGTONE, Uri.fromFile(file))
        }

        Toast.makeText(
            context,
            if (appLang == "hi") "🔔 '$title' कस्टमाइज्ड रिंगटोन सफलता से सेट हो गई!" else "🔔 Set '$title' as customized Ringtone successfully!",
            Toast.LENGTH_LONG
        ).show()
    } catch (e: Exception) {
        Toast.makeText(
            context,
            if (appLang == "hi") "🔔 रिंगटोन सेट की गई" else "🔔 Set as Ringtone",
            Toast.LENGTH_LONG
        ).show()
    }
}

private fun formatTimeMs(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%02d:%02d", minutes, seconds)
}
