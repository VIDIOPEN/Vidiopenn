package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.model.MediaEntity
import com.example.data.model.VaultEntity
import com.example.data.model.WatchHistoryEntity
import com.example.data.model.VideoBookmarkEntity
import com.example.data.model.VideoPlaylistEntity
import com.example.data.model.PlaylistVideoEntity
import com.example.data.model.QueueVideoEntity
import com.example.data.model.CapturedFrameEntity
import com.example.data.model.RecycleBinEntity
import com.example.utils.SmartSearchEngine
import com.example.data.repository.MediaRepository
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.Player
import androidx.media3.common.MediaItem

import kotlinx.coroutines.withContext
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.os.Build
import android.content.ContentValues
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers

private val android.content.Context.videoPrefsDataStore: DataStore<Preferences> by preferencesDataStore(name = "video_player_prefs")

sealed class MediaConversionState {
    object Idle : MediaConversionState()
    data class Converting(
        val progress: Float, 
        val statusMessage: String,
        val videoTitle: String? = null,
        val thumbnailUrl: String? = null
    ) : MediaConversionState()
    data class Success(
        val filePath: String, 
        val fileName: String,
        val videoTitle: String? = null,
        val thumbnailUrl: String? = null
    ) : MediaConversionState()
    data class Error(val errorMessage: String) : MediaConversionState()
}

class MediaViewModel(
    application: Application,
    private val repository: MediaRepository
) : AndroidViewModel(application) {

    private val videoPrefs = application.getSharedPreferences("video_player_prefs", android.content.Context.MODE_PRIVATE)

    fun saveLastWatchedVideo(mediaId: String, position: Long, isActive: Boolean) {
        videoPrefs.edit()
            .putString("last_watched_video_id", mediaId)
            .putLong("last_watched_position", position)
            .putBoolean("video_player_active", isActive)
            .apply()
    }

    fun clearLastWatchedVideo() {
        videoPrefs.edit()
            .putBoolean("video_player_active", false)
            .apply()
    }

    fun checkForAutoResume() {
        val lastId = videoPrefs.getString("last_watched_video_id", null)
        val isActive = videoPrefs.getBoolean("video_player_active", false)
        if (isActive && !lastId.isNullOrEmpty()) {
            viewModelScope.launch {
                val media = repository.getMediaById(lastId)
                if (media != null) {
                    val lastPos = videoPrefs.getLong("last_watched_position", media.lastPlayedPosition)
                    val mediaToPlay = media.copy(lastPlayedPosition = lastPos)
                    playMedia(mediaToPlay)
                }
            }
        }
    }

    // Video to MP3 Conversion State Flow
    private val _conversionState = MutableStateFlow<MediaConversionState>(MediaConversionState.Idle)
    val conversionState: StateFlow<MediaConversionState> = _conversionState.asStateFlow()

    fun resetConversionState() {
        _conversionState.value = MediaConversionState.Idle
    }

    // Search query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Active playing media (video or audio)
    private val _currentPlayingMedia = MutableStateFlow<MediaEntity?>(null)
    val currentPlayingMedia: StateFlow<MediaEntity?> = _currentPlayingMedia.asStateFlow()

    // All media lists
    val allMedia: StateFlow<List<MediaEntity>> = repository.allMedia
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favorites: StateFlow<List<MediaEntity>> = repository.favorites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val continueWatching: StateFlow<List<MediaEntity>> = repository.continueWatching
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vaultItems: StateFlow<List<VaultEntity>> = repository.vaultItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val watchHistory: StateFlow<List<WatchHistoryEntity>> = repository.watchHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pinnedFolderPaths: StateFlow<List<String>> = repository.pinnedFolderPaths
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val capturedFrames: StateFlow<List<CapturedFrameEntity>> = repository.getAllCapturedFrames()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered media by query with SmartSearchEngine ranking
    val filteredMedia = combine(allMedia, _searchQuery) { media, query ->
        if (query.isBlank()) {
            media
        } else {
            media.mapNotNull { item ->
                SmartSearchEngine.scoreMediaEntity(item, query)?.let { scored ->
                    item to scored.score
                }
            }.sortedByDescending { it.second }.map { it.first }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Preferences keys
    private val KEY_APP_LANGUAGE = stringPreferencesKey("app_language")
    private val KEY_AUTO_PLAY = booleanPreferencesKey("auto_play_enabled")
    private val KEY_REPEAT_PLAYLIST = booleanPreferencesKey("repeat_playlist_enabled")
    private val KEY_SHUFFLE_PLAYLIST = booleanPreferencesKey("shuffle_playlist_enabled")
    private val KEY_FLOATING_SIZE = androidx.datastore.preferences.core.stringPreferencesKey("floating_size")
    private val KEY_FLOATING_TRANSPARENCY = androidx.datastore.preferences.core.floatPreferencesKey("floating_transparency")
    private val KEY_AUTO_ENTER_PIP = androidx.datastore.preferences.core.booleanPreferencesKey("auto_enter_pip")
    private val KEY_CUSTOM_BACKGROUND_URI = stringPreferencesKey("custom_background_uri")
    private val KEY_SELECTED_THEME_ID = stringPreferencesKey("selected_theme_id")
    private val KEY_CUSTOM_THEME_SCALE_TYPE = stringPreferencesKey("custom_theme_scale_type")
    private val KEY_CUSTOM_THEME_ZOOM = floatPreferencesKey("custom_theme_zoom")
    private val KEY_CUSTOM_THEME_OPACITY = floatPreferencesKey("custom_theme_opacity")
    private val KEY_CUSTOM_THEME_ALIGNMENT = stringPreferencesKey("custom_theme_alignment")

    // Subtitle Custom Styling Keys
    private val KEY_SUBTITLE_ENABLED = booleanPreferencesKey("sub_enabled")
    private val KEY_SUBTITLE_SIZE = floatPreferencesKey("sub_size")
    private val KEY_SUBTITLE_DELAY = longPreferencesKey("sub_delay")
    private val KEY_SUBTITLE_FONT_FAMILY = stringPreferencesKey("sub_font_family")
    private val KEY_SUBTITLE_FONT_WEIGHT = stringPreferencesKey("sub_font_weight")
    private val KEY_SUBTITLE_TEXT_COLOR = stringPreferencesKey("sub_text_color")
    private val KEY_SUBTITLE_BG_COLOR = stringPreferencesKey("sub_bg_color")
    private val KEY_SUBTITLE_BG_OPACITY = floatPreferencesKey("sub_bg_opacity")
    private val KEY_SUBTITLE_OUTLINE_COLOR = stringPreferencesKey("sub_outline_color")
    private val KEY_SUBTITLE_OUTLINE_WIDTH = floatPreferencesKey("sub_outline_width")
    private val KEY_SUBTITLE_BOTTOM_PADDING = floatPreferencesKey("sub_bottom_padding")
    private val KEY_SUBTITLE_POSITION = stringPreferencesKey("sub_position")

    fun lastSubtitleKey(videoId: String) = stringPreferencesKey("last_sub_$videoId")

    // Preference Flows
    val autoPlayEnabled: StateFlow<Boolean> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_AUTO_PLAY] ?: true }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val repeatPlaylistEnabled: StateFlow<Boolean> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_REPEAT_PLAYLIST] ?: false }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val shufflePlaylistEnabled: StateFlow<Boolean> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_SHUFFLE_PLAYLIST] ?: false }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val floatingSize: StateFlow<String> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_FLOATING_SIZE] ?: "Medium" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Medium")

    val floatingTransparency: StateFlow<Float> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_FLOATING_TRANSPARENCY] ?: 0.0f }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0f)

    val autoEnterPip: StateFlow<Boolean> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_AUTO_ENTER_PIP] ?: false }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val appLanguage: StateFlow<String> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_APP_LANGUAGE] ?: "" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    fun setAppLanguage(lang: String) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_APP_LANGUAGE] = lang
            }
        }
    }

    val customBackgroundUri: StateFlow<String> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_CUSTOM_BACKGROUND_URI] ?: "" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    fun setCustomBackgroundUri(uri: String) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_CUSTOM_BACKGROUND_URI] = uri
            }
        }
    }

    val selectedThemeId: StateFlow<String> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_SELECTED_THEME_ID] ?: "dark_color" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "dark_color")

    fun setSelectedThemeId(themeId: String) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_SELECTED_THEME_ID] = themeId
            }
        }
    }

    val customThemeScaleType: StateFlow<String> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_CUSTOM_THEME_SCALE_TYPE] ?: "CROP" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "CROP")

    fun setCustomThemeScaleType(type: String) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_CUSTOM_THEME_SCALE_TYPE] = type
            }
        }
    }

    val customThemeZoom: StateFlow<Float> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_CUSTOM_THEME_ZOOM] ?: 1.0f }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1.0f)

    fun setCustomThemeZoom(zoom: Float) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_CUSTOM_THEME_ZOOM] = zoom
            }
        }
    }

    val customThemeOpacity: StateFlow<Float> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_CUSTOM_THEME_OPACITY] ?: 0.55f }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.55f)

    fun setCustomThemeOpacity(opacity: Float) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_CUSTOM_THEME_OPACITY] = opacity
            }
        }
    }

    val customThemeAlignment: StateFlow<String> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_CUSTOM_THEME_ALIGNMENT] ?: "CENTER" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "CENTER")

    fun setCustomThemeAlignment(alignment: String) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_CUSTOM_THEME_ALIGNMENT] = alignment
            }
        }
    }

    fun resetCustomThemeSettings() {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_CUSTOM_THEME_SCALE_TYPE] = "CROP"
                prefs[KEY_CUSTOM_THEME_ZOOM] = 1.0f
                prefs[KEY_CUSTOM_THEME_OPACITY] = 0.55f
                prefs[KEY_CUSTOM_THEME_ALIGNMENT] = "CENTER"
            }
        }
    }

    // Subtitle Custom Styling Flows
    val subtitleEnabled: StateFlow<Boolean> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_SUBTITLE_ENABLED] ?: true }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val subtitleSize: StateFlow<Float> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_SUBTITLE_SIZE] ?: 18f }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 18f)

    val subtitleDelay: StateFlow<Long> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_SUBTITLE_DELAY] ?: 0L }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val subtitleFontFamily: StateFlow<String> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_SUBTITLE_FONT_FAMILY] ?: "Sans-serif" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Sans-serif")

    val subtitleFontWeight: StateFlow<String> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_SUBTITLE_FONT_WEIGHT] ?: "Normal" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Normal")

    val subtitleTextColor: StateFlow<String> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_SUBTITLE_TEXT_COLOR] ?: "#FFFFFF" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "#FFFFFF")

    val subtitleBgColor: StateFlow<String> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_SUBTITLE_BG_COLOR] ?: "#000000" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "#000000")

    val subtitleBgOpacity: StateFlow<Float> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_SUBTITLE_BG_OPACITY] ?: 0.5f }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.5f)

    val subtitleOutlineColor: StateFlow<String> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_SUBTITLE_OUTLINE_COLOR] ?: "#000000" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "#000000")

    val subtitleOutlineWidth: StateFlow<Float> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_SUBTITLE_OUTLINE_WIDTH] ?: 2.0f }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 2.0f)

    val subtitleBottomPadding: StateFlow<Float> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_SUBTITLE_BOTTOM_PADDING] ?: 24.0f }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 24.0f)

    val subtitlePosition: StateFlow<String> = getApplication<Application>().videoPrefsDataStore.data
        .map { it[KEY_SUBTITLE_POSITION] ?: "Bottom" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Bottom")

    private val _activeCustomSubtitlePath = MutableStateFlow<String?>(null)
    val activeCustomSubtitlePath: StateFlow<String?> = _activeCustomSubtitlePath.asStateFlow()

    // Floating Window Active State & Lock State
    private val _isFloatingMode = MutableStateFlow(false)
    val isFloatingMode: StateFlow<Boolean> = _isFloatingMode.asStateFlow()

    private val _floatingModeLock = MutableStateFlow(false)
    val floatingModeLock: StateFlow<Boolean> = _floatingModeLock.asStateFlow()

    private val _isInPictureInPictureMode = MutableStateFlow(false)
    val isInPictureInPictureMode: StateFlow<Boolean> = _isInPictureInPictureMode.asStateFlow()

    // Current playing playlist track management
    private val _currentPlayingPlaylistId = MutableStateFlow<Long?>(null)
    val currentPlayingPlaylistId: StateFlow<Long?> = _currentPlayingPlaylistId.asStateFlow()

    private val _currentPlayingPlaylistVideos = MutableStateFlow<List<PlaylistVideoEntity>>(emptyList())
    val currentPlayingPlaylistVideos: StateFlow<List<PlaylistVideoEntity>> = _currentPlayingPlaylistVideos.asStateFlow()

    // Playlist Data Flows
    val allPlaylists: StateFlow<List<VideoPlaylistEntity>> = repository.allPlaylists
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Queue Data Flows
    val queueVideos: StateFlow<List<QueueVideoEntity>> = repository.queueVideos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Player States
    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _isLocked = MutableStateFlow(false)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    private val _equalizerPreset = MutableStateFlow("Normal")
    val equalizerPreset: StateFlow<String> = _equalizerPreset.asStateFlow()

    private val _selectedAudioTrack = MutableStateFlow("English [Stereo]")
    val selectedAudioTrack: StateFlow<String> = _selectedAudioTrack.asStateFlow()

    private val _selectedSubtitleTrack = MutableStateFlow("None")
    val selectedSubtitleTrack: StateFlow<String> = _selectedSubtitleTrack.asStateFlow()

    // A-B Repeat States
    private val _abRepeatActive = MutableStateFlow(false)
    val abRepeatActive: StateFlow<Boolean> = _abRepeatActive.asStateFlow()

    private val _abPointA = MutableStateFlow<Long?>(null)
    val abPointA: StateFlow<Long?> = _abPointA.asStateFlow()

    private val _abPointB = MutableStateFlow<Long?>(null)
    val abPointB: StateFlow<Long?> = _abPointB.asStateFlow()

    private val _loopCount = MutableStateFlow(0)
    val loopCount: StateFlow<Int> = _loopCount.asStateFlow()

    // Precision Seek States
    private val _precisionSeekEnabled = MutableStateFlow(false)
    val precisionSeekEnabled: StateFlow<Boolean> = _precisionSeekEnabled.asStateFlow()

    private val previewCache = java.util.concurrent.ConcurrentHashMap<Long, Bitmap>()

    // Sleep Timer
    private val _sleepTimerMinutes = MutableStateFlow<Int?>(null)
    val sleepTimerMinutes: StateFlow<Int?> = _sleepTimerMinutes.asStateFlow()

    private val _sleepTimerRemaining = MutableStateFlow(0)
    val sleepTimerRemaining: StateFlow<Int> = _sleepTimerRemaining.asStateFlow()

    private var sleepTimerJob: Job? = null

    // Private Vault Security
    private val _vaultPin = MutableStateFlow<String?>(null)
    val vaultPin: StateFlow<String?> = _vaultPin.asStateFlow()

    private val _isVaultUnlocked = MutableStateFlow(false)
    val isVaultUnlocked: StateFlow<Boolean> = _isVaultUnlocked.asStateFlow()

    init {
        // Load configurations
        viewModelScope.launch {
            _vaultPin.value = repository.getConfig("vault_pin")
            val savedPreset = repository.getConfig("eq_preset") ?: "Normal"
            _equalizerPreset.value = savedPreset
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun playMedia(media: MediaEntity) {
        resetAbRepeat()
        setPrecisionSeekEnabled(false)
        clearPreviewCache()
        viewModelScope.launch {
            // Ensure media is in database
            val existing = repository.getMediaById(media.id)
            val mediaToPlay = existing?.copy(
                lastPlayedPosition = if (existing.lastPlayedPosition > 0L) existing.lastPlayedPosition else media.lastPlayedPosition
            ) ?: media

            if (existing == null) {
                repository.insertMedia(media)
            }
            if (mediaToPlay.lastPlayedPosition == 0L) {
                repository.updatePlaybackPosition(mediaToPlay.id, 1L)
            }

            _currentPlayingMedia.value = mediaToPlay
            saveLastWatchedVideo(mediaToPlay.id, mediaToPlay.lastPlayedPosition, true)

            // Add to Watch History
            repository.insertWatchHistory(
                WatchHistoryEntity(
                    id = mediaToPlay.id,
                    title = mediaToPlay.title,
                    url = mediaToPlay.url,
                    duration = mediaToPlay.duration,
                    artist = mediaToPlay.artist,
                    thumbnailUrl = mediaToPlay.thumbnailUrl,
                    category = mediaToPlay.category,
                    watchedTimestamp = System.currentTimeMillis()
                )
            )
        }
    }

    private var sharedExoPlayer: ExoPlayer? = null

    fun getOrCreatePlayer(context: android.content.Context): ExoPlayer {
        if (sharedExoPlayer == null) {
            val renderersFactory = androidx.media3.exoplayer.DefaultRenderersFactory(context).apply {
                setEnableDecoderFallback(true)
                setExtensionRendererMode(androidx.media3.exoplayer.DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
                setAllowedVideoJoiningTimeMs(5000L)
            }

            val trackSelector = androidx.media3.exoplayer.trackselection.DefaultTrackSelector(context).apply {
                parameters = buildUponParameters()
                    .setMaxVideoSize(7680, 4320) // 8K Ultra HD resolution support
                    .setMaxVideoFrameRate(120) // Up to 120 FPS high frame rate support
                    .setMaxVideoBitrate(250_000_000) // 250 Mbps ultra-high bitrate limit
                    .setAllowVideoNonSeamlessAdaptiveness(true)
                    .setAllowVideoMixedMimeTypeAdaptiveness(true)
                    .setAllowVideoMixedDecoderSupportAdaptiveness(true)
                    .setExceedVideoConstraintsIfNecessary(true)
                    .setExceedRendererCapabilitiesIfNecessary(true)
                    .build()
            }

            val loadControl = androidx.media3.exoplayer.DefaultLoadControl.Builder()
                .setBufferDurationsMs(
                    30_000,  // Min buffer 30s
                    120_000, // Max buffer 120s
                    500,     // Buffer for playback start 0.5s (INSTANT START)
                    1_500    // Buffer after rebuffer 1.5s
                )
                .setBackBuffer(15_000, true) // 15s back buffer for instant rewind without re-buffering
                .setPrioritizeTimeOverSizeThresholds(true)
                .setTargetBufferBytes(128 * 1024 * 1024) // 128 MB RAM buffer allocation for high bitrate 4K/8K frames
                .build()

            val audioAttributes = androidx.media3.common.AudioAttributes.Builder()
                .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MOVIE)
                .setUsage(androidx.media3.common.C.USAGE_MEDIA)
                .build()

            sharedExoPlayer = ExoPlayer.Builder(context)
                .setRenderersFactory(renderersFactory)
                .setTrackSelector(trackSelector)
                .setLoadControl(loadControl)
                .setAudioAttributes(audioAttributes, true)
                .setHandleAudioBecomingNoisy(true)
                .setSeekParameters(androidx.media3.exoplayer.SeekParameters.CLOSEST_SYNC)
                .build().apply {
                    playWhenReady = true
                    addListener(object : androidx.media3.common.Player.Listener {
                        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                            timber.log.Timber.e(error, "ExoPlayer playback error occurred: ${error.errorCodeName}")
                            // Auto-recover from transient decoder or network errors
                            val currentPos = currentPosition
                            val mediaItem = currentMediaItem
                            if (mediaItem != null) {
                                prepare()
                                seekTo(currentPos)
                                play()
                            }
                        }
                    })
                }
        }
        return sharedExoPlayer!!
    }

    fun releaseSharedPlayer() {
        com.example.service.VideoPlaybackService.stop(getApplication())
        sharedExoPlayer?.release()
        sharedExoPlayer = null
    }

    override fun onCleared() {
        super.onCleared()
        releaseSharedPlayer()
    }

    fun closePlayer() {
        com.example.service.VideoPlaybackService.stop(getApplication())
        resetAbRepeat()
        setPrecisionSeekEnabled(false)
        clearPreviewCache()
        _currentPlayingMedia.value = null
        sharedExoPlayer?.pause()
        sharedExoPlayer?.clearMediaItems()
        _isFloatingMode.value = false
        _floatingModeLock.value = false
        clearLastWatchedVideo()
    }

    fun toggleFavorite(id: String, isFavorite: Boolean) {
        viewModelScope.launch {
            repository.toggleFavorite(id, isFavorite)
        }
    }

    fun toggleFavorite(media: MediaEntity) {
        viewModelScope.launch {
            val existing = repository.getMediaById(media.id)
            if (existing == null) {
                repository.insertMedia(media.copy(isFavorite = true))
            } else {
                repository.toggleFavorite(media.id, !existing.isFavorite)
            }
        }
    }

    fun updatePlaybackPosition(id: String, position: Long) {
        viewModelScope.launch {
            repository.updatePlaybackPosition(id, position)
        }
    }

    fun clearWatchHistory() {
        viewModelScope.launch {
            repository.clearWatchHistory()
        }
    }

    fun deleteWatchHistoryById(id: String) {
        viewModelScope.launch {
            repository.deleteWatchHistoryById(id)
        }
    }

    fun pinFolder(folderPath: String) {
        viewModelScope.launch {
            repository.pinFolder(folderPath)
        }
    }

    fun unpinFolder(folderPath: String) {
        viewModelScope.launch {
            repository.unpinFolder(folderPath)
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
    }

    fun toggleLock() {
        _isLocked.value = !_isLocked.value
    }

    fun setEqualizerPreset(preset: String) {
        _equalizerPreset.value = preset
        viewModelScope.launch {
            repository.setConfig("eq_preset", preset)
        }
    }

    fun setAudioTrack(track: String) {
        _selectedAudioTrack.value = track
    }

    fun setSubtitleTrack(track: String) {
        _selectedSubtitleTrack.value = track
    }

    fun saveConfig(key: String, value: String) {
        viewModelScope.launch {
            repository.setConfig(key, value)
        }
    }

    // Sleep Timer Actions
    fun startSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        _sleepTimerMinutes.value = minutes
        _sleepTimerRemaining.value = minutes * 60

        sleepTimerJob = viewModelScope.launch {
            while (_sleepTimerRemaining.value > 0) {
                delay(1000)
                _sleepTimerRemaining.value -= 1
            }
            // Timer expired, stop playback
            _currentPlayingMedia.value = null
            _sleepTimerMinutes.value = null
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        _sleepTimerMinutes.value = null
        _sleepTimerRemaining.value = 0
    }

    // Vault Security Actions
    fun setVaultPin(pin: String) {
        viewModelScope.launch {
            repository.setConfig("vault_pin", pin)
            _vaultPin.value = pin
            _isVaultUnlocked.value = true
        }
    }

    fun verifyPin(pin: String): Boolean {
        val success = _vaultPin.value == pin
        if (success) {
            _isVaultUnlocked.value = true
        }
        return success
    }

    fun lockVault() {
        _isVaultUnlocked.value = false
    }

    fun hideMediaToVault(media: MediaEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val app = getApplication<Application>()
                val vaultDir = File(app.filesDir, "vidiopen_vault")
                if (!vaultDir.exists()) vaultDir.mkdirs()

                val type = if (media.category == "Music") "AUDIO" else "VIDEO"
                val secureFileName = "enc_${java.util.UUID.randomUUID()}"
                val secureDestFile = File(vaultDir, secureFileName)

                var success = false
                val origFile = File(media.url)

                if (origFile.exists()) {
                    success = com.example.utils.CryptoManager.encryptFile(origFile, secureDestFile)
                } else if (media.url.startsWith("content://")) {
                    try {
                        val uri = android.net.Uri.parse(media.url)
                        app.contentResolver.openInputStream(uri)?.use { input ->
                            success = com.example.utils.CryptoManager.encryptStream(input, secureDestFile)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }

                if (success && secureDestFile.exists() && secureDestFile.length() > 0L) {
                    val fileSize = if (origFile.exists()) origFile.length() else secureDestFile.length()
                    repository.insertVaultItem(
                        VaultEntity(
                            title = media.title,
                            path = secureDestFile.absolutePath,
                            type = type,
                            size = fileSize,
                            isFavorite = false,
                            addedDate = System.currentTimeMillis()
                        )
                    )

                    // Delete original physical file so it disappears from gallery & phone storage
                    if (origFile.exists()) {
                        origFile.delete()
                        try {
                            android.media.MediaScannerConnection.scanFile(
                                app,
                                arrayOf(origFile.absolutePath),
                                null,
                                null
                            )
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }

                    if (media.url.startsWith("content://")) {
                        try {
                            app.contentResolver.delete(android.net.Uri.parse(media.url), null, null)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }

                    // Delete from main media list
                    repository.deleteMedia(media.id)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun addLocalVideo(title: String, url: String, duration: Long) {
        viewModelScope.launch {
            val customId = "local_" + System.currentTimeMillis()
            repository.insertMedia(
                MediaEntity(
                    id = customId,
                    title = title,
                    url = url,
                    duration = duration,
                    artist = "Local Storage",
                    thumbnailUrl = null,
                    category = "Movies"
                )
            )
        }
    }

    fun deleteVaultItem(item: VaultEntity) {
        viewModelScope.launch {
            repository.deleteVaultItem(item.id)
            // Restore back to list as user unhides
            val category = if (item.type == "AUDIO") "Music" else "Movies"
            val restoredId = "restored_" + System.currentTimeMillis()
            repository.insertMedia(
                MediaEntity(
                    id = restoredId,
                    title = item.title,
                    url = item.path,
                    duration = 300000L, // Mock duration
                    artist = "Restored",
                    thumbnailUrl = null,
                    category = category
                )
            )
        }
    }

    // Bookmark Methods
    fun getBookmarksForVideo(videoId: String): Flow<List<VideoBookmarkEntity>> {
        return repository.getBookmarksForVideo(videoId)
    }

    fun addBookmark(videoId: String, videoName: String, timestampMs: Long, customName: String?, videoUrl: String) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val thumbnailPath = captureVideoThumbnailAtTime(videoUrl, timestampMs)
            val bookmark = VideoBookmarkEntity(
                videoId = videoId,
                videoName = videoName,
                timestampMs = timestampMs,
                bookmarkName = customName,
                thumbnailPath = thumbnailPath
            )
            repository.insertBookmark(bookmark)
        }
    }

    fun renameBookmark(id: Int, newName: String) {
        viewModelScope.launch {
            repository.renameBookmark(id, newName)
        }
    }

    fun deleteBookmark(id: Int) {
        viewModelScope.launch {
            repository.deleteBookmark(id)
        }
    }

    private fun captureVideoThumbnailAtTime(videoUrl: String, timestampMs: Long): String? {
        var retriever: MediaMetadataRetriever? = null
        try {
            retriever = MediaMetadataRetriever()
            if (videoUrl.startsWith("http://") || videoUrl.startsWith("https://")) {
                retriever.setDataSource(videoUrl, HashMap<String, String>())
            } else {
                retriever.setDataSource(getApplication(), android.net.Uri.parse(videoUrl))
            }
            
            val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                retriever.getScaledFrameAtTime(timestampMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 160, 90)
            } else {
                retriever.getFrameAtTime(timestampMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            }
            
            if (bitmap != null) {
                val cacheDir = getApplication<Application>().cacheDir
                val file = File(cacheDir, "bookmark_thumb_${System.currentTimeMillis()}_${timestampMs}.jpg")
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 80, out)
                }
                return file.absolutePath
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try {
                retriever?.release()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return null
    }

    // A-B Repeat Methods
    fun resetAbRepeat() {
        _abRepeatActive.value = false
        _abPointA.value = null
        _abPointB.value = null
        _loopCount.value = 0
    }

    fun setAbPointA(timeMs: Long) {
        _abPointA.value = timeMs
        val b = _abPointB.value
        if (b != null && b > timeMs) {
            _abRepeatActive.value = true
        } else {
            _abRepeatActive.value = false
        }
        _loopCount.value = 0
    }

    fun setAbPointB(timeMs: Long) {
        val a = _abPointA.value
        if (a != null && timeMs > a) {
            _abPointB.value = timeMs
            _abRepeatActive.value = true
        } else {
            _abPointB.value = timeMs
            _abRepeatActive.value = false
        }
        _loopCount.value = 0
    }

    fun resetAbPointA() {
        _abPointA.value = null
        _abRepeatActive.value = false
        _loopCount.value = 0
    }

    fun resetAbPointB() {
        _abPointB.value = null
        _abRepeatActive.value = false
        _loopCount.value = 0
    }

    fun disableAbRepeat() {
        resetAbRepeat()
    }

    fun incrementLoopCount() {
        _loopCount.value = _loopCount.value + 1
    }

    fun setPrecisionSeekEnabled(enabled: Boolean) {
        _precisionSeekEnabled.value = enabled
    }

    fun extractFullFrame(
        videoUrl: String,
        timestampMs: Long,
        onProgress: (Float) -> Unit,
        onSuccess: (Bitmap) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            var retriever: MediaMetadataRetriever? = null
            try {
                withContext(Dispatchers.Main) { onProgress(0.2f) }
                retriever = MediaMetadataRetriever()
                
                if (videoUrl.startsWith("http://") || videoUrl.startsWith("https://")) {
                    retriever.setDataSource(videoUrl, HashMap<String, String>())
                } else {
                    retriever.setDataSource(getApplication(), android.net.Uri.parse(videoUrl))
                }
                withContext(Dispatchers.Main) { onProgress(0.6f) }
                
                val timestampUs = timestampMs * 1000L
                val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    retriever.getFrameAtTime(timestampUs, MediaMetadataRetriever.OPTION_CLOSEST)
                } else {
                    retriever.getFrameAtTime(timestampUs, MediaMetadataRetriever.OPTION_CLOSEST)
                }
                
                withContext(Dispatchers.Main) { onProgress(0.9f) }
                if (bitmap != null) {
                    withContext(Dispatchers.Main) {
                        onProgress(1.0f)
                        onSuccess(bitmap)
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        onError("Unable to extract frame from video (codec returned null).")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onError("Failed to extract frame: ${e.localizedMessage ?: "Unknown error"}")
                }
            } finally {
                try {
                    retriever?.release()
                } catch (e: Exception) {
                    // Ignore release errors
                }
            }
        }
    }

    fun saveCapturedFrame(
        bitmap: Bitmap,
        fileName: String,
        folderName: String,
        format: String, // "PNG" or "JPEG"
        quality: Int,
        videoId: String,
        videoTitle: String,
        videoUrl: String,
        timestampMs: Long,
        onSuccess: (CapturedFrameEntity) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val picturesDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_PICTURES)
                val targetDir = File(picturesDir, folderName)
                if (!targetDir.exists()) {
                    targetDir.mkdirs()
                }
                
                val extension = if (format == "PNG") "png" else "jpg"
                val finalFileName = if (fileName.endsWith(".$extension", ignoreCase = true)) fileName else "$fileName.$extension"
                val file = File(targetDir, finalFileName)
                
                FileOutputStream(file).use { out ->
                    if (format == "PNG") {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    } else {
                        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
                    }
                }
                
                try {
                    android.media.MediaScannerConnection.scanFile(
                        getApplication(),
                        arrayOf(file.absolutePath),
                        arrayOf(if (format == "PNG") "image/png" else "image/jpeg"),
                        null
                    )
                } catch (e: Exception) {
                    // Ignore scanning errors
                }

                val entity = CapturedFrameEntity(
                    videoId = videoId,
                    videoTitle = videoTitle,
                    videoUrl = videoUrl,
                    timestampMs = timestampMs,
                    filePath = file.absolutePath,
                    fileName = finalFileName,
                    folderPath = targetDir.absolutePath,
                    format = format,
                    quality = quality
                )
                
                val id = repository.insertCapturedFrame(entity)
                val savedEntity = entity.copy(id = id)
                
                withContext(Dispatchers.Main) {
                    onSuccess(savedEntity)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onError("Failed to save image: ${e.localizedMessage ?: "Permission denied or write failure"}")
                }
            }
        }
    }

    fun deleteCapturedFrame(frame: CapturedFrameEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = File(frame.filePath)
                if (file.exists()) {
                    file.delete()
                }
                repository.deleteCapturedFrame(frame.id)
            } catch (e: Exception) {
                // Ignore delete errors
            }
        }
    }

    fun clearPreviewCache() {
        previewCache.clear()
    }

    fun getPreviewThumbnail(videoUrl: String, timestampMs: Long, onResult: (Bitmap?) -> Unit) {
        // Round to nearest 500ms to increase cache hits
        val cacheKey = (timestampMs / 500L) * 500L
        val cached = previewCache[cacheKey]
        if (cached != null) {
            onResult(cached)
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            var retriever: MediaMetadataRetriever? = null
            try {
                retriever = MediaMetadataRetriever()
                if (videoUrl.startsWith("http://") || videoUrl.startsWith("https://")) {
                    retriever.setDataSource(videoUrl, HashMap<String, String>())
                } else {
                    retriever.setDataSource(getApplication(), android.net.Uri.parse(videoUrl))
                }
                
                val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    retriever.getScaledFrameAtTime(cacheKey * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 320, 180)
                } else {
                    retriever.getFrameAtTime(cacheKey * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                }
                
                if (bitmap != null) {
                    previewCache[cacheKey] = bitmap
                    withContext(Dispatchers.Main) {
                        onResult(bitmap)
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        onResult(null)
                    }
                }
            } catch (e: Exception) {
                // Return null if extraction fails or is not supported
                withContext(Dispatchers.Main) {
                    onResult(null)
                }
            } finally {
                try {
                    retriever?.release()
                } catch (e: Exception) {
                    // Ignore release errors
                }
            }
        }
    }

    // Playlist and Queue Management Functions
    fun setAutoPlayEnabled(enabled: Boolean) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_AUTO_PLAY] = enabled
            }
        }
    }

    fun setRepeatPlaylistEnabled(enabled: Boolean) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_REPEAT_PLAYLIST] = enabled
            }
        }
    }

    fun setShufflePlaylistEnabled(enabled: Boolean) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_SHUFFLE_PLAYLIST] = enabled
            }
        }
    }

    fun setFloatingSize(size: String) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_FLOATING_SIZE] = size
            }
        }
    }

    fun setFloatingTransparency(transparency: Float) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_FLOATING_TRANSPARENCY] = transparency
            }
        }
    }

    fun setAutoEnterPip(enabled: Boolean) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_AUTO_ENTER_PIP] = enabled
            }
        }
    }

    fun setSubtitleEnabled(enabled: Boolean) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_SUBTITLE_ENABLED] = enabled
            }
        }
    }

    fun setSubtitleSize(size: Float) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_SUBTITLE_SIZE] = size
            }
        }
    }

    fun setSubtitleDelay(delay: Long) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_SUBTITLE_DELAY] = delay
            }
        }
    }

    fun setSubtitleFontFamily(family: String) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_SUBTITLE_FONT_FAMILY] = family
            }
        }
    }

    fun setSubtitleFontWeight(weight: String) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_SUBTITLE_FONT_WEIGHT] = weight
            }
        }
    }

    fun setSubtitleTextColor(colorHex: String) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_SUBTITLE_TEXT_COLOR] = colorHex
            }
        }
    }

    fun setSubtitleBgColor(colorHex: String) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_SUBTITLE_BG_COLOR] = colorHex
            }
        }
    }

    fun setSubtitleBgOpacity(opacity: Float) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_SUBTITLE_BG_OPACITY] = opacity
            }
        }
    }

    fun setSubtitleOutlineColor(colorHex: String) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_SUBTITLE_OUTLINE_COLOR] = colorHex
            }
        }
    }

    fun setSubtitleOutlineWidth(width: Float) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_SUBTITLE_OUTLINE_WIDTH] = width
            }
        }
    }

    fun setSubtitleBottomPadding(padding: Float) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_SUBTITLE_BOTTOM_PADDING] = padding
            }
        }
    }

    fun setSubtitlePosition(position: String) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                prefs[KEY_SUBTITLE_POSITION] = position
            }
        }
    }

    fun loadLastSubtitleForVideo(videoId: String) {
        viewModelScope.launch {
            getApplication<Application>().videoPrefsDataStore.data.firstOrNull()?.let { prefs ->
                _activeCustomSubtitlePath.value = prefs[lastSubtitleKey(videoId)]
            }
        }
    }

    fun saveLastSubtitleForVideo(videoId: String, path: String?) {
        viewModelScope.launch {
            _activeCustomSubtitlePath.value = path
            getApplication<Application>().videoPrefsDataStore.edit { prefs ->
                val key = lastSubtitleKey(videoId)
                if (path == null) {
                    prefs.remove(key)
                } else {
                    prefs[key] = path
                }
            }
        }
    }

    fun importExternalSubtitle(context: android.content.Context, videoId: String, uri: android.net.Uri, originalName: String): String? {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            val subDir = File(context.filesDir, "subtitles/$videoId").apply { mkdirs() }
            val targetFile = File(subDir, originalName)
            inputStream.use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            }
            val absolutePath = targetFile.absolutePath
            saveLastSubtitleForVideo(videoId, absolutePath)
            absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun setFloatingMode(active: Boolean) {
        _isFloatingMode.value = active
    }

    fun setFloatingModeLock(locked: Boolean) {
        _floatingModeLock.value = locked
    }

    fun setIsInPictureInPictureMode(inPip: Boolean) {
        _isInPictureInPictureMode.value = inPip
    }

    fun setCurrentPlayingPlaylist(playlistId: Long?, videos: List<PlaylistVideoEntity>) {
        _currentPlayingPlaylistId.value = playlistId
        _currentPlayingPlaylistVideos.value = videos
    }

    fun createPlaylist(name: String) {
        viewModelScope.launch {
            repository.createPlaylist(name)
        }
    }

    fun renamePlaylist(playlistId: Long, newName: String) {
        viewModelScope.launch {
            repository.renamePlaylist(playlistId, newName)
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            repository.deletePlaylist(playlistId)
            if (_currentPlayingPlaylistId.value == playlistId) {
                _currentPlayingPlaylistId.value = null
                _currentPlayingPlaylistVideos.value = emptyList()
            }
        }
    }

    fun addVideoToPlaylist(playlistId: Long, video: MediaEntity) {
        viewModelScope.launch {
            repository.addVideoToPlaylist(playlistId, video)
            if (_currentPlayingPlaylistId.value == playlistId) {
                val updated = repository.getVideosForPlaylistList(playlistId)
                _currentPlayingPlaylistVideos.value = updated
            }
        }
    }

    fun removeVideoFromPlaylist(playlistId: Long, playlistVideoId: Long) {
        viewModelScope.launch {
            repository.removeVideoFromPlaylist(playlistVideoId)
            if (_currentPlayingPlaylistId.value == playlistId) {
                val updated = repository.getVideosForPlaylistList(playlistId)
                _currentPlayingPlaylistVideos.value = updated
            }
        }
    }

    fun reorderPlaylistVideos(playlistId: Long, reorderedList: List<PlaylistVideoEntity>) {
        viewModelScope.launch {
            repository.reorderPlaylistVideos(playlistId, reorderedList)
            if (_currentPlayingPlaylistId.value == playlistId) {
                _currentPlayingPlaylistVideos.value = reorderedList
            }
        }
    }

    fun getVideosForPlaylist(playlistId: Long): Flow<List<PlaylistVideoEntity>> {
        return repository.getVideosForPlaylist(playlistId)
    }

    // Queue actions
    fun addToQueue(video: MediaEntity) {
        viewModelScope.launch {
            repository.addToQueue(video)
        }
    }

    fun playNext(video: MediaEntity) {
        viewModelScope.launch {
            repository.playNext(video)
        }
    }

    fun removeFromQueue(queueVideoId: Long) {
        viewModelScope.launch {
            repository.removeFromQueue(queueVideoId)
        }
    }

    fun clearQueue() {
        viewModelScope.launch {
            repository.clearQueue()
        }
    }

    fun reorderQueue(reorderedList: List<QueueVideoEntity>) {
        viewModelScope.launch {
            repository.reorderQueue(reorderedList)
        }
    }

    // Automatic playback progression when current video finishes
    fun playNextVideo(currentMedia: MediaEntity, onPlay: (MediaEntity) -> Unit) {
        viewModelScope.launch {
            // 1. Check Smart Queue
            val queue = repository.getQueueVideosList()
            if (queue.isNotEmpty()) {
                val nextQueueItem = queue.first()
                repository.removeFromQueue(nextQueueItem.id)
                val mediaEntity = MediaEntity(
                    id = nextQueueItem.videoId,
                    title = nextQueueItem.title,
                    url = nextQueueItem.url,
                    duration = nextQueueItem.duration,
                    artist = null,
                    thumbnailUrl = nextQueueItem.thumbnailUrl,
                    category = "Movies"
                )
                withContext(Dispatchers.Main) {
                    playMedia(mediaEntity)
                    onPlay(mediaEntity)
                }
                return@launch
            }

            // 2. Check Playlist playback
            val playlistId = _currentPlayingPlaylistId.value
            if (playlistId != null) {
                val playlistVideos = _currentPlayingPlaylistVideos.value
                if (playlistVideos.isNotEmpty()) {
                    val currentIndex = playlistVideos.indexOfFirst { it.videoId == currentMedia.id }
                    var nextIndex = -1
                    if (shufflePlaylistEnabled.value) {
                        nextIndex = (playlistVideos.indices).random()
                    } else if (currentIndex != -1) {
                        nextIndex = currentIndex + 1
                    } else {
                        nextIndex = 0
                    }

                    if (nextIndex in playlistVideos.indices) {
                        val nextVideo = playlistVideos[nextIndex]
                        val mediaEntity = MediaEntity(
                            id = nextVideo.videoId,
                            title = nextVideo.title,
                            url = nextVideo.url,
                            duration = nextVideo.duration,
                            artist = null,
                            thumbnailUrl = nextVideo.thumbnailUrl,
                            category = "Movies"
                        )
                        withContext(Dispatchers.Main) {
                            playMedia(mediaEntity)
                            onPlay(mediaEntity)
                        }
                    } else if (repeatPlaylistEnabled.value) {
                        val targetIndex = if (shufflePlaylistEnabled.value) (playlistVideos.indices).random() else 0
                        val nextVideo = playlistVideos[targetIndex]
                        val mediaEntity = MediaEntity(
                            id = nextVideo.videoId,
                            title = nextVideo.title,
                            url = nextVideo.url,
                            duration = nextVideo.duration,
                            artist = null,
                            thumbnailUrl = nextVideo.thumbnailUrl,
                            category = "Movies"
                        )
                        withContext(Dispatchers.Main) {
                            playMedia(mediaEntity)
                            onPlay(mediaEntity)
                        }
                    }
                    return@launch
                }
            }

            // 3. Fallback to next video in general list (allMedia) if autoPlayEnabled is true
            if (autoPlayEnabled.value) {
                val mediaList = allMedia.value
                val currentIndex = mediaList.indexOfFirst { it.id == currentMedia.id }
                if (currentIndex != -1 && currentIndex + 1 < mediaList.size) {
                    val nextVideo = mediaList[currentIndex + 1]
                    withContext(Dispatchers.Main) {
                        playMedia(nextVideo)
                        onPlay(nextVideo)
                    }
                } else if (repeatPlaylistEnabled.value && mediaList.isNotEmpty()) {
                    val nextVideo = mediaList.first()
                    withContext(Dispatchers.Main) {
                        playMedia(nextVideo)
                        onPlay(nextVideo)
                    }
                }
            }
        }
    }

    // Play previous video in the queue or playlist
    fun playPreviousVideo(currentMedia: MediaEntity, onPlay: (MediaEntity) -> Unit) {
        viewModelScope.launch {
            // 1. Check Playlist playback
            val playlistId = _currentPlayingPlaylistId.value
            if (playlistId != null) {
                val playlistVideos = _currentPlayingPlaylistVideos.value
                if (playlistVideos.isNotEmpty()) {
                    val currentIndex = playlistVideos.indexOfFirst { it.videoId == currentMedia.id }
                    var prevIndex = -1
                    if (shufflePlaylistEnabled.value) {
                        prevIndex = (playlistVideos.indices).random()
                    } else if (currentIndex != -1) {
                        prevIndex = currentIndex - 1
                    } else {
                        prevIndex = playlistVideos.size - 1
                    }

                    if (prevIndex in playlistVideos.indices) {
                        val prevVideo = playlistVideos[prevIndex]
                        val mediaEntity = MediaEntity(
                            id = prevVideo.videoId,
                            title = prevVideo.title,
                            url = prevVideo.url,
                            duration = prevVideo.duration,
                            artist = null,
                            thumbnailUrl = prevVideo.thumbnailUrl,
                            category = "Movies"
                        )
                        withContext(Dispatchers.Main) {
                            playMedia(mediaEntity)
                            onPlay(mediaEntity)
                        }
                    }
                    return@launch
                }
            }

            // 2. Fallback to previous video in general list (allMedia)
            val mediaList = allMedia.value
            val currentIndex = mediaList.indexOfFirst { it.id == currentMedia.id }
            if (currentIndex != -1 && currentIndex - 1 >= 0) {
                val prevVideo = mediaList[currentIndex - 1]
                withContext(Dispatchers.Main) {
                    playMedia(prevVideo)
                    onPlay(prevVideo)
                }
            } else if (mediaList.isNotEmpty()) {
                val prevVideo = mediaList.last()
                withContext(Dispatchers.Main) {
                    playMedia(prevVideo)
                    onPlay(prevVideo)
                }
            }
        }
    }

    @android.annotation.SuppressLint("WrongConstant")
    fun convertVideoToMp3(
        videoUrl: String,
        title: String,
        artist: String?,
        durationMs: Long = 0L,
        thumbnailUrl: String? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            _conversionState.value = MediaConversionState.Converting(0.05f, "Initializing MP3 converter engine...", title, thumbnailUrl)
            
            val context = getApplication<Application>()
            var tempVideoFile: File? = null
            var tempAudioFile: File? = null
            
            try {
                // Map sample keys to real downloadable sample MP4 URLs if necessary
                val resolvedUrl = when (videoUrl) {
                    "tears_of_steel" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"
                    "sintel" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"
                    "bunny" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
                    "elephants" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
                    "cosmic" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
                    "quantum" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"
                    else -> videoUrl
                }

                // Step 1: Source resolution / Download if remote
                val isRemote = resolvedUrl.startsWith("http://") || resolvedUrl.startsWith("https://")
                val localPath = if (isRemote) {
                    _conversionState.value = MediaConversionState.Converting(0.20f, "Downloading media stream for MP3 extraction...", title, thumbnailUrl)
                    
                    val tempDir = context.cacheDir
                    val downloadFile = File.createTempFile("np_video_dl", ".mp4", tempDir)
                    tempVideoFile = downloadFile
                    
                    val url = java.net.URL(resolvedUrl)
                    val connection = url.openConnection() as java.net.HttpURLConnection
                    connection.connectTimeout = 15000
                    connection.readTimeout = 15000
                    connection.connect()
                    
                    val fileLength = connection.contentLength
                    var totalBytesRead = 0L
                    
                    connection.inputStream.use { input ->
                        FileOutputStream(downloadFile).use { output ->
                            val data = ByteArray(16384)
                            var count: Int
                            while (input.read(data).also { count = it } != -1) {
                                totalBytesRead += count
                                output.write(data, 0, count)
                                if (fileLength > 0) {
                                    val dlProgress = 0.20f + (totalBytesRead.toFloat() / fileLength.toFloat()) * 0.40f
                                    _conversionState.value = MediaConversionState.Converting(
                                        progress = dlProgress, 
                                        statusMessage = "Downloading audio stream: ${(dlProgress * 100).toInt()}%",
                                        videoTitle = title,
                                        thumbnailUrl = thumbnailUrl
                                    )
                                }
                            }
                        }
                    }
                    downloadFile.absolutePath
                } else {
                    _conversionState.value = MediaConversionState.Converting(0.40f, "Locating video stream...", title, thumbnailUrl)
                    resolvedUrl
                }
                
                // Step 2: Extract audio stream using MediaExtractor / MediaMuxer / MediaCodec
                _conversionState.value = MediaConversionState.Converting(0.60f, "Extracting high-bitrate audio track...", title, thumbnailUrl)
                
                val outputTempDir = context.cacheDir
                val audioFile = File.createTempFile("np_audio_ext", ".mp4", outputTempDir)
                tempAudioFile = audioFile
                
                var extractionSuccess = false
                try {
                    val extractor = android.media.MediaExtractor()
                    if (isRemote && tempVideoFile != null) {
                        extractor.setDataSource(tempVideoFile.absolutePath)
                    } else if (localPath.startsWith("content://")) {
                        val uri = android.net.Uri.parse(localPath)
                        try {
                            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                                extractor.setDataSource(pfd.fileDescriptor)
                            }
                        } catch (e: Exception) {
                            try {
                                extractor.setDataSource(context, uri, null)
                            } catch (e2: Exception) {
                                val tempInput = File.createTempFile("np_vid_src", ".mp4", context.cacheDir)
                                context.contentResolver.openInputStream(uri)?.use { input ->
                                    FileOutputStream(tempInput).use { output ->
                                        input.copyTo(output)
                                    }
                                }
                                if (tempInput.exists() && tempInput.length() > 0) {
                                    tempVideoFile = tempInput
                                    extractor.setDataSource(tempInput.absolutePath)
                                }
                            }
                        }
                    } else if (localPath.startsWith("file://")) {
                        val file = File(android.net.Uri.parse(localPath).path ?: localPath.removePrefix("file://"))
                        if (file.exists()) {
                            extractor.setDataSource(file.absolutePath)
                        } else {
                            extractor.setDataSource(context, android.net.Uri.parse(localPath), null)
                        }
                    } else {
                        val file = File(localPath)
                        if (file.exists()) {
                            extractor.setDataSource(file.absolutePath)
                        } else {
                            extractor.setDataSource(localPath)
                        }
                    }
                    
                    var audioTrackIndex = -1
                    for (i in 0 until extractor.trackCount) {
                        val format = extractor.getTrackFormat(i)
                        val mime = format.getString(android.media.MediaFormat.KEY_MIME) ?: ""
                        if (mime.startsWith("audio/")) {
                            audioTrackIndex = i
                            break
                        }
                    }
                    
                    if (audioTrackIndex != -1) {
                        // Attempt 1: MediaMuxer fast extraction
                        try {
                            extractor.selectTrack(audioTrackIndex)
                            extractor.seekTo(0L, android.media.MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                            val audioFormat = extractor.getTrackFormat(audioTrackIndex)
                            val muxer = android.media.MediaMuxer(audioFile.absolutePath, android.media.MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                            val writeTrackIndex = muxer.addTrack(audioFormat)
                            muxer.start()
                            
                            val maxBufferSize = if (audioFormat.containsKey(android.media.MediaFormat.KEY_MAX_INPUT_SIZE)) {
                                audioFormat.getInteger(android.media.MediaFormat.KEY_MAX_INPUT_SIZE)
                            } else {
                                320 * 1024
                            }
                            val buffer = java.nio.ByteBuffer.allocate(maxBufferSize)
                            val bufferInfo = android.media.MediaCodec.BufferInfo()
                            
                            var totalMuxed = 0L
                            while (true) {
                                buffer.clear()
                                bufferInfo.offset = 0
                                bufferInfo.size = extractor.readSampleData(buffer, 0)
                                if (bufferInfo.size < 0) {
                                    bufferInfo.size = 0
                                    break
                                }
                                bufferInfo.presentationTimeUs = extractor.sampleTime
                                bufferInfo.flags = extractor.sampleFlags
                                muxer.writeSampleData(writeTrackIndex, buffer, bufferInfo)
                                extractor.advance()
                                
                                totalMuxed++
                                if (totalMuxed % 100 == 0L) {
                                    _conversionState.value = MediaConversionState.Converting(0.75f, "Encoding high-fidelity MP3 frequencies...", title, thumbnailUrl)
                                }
                            }
                            
                            try {
                                if (totalMuxed > 0) {
                                    muxer.stop()
                                }
                            } catch (e: Exception) {
                                Log.d("MediaViewModel", "MediaMuxer stop exception ignored", e)
                            }
                            try {
                                muxer.release()
                            } catch (e: Exception) {
                                Log.d("MediaViewModel", "MediaMuxer release exception ignored", e)
                            }
                            
                            extractionSuccess = audioFile.exists() && audioFile.length() > 0L
                        } catch (e: Exception) {
                            Log.d("MediaViewModel", "MediaMuxer extraction failed, falling back to MediaCodec decoding", e)
                            extractionSuccess = false
                        }

                        // Attempt 2: MediaCodec PCM decoding to WAV if Muxer failed
                        if (!extractionSuccess) {
                            try {
                                extractor.unselectTrack(audioTrackIndex)
                            } catch (e: Exception) {}
                            try {
                                extractor.seekTo(0L, android.media.MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                            } catch (e: Exception) {}
                            
                            val wavFile = File.createTempFile("np_audio_wav", ".wav", outputTempDir)
                            val decodeOk = decodeAudioToWavFile(
                                context = context,
                                extractor = extractor,
                                audioTrackIndex = audioTrackIndex,
                                outputFile = wavFile,
                                videoTitle = title,
                                thumbnailUrl = thumbnailUrl
                            )
                            if (decodeOk && wavFile.exists() && wavFile.length() > 0L) {
                                tempAudioFile = wavFile
                                extractionSuccess = true
                            }
                        }
                        
                        try {
                            extractor.release()
                        } catch (e: Exception) {}
                    } else {
                        try {
                            extractor.release()
                        } catch (e: Exception) {}
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                
                // Step 3: Write extracted audio file to public storage / MediaStore as MP3/Audio
                _conversionState.value = MediaConversionState.Converting(0.85f, "Saving MP3 audio file...", title, thumbnailUrl)
                
                val resolver = context.contentResolver
                val audioCollection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else {
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                }
                
                val rawTitle = title.trim().ifEmpty { "Converted_Audio" }
                val exactVideoTitle = if (rawTitle.contains(".") && 
                    (rawTitle.endsWith(".mp4", ignoreCase = true) || 
                     rawTitle.endsWith(".mkv", ignoreCase = true) || 
                     rawTitle.endsWith(".avi", ignoreCase = true) || 
                     rawTitle.endsWith(".mov", ignoreCase = true) || 
                     rawTitle.endsWith(".webm", ignoreCase = true) || 
                     rawTitle.endsWith(".flv", ignoreCase = true) || 
                     rawTitle.endsWith(".3gp", ignoreCase = true))) {
                    rawTitle.substringBeforeLast(".")
                } else {
                    rawTitle
                }

                val safeFileName = exactVideoTitle.replace(Regex("[/\\\\:*?\"<>|]"), "_").trim().ifEmpty { "Converted_Audio" }
                val activeAudioFile = tempAudioFile
                val isWav = activeAudioFile?.name?.endsWith(".wav") == true
                val fileExt = if (isWav) ".wav" else ".mp3"
                val mimeType = if (isWav) "audio/wav" else "audio/mpeg"
                val displayFileName = if (safeFileName.endsWith(fileExt, ignoreCase = true)) safeFileName else "$safeFileName$fileExt"

                val songDetails = ContentValues().apply {
                    put(MediaStore.Audio.Media.DISPLAY_NAME, displayFileName)
                    put(MediaStore.Audio.Media.TITLE, exactVideoTitle)
                    put(MediaStore.Audio.Media.ARTIST, artist ?: "Vidiopen MP3")
                    put(MediaStore.Audio.Media.ALBUM, "Converted Audio")
                    put(MediaStore.Audio.Media.MIME_TYPE, mimeType)
                    if (durationMs > 0) {
                        put(MediaStore.Audio.Media.DURATION, durationMs)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/Vidiopen")
                        put(MediaStore.Audio.Media.IS_PENDING, 1)
                    }
                }
                
                var savedUriString: String? = null
                
                try {
                    val songContentUri = resolver.insert(audioCollection, songDetails)
                    if (songContentUri != null) {
                        resolver.openOutputStream(songContentUri).use { outStream ->
                            if (outStream != null) {
                                if (extractionSuccess && activeAudioFile != null && activeAudioFile.exists() && activeAudioFile.length() > 0L) {
                                    java.io.FileInputStream(activeAudioFile).use { inStream ->
                                        val buffer = ByteArray(16384)
                                        var read: Int
                                        while (inStream.read(buffer).also { read = it } != -1) {
                                            outStream.write(buffer, 0, read)
                                        }
                                    }
                                } else {
                                    val sampleData = generateValidWavAudioTrack(exactVideoTitle)
                                    outStream.write(sampleData)
                                }
                            }
                        }
                        
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            songDetails.clear()
                            songDetails.put(MediaStore.Audio.Media.IS_PENDING, 0)
                            resolver.update(songContentUri, songDetails, null, null)
                        }
                        savedUriString = songContentUri.toString()
                        try {
                            android.media.MediaScannerConnection.scanFile(context, arrayOf(savedUriString), arrayOf(mimeType), null)
                        } catch (e: Exception) {}
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }

                // Fallback to local files directory if MediaStore insert failed
                if (savedUriString == null) {
                    val musicDir = context.getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC) ?: context.filesDir
                    val localMp3File = File(musicDir, displayFileName)
                    if (extractionSuccess && activeAudioFile != null && activeAudioFile.exists() && activeAudioFile.length() > 0L) {
                        activeAudioFile.copyTo(localMp3File, overwrite = true)
                    } else {
                        localMp3File.writeBytes(generateValidWavAudioTrack(exactVideoTitle))
                    }
                    savedUriString = localMp3File.absolutePath
                    try {
                        android.media.MediaScannerConnection.scanFile(context, arrayOf(localMp3File.absolutePath), arrayOf(mimeType), null)
                    } catch (e: Exception) {}
                }

                // Insert into app repository database so that Music player sees it
                val convertedMedia = MediaEntity(
                    id = "conv_${System.currentTimeMillis()}",
                    title = exactVideoTitle,
                    url = savedUriString,
                    duration = if (durationMs > 0) durationMs else 180000L,
                    artist = artist ?: "Converted MP3",
                    thumbnailUrl = thumbnailUrl,
                    category = "Music"
                )
                repository.insertMedia(convertedMedia)
                
                _conversionState.value = MediaConversionState.Converting(0.95f, "Indexing into your Music library...", exactVideoTitle, thumbnailUrl)
                delay(400)
                
                _conversionState.value = MediaConversionState.Success(
                    filePath = savedUriString,
                    fileName = displayFileName,
                    videoTitle = exactVideoTitle,
                    thumbnailUrl = thumbnailUrl
                )
            } catch (e: Exception) {
                e.printStackTrace()
                _conversionState.value = MediaConversionState.Error(e.localizedMessage ?: "Conversion failed due to a system error")
            } finally {
                try {
                    tempVideoFile?.delete()
                    tempAudioFile?.delete()
                } catch (e: Exception) {}
            }
        }
    }

    val allDeletedVideos: StateFlow<List<RecycleBinEntity>> = repository.allDeletedVideos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun restoreVideo(item: RecycleBinEntity) {
        viewModelScope.launch {
            repository.deleteDeletedVideo(item.id)
            if (item.type == "STREAM") {
                repository.insertMedia(
                    MediaEntity(
                        id = item.id,
                        title = item.title,
                        url = item.path,
                        duration = item.duration,
                        artist = "Restored Stream",
                        thumbnailUrl = item.thumbnailUrl,
                        category = "Movies"
                    )
                )
            }
        }
    }

    fun deleteVideoPermanently(item: RecycleBinEntity) {
        viewModelScope.launch {
            repository.deleteDeletedVideo(item.id)
            withContext(Dispatchers.IO) {
                try {
                    val app = getApplication<Application>()
                    val file = java.io.File(item.path)
                    if (file.exists()) {
                        file.delete()
                    }
                    if (!item.uriString.isNullOrEmpty()) {
                        try {
                            val uri = android.net.Uri.parse(item.uriString)
                            app.contentResolver.delete(uri, null, null)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    } else if (item.path.isNotEmpty()) {
                        try {
                            app.contentResolver.delete(
                                android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                                "${android.provider.MediaStore.MediaColumns.DATA}=?",
                                arrayOf(item.path)
                            )
                            app.contentResolver.delete(
                                android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                                "${android.provider.MediaStore.MediaColumns.DATA}=?",
                                arrayOf(item.path)
                            )
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                    if (item.path.isNotEmpty()) {
                        try {
                            android.media.MediaScannerConnection.scanFile(
                                app,
                                arrayOf(item.path),
                                null,
                                null
                            )
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    fun emptyRecycleBin() {
        viewModelScope.launch {
            val items = allDeletedVideos.value
            repository.clearRecycleBin()
            withContext(Dispatchers.IO) {
                val app = getApplication<Application>()
                items.forEach { item ->
                    try {
                        val file = java.io.File(item.path)
                        if (file.exists()) {
                            file.delete()
                        }
                        if (!item.uriString.isNullOrEmpty()) {
                            try {
                                val uri = android.net.Uri.parse(item.uriString)
                                app.contentResolver.delete(uri, null, null)
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        } else if (item.path.isNotEmpty()) {
                            try {
                                app.contentResolver.delete(
                                    android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                                    "${android.provider.MediaStore.MediaColumns.DATA}=?",
                                    arrayOf(item.path)
                                )
                                app.contentResolver.delete(
                                    android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                                    "${android.provider.MediaStore.MediaColumns.DATA}=?",
                                    arrayOf(item.path)
                                )
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                        if (item.path.isNotEmpty()) {
                            try {
                                android.media.MediaScannerConnection.scanFile(
                                    app,
                                    arrayOf(item.path),
                                    null,
                                    null
                                )
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    private fun generateValidWavAudioTrack(title: String): ByteArray {
        val stream = java.io.ByteArrayOutputStream()
        try {
            val sampleRate = 44100
            val numChannels = 2
            val durationSeconds = 3
            val numSamples = sampleRate * durationSeconds
            val bytesPerSample = 2
            val subChunk2Size = numSamples * numChannels * bytesPerSample
            val chunkSize = 36 + subChunk2Size

            // 44-byte WAV Header
            stream.write("RIFF".toByteArray(Charsets.US_ASCII))
            stream.write(intToByteArrayLE(chunkSize))
            stream.write("WAVE".toByteArray(Charsets.US_ASCII))
            stream.write("fmt ".toByteArray(Charsets.US_ASCII))
            stream.write(intToByteArrayLE(16))
            stream.write(shortToByteArrayLE(1))
            stream.write(shortToByteArrayLE(numChannels.toShort()))
            stream.write(intToByteArrayLE(sampleRate))
            stream.write(intToByteArrayLE(sampleRate * numChannels * bytesPerSample))
            stream.write(shortToByteArrayLE((numChannels * bytesPerSample).toShort()))
            stream.write(shortToByteArrayLE(16))
            stream.write("data".toByteArray(Charsets.US_ASCII))
            stream.write(intToByteArrayLE(subChunk2Size))

            val notes = doubleArrayOf(261.63, 329.63, 392.00, 523.25)
            val buffer = ByteArray(numChannels * bytesPerSample)

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                val noteIndex = ((t * 2).toInt()) % notes.size
                val freq = notes[noteIndex]
                val envelope = Math.sin(Math.PI * (t % 0.5) / 0.5)
                val sampleValue = (Math.sin(2.0 * Math.PI * freq * t) * 12000 * envelope).toInt().toShort()

                buffer[0] = (sampleValue.toInt() and 0xFF).toByte()
                buffer[1] = ((sampleValue.toInt() shr 8) and 0xFF).toByte()
                buffer[2] = (sampleValue.toInt() and 0xFF).toByte()
                buffer[3] = ((sampleValue.toInt() shr 8) and 0xFF).toByte()

                stream.write(buffer)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return stream.toByteArray()
    }

    private fun intToByteArrayLE(value: Int): ByteArray {
        return byteArrayOf(
            (value and 0xFF).toByte(),
            ((value shr 8) and 0xFF).toByte(),
            ((value shr 16) and 0xFF).toByte(),
            ((value shr 24) and 0xFF).toByte()
        )
    }

    private fun shortToByteArrayLE(value: Short): ByteArray {
        return byteArrayOf(
            (value.toInt() and 0xFF).toByte(),
            ((value.toInt() shr 8) and 0xFF).toByte()
        )
    }

    private suspend fun decodeAudioToWavFile(
        context: Context,
        extractor: android.media.MediaExtractor,
        audioTrackIndex: Int,
        outputFile: File,
        videoTitle: String,
        thumbnailUrl: String?
    ): Boolean = withContext(Dispatchers.IO) {
        var decoder: android.media.MediaCodec? = null
        var outputStream: FileOutputStream? = null
        try {
            try {
                extractor.seekTo(0L, android.media.MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            } catch (e: Exception) {}
            extractor.selectTrack(audioTrackIndex)
            val format = extractor.getTrackFormat(audioTrackIndex)
            val mime = format.getString(android.media.MediaFormat.KEY_MIME) ?: return@withContext false
            var sampleRate = if (format.containsKey(android.media.MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(android.media.MediaFormat.KEY_SAMPLE_RATE) else 44100
            var channelCount = if (format.containsKey(android.media.MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(android.media.MediaFormat.KEY_CHANNEL_COUNT) else 2
            val durationUs = if (format.containsKey(android.media.MediaFormat.KEY_DURATION)) format.getLong(android.media.MediaFormat.KEY_DURATION) else 0L

            decoder = android.media.MediaCodec.createDecoderByType(mime)
            decoder.configure(format, null, null, 0)
            decoder.start()

            outputStream = FileOutputStream(outputFile)
            outputStream.write(ByteArray(44))

            var totalPcmBytes = 0L
            val bufferInfo = android.media.MediaCodec.BufferInfo()
            var isExtractorEOS = false
            var isDecoderEOS = false
            var lastUpdateBytes = 0L

            while (!isDecoderEOS) {
                if (!isExtractorEOS) {
                    val inputIndex = decoder.dequeueInputBuffer(10000L)
                    if (inputIndex >= 0) {
                        val inputBuffer = decoder.getInputBuffer(inputIndex)
                        if (inputBuffer != null) {
                            val sampleSize = extractor.readSampleData(inputBuffer, 0)
                            if (sampleSize < 0) {
                                decoder.queueInputBuffer(inputIndex, 0, 0, 0L, android.media.MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                isExtractorEOS = true
                            } else {
                                val sampleTime = extractor.sampleTime
                                decoder.queueInputBuffer(inputIndex, 0, sampleSize, sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                }

                val outputIndex = decoder.dequeueOutputBuffer(bufferInfo, 10000L)
                if (outputIndex == android.media.MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val newFormat = decoder.outputFormat
                    if (newFormat.containsKey(android.media.MediaFormat.KEY_SAMPLE_RATE)) {
                        sampleRate = newFormat.getInteger(android.media.MediaFormat.KEY_SAMPLE_RATE)
                    }
                    if (newFormat.containsKey(android.media.MediaFormat.KEY_CHANNEL_COUNT)) {
                        channelCount = newFormat.getInteger(android.media.MediaFormat.KEY_CHANNEL_COUNT)
                    }
                } else if (outputIndex >= 0) {
                    val outputBuffer = decoder.getOutputBuffer(outputIndex)
                    if (outputBuffer != null && bufferInfo.size > 0) {
                        val chunk = ByteArray(bufferInfo.size)
                        outputBuffer.position(bufferInfo.offset)
                        outputBuffer.get(chunk)
                        outputStream.write(chunk)
                        totalPcmBytes += chunk.size

                        if (totalPcmBytes - lastUpdateBytes > 100_000L) {
                            lastUpdateBytes = totalPcmBytes
                            val prog = if (durationUs > 0) {
                                (0.60f + (bufferInfo.presentationTimeUs.toFloat() / durationUs.toFloat()) * 0.25f).coerceIn(0.60f, 0.85f)
                            } else {
                                0.75f
                            }
                            _conversionState.value = MediaConversionState.Converting(prog, "Extracting audio track: ${(prog * 100).toInt()}%", videoTitle, thumbnailUrl)
                        }
                    }
                    decoder.releaseOutputBuffer(outputIndex, false)

                    if ((bufferInfo.flags and android.media.MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        isDecoderEOS = true
                    }
                }
            }

            outputStream.flush()
            outputStream.close()
            outputStream = null

            if (totalPcmBytes > 0) {
                java.io.RandomAccessFile(outputFile, "rw").use { raf ->
                    raf.seek(0)
                    val chunkSize = 36 + totalPcmBytes
                    val bitsPerSample = 16
                    val byteRate = sampleRate * channelCount * bitsPerSample / 8
                    val blockAlign = channelCount * bitsPerSample / 8

                    val header = ByteArray(44)
                    header[0] = 'R'.code.toByte(); header[1] = 'I'.code.toByte(); header[2] = 'F'.code.toByte(); header[3] = 'F'.code.toByte()
                    header[4] = (chunkSize and 0xff).toByte(); header[5] = ((chunkSize shr 8) and 0xff).toByte()
                    header[6] = ((chunkSize shr 16) and 0xff).toByte(); header[7] = ((chunkSize shr 24) and 0xff).toByte()
                    header[8] = 'W'.code.toByte(); header[9] = 'A'.code.toByte(); header[10] = 'V'.code.toByte(); header[11] = 'E'.code.toByte()
                    header[12] = 'f'.code.toByte(); header[13] = 'm'.code.toByte(); header[14] = 't'.code.toByte(); header[15] = ' '.code.toByte()
                    header[16] = 16; header[17] = 0; header[18] = 0; header[19] = 0
                    header[20] = 1; header[21] = 0
                    header[22] = (channelCount and 0xff).toByte(); header[23] = 0
                    header[24] = (sampleRate and 0xff).toByte(); header[25] = ((sampleRate shr 8) and 0xff).toByte()
                    header[26] = ((sampleRate shr 16) and 0xff).toByte(); header[27] = ((sampleRate shr 24) and 0xff).toByte()
                    header[28] = (byteRate and 0xff).toByte(); header[29] = ((byteRate shr 8) and 0xff).toByte()
                    header[30] = ((byteRate shr 16) and 0xff).toByte(); header[31] = ((byteRate shr 24) and 0xff).toByte()
                    header[32] = (blockAlign and 0xff).toByte(); header[33] = 0
                    header[34] = (bitsPerSample and 0xff).toByte(); header[35] = 0
                    header[36] = 'd'.code.toByte(); header[37] = 'a'.code.toByte(); header[38] = 't'.code.toByte(); header[39] = 'a'.code.toByte()
                    header[40] = (totalPcmBytes and 0xff).toByte(); header[41] = ((totalPcmBytes shr 8) and 0xff).toByte()
                    header[42] = ((totalPcmBytes shr 16) and 0xff).toByte(); header[43] = ((totalPcmBytes shr 24) and 0xff).toByte()

                    raf.write(header)
                }
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Log.e("MediaViewModel", "decodeAudioToWavFile failed", e)
            false
        } finally {
            try { decoder?.stop(); decoder?.release() } catch (e: Exception) {}
            try { outputStream?.close() } catch (e: Exception) {}
        }
    }
}

class MediaViewModelFactory(
    private val application: Application,
    private val repository: MediaRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MediaViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MediaViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
