package com.example.ui.viewmodel

import android.app.Application
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.MediaEntity
import com.example.data.model.ScannedVideo
import com.example.data.model.VideoFolder
import com.example.data.repository.MediaStoreRepository
import com.example.data.database.AppDatabase
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.example.utils.SmartSearchEngine
import java.io.File

private val android.content.Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "media_settings")

enum class VideoSortOrder {
    NEWEST,
    OLDEST,
    NAME_A_Z,
    NAME_Z_A,
    SIZE_LARGEST,
    SIZE_SMALLEST,
    DURATION_LONGEST,
    DURATION_SHORTEST
}

enum class VideoFilterType {
    ALL,
    HD,
    FULL_HD,
    FOUR_K,
    SHORT,
    LONG
}

class MediaStoreViewModel(
    application: Application,
    private val repository: MediaStoreRepository
) : AndroidViewModel(application) {

    private val SORT_ORDER_KEY = stringPreferencesKey("video_sort_order")
    private val FILTER_TYPE_KEY = stringPreferencesKey("video_filter_type")

    private val recycleBinDao = AppDatabase.getDatabase(application).recycleBinDao()
    private val vaultDao = AppDatabase.getDatabase(application).vaultDao()

    private val deletedVideoIds = recycleBinDao.getAllDeletedVideos()
        .map { list -> list.map { it.id }.toSet() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    private val vaultItems = vaultDao.getVaultItems()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _scannedVideos = MutableStateFlow<List<ScannedVideo>>(emptyList())

    val scannedVideos: StateFlow<List<ScannedVideo>> = combine(
        _scannedVideos,
        deletedVideoIds,
        vaultItems
    ) { videos, deletedIds, vaultList ->
        val vaultTitles = vaultList.map { it.title.lowercase() }.toSet()
        val vaultPaths = vaultList.map { it.path.lowercase() }.toSet()
        videos.filter { video ->
            val titleLower = video.title.lowercase()
            val pathLower = video.path.lowercase()
            !deletedIds.contains(video.id.toString()) &&
            !vaultTitles.contains(titleLower) &&
            !vaultPaths.contains(pathLower) &&
            !pathLower.contains("vidiopen_vault")
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val scannedFolders: StateFlow<List<VideoFolder>> = scannedVideos
        .map { videos -> groupVideosIntoFolders(videos) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _sortOrder = MutableStateFlow(VideoSortOrder.NEWEST)
    val sortOrder: StateFlow<VideoSortOrder> = _sortOrder.asStateFlow()

    private val _filterType = MutableStateFlow(VideoFilterType.ALL)
    val filterType: StateFlow<VideoFilterType> = _filterType.asStateFlow()

    // Real-time Search, Sort and Filter combined for smooth 10k+ video scrolling
    val filteredVideos: StateFlow<List<ScannedVideo>> = combine(
        scannedVideos,
        _searchQuery,
        _sortOrder,
        _filterType
    ) { videos, query, sort, filter ->

        var result = videos

        // 1. Intelligent Smart Search Filtering and Scoring
        var searchScored: Map<Long, Int>? = null
        if (query.isNotBlank()) {
            val scoredList = videos.mapNotNull { video ->
                SmartSearchEngine.scoreVideo(video, query)?.let { scored ->
                    video to scored.score
                }
            }
            searchScored = scoredList.associate { it.first.id to it.second }
            // Filter and rank videos by highest search relevance score
            result = scoredList.sortedByDescending { it.second }.map { it.first }
        }

        // 2. Filter by Category Specs
        result = when (filter) {
            VideoFilterType.ALL -> result
            VideoFilterType.HD -> result.filter { maxOf(it.width, it.height) >= 1280 }
            VideoFilterType.FULL_HD -> result.filter { maxOf(it.width, it.height) >= 1920 }
            VideoFilterType.FOUR_K -> result.filter { maxOf(it.width, it.height) >= 3840 }
            VideoFilterType.SHORT -> result.filter { it.duration < 5 * 60 * 1000 }
            VideoFilterType.LONG -> result.filter { it.duration > 20 * 60 * 1000 }
        }

        // 3. Sort Order (If searching, prioritize relevance score, then secondary sort)
        result = if (query.isNotBlank() && searchScored != null) {
            result.sortedWith(
                compareByDescending<ScannedVideo> { searchScored[it.id] ?: 0 }
                    .thenByDescending { it.dateAdded }
            )
        } else {
            when (sort) {
                VideoSortOrder.NEWEST -> result.sortedByDescending { it.dateAdded }
                VideoSortOrder.OLDEST -> result.sortedBy { it.dateAdded }
                VideoSortOrder.NAME_A_Z -> result.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.title })
                VideoSortOrder.NAME_Z_A -> result.sortedWith(compareByDescending(String.CASE_INSENSITIVE_ORDER) { it.title })
                VideoSortOrder.SIZE_LARGEST -> result.sortedByDescending { it.size }
                VideoSortOrder.SIZE_SMALLEST -> result.sortedBy { it.size }
                VideoSortOrder.DURATION_LONGEST -> result.sortedByDescending { it.duration }
                VideoSortOrder.DURATION_SHORTEST -> result.sortedBy { it.duration }
            }
        }

        result
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Real-time combined folders based on Search and Sort
    val filteredFolders: StateFlow<List<VideoFolder>> = combine(
        scannedFolders,
        _searchQuery,
        _sortOrder
    ) { folders, query, sort ->
        var result = folders

        // Filter folders by Intelligent Smart Search Engine
        if (query.isNotBlank()) {
            val scoredFolders = result.mapNotNull { folder ->
                SmartSearchEngine.scoreFolder(folder, query)?.let { scored ->
                    folder to scored.score
                }
            }
            result = scoredFolders.sortedByDescending { it.second }.map { it.first }
        }

        // Sort folders based on selected sort order
        result = when (sort) {
            VideoSortOrder.NEWEST -> result.sortedByDescending { it.latestVideoDateAdded }
            VideoSortOrder.OLDEST -> result.sortedBy { it.latestVideoDateAdded }
            VideoSortOrder.NAME_A_Z -> result.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
            VideoSortOrder.NAME_Z_A -> result.sortedWith(compareByDescending(String.CASE_INSENSITIVE_ORDER) { it.name })
            VideoSortOrder.SIZE_LARGEST -> result.sortedByDescending { it.totalSize }
            VideoSortOrder.SIZE_SMALLEST -> result.sortedBy { it.totalSize }
            VideoSortOrder.DURATION_LONGEST -> result.sortedByDescending { folder -> folder.videos.maxOfOrNull { it.duration } ?: 0L }
            VideoSortOrder.DURATION_SHORTEST -> result.sortedBy { folder -> folder.videos.minOfOrNull { it.duration } ?: 0L }
        }

        result
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var scanJob: kotlinx.coroutines.Job? = null

    private val contentObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            super.onChange(selfChange)
            scanVideos()
        }
    }

    init {
        // Load Sort and Filter preferences from DataStore
        viewModelScope.launch {
            try {
                application.dataStore.data.collect { preferences ->
                    val savedSort = preferences[SORT_ORDER_KEY]
                    if (savedSort != null) {
                        try {
                            _sortOrder.value = VideoSortOrder.valueOf(savedSort)
                        } catch (e: Exception) {
                            // ignore
                        }
                    }
                    val savedFilter = preferences[FILTER_TYPE_KEY]
                    if (savedFilter != null) {
                        try {
                            _filterType.value = VideoFilterType.valueOf(savedFilter)
                        } catch (e: Exception) {
                            // ignore
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        try {
            application.contentResolver.registerContentObserver(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                true,
                contentObserver
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onCleared() {
        super.onCleared()
        try {
            getApplication<Application>().contentResolver.unregisterContentObserver(contentObserver)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun scanVideos() {
        scanJob?.cancel()
        scanJob = viewModelScope.launch(Dispatchers.IO) {
            _isScanning.value = true
            try {
                val videos = repository.scanVideos()
                _scannedVideos.value = videos
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isScanning.value = false
            }
        }
    }

    fun renameVideoTitle(videoId: Long, newTitle: String) {
        _scannedVideos.value = _scannedVideos.value.map {
            if (it.id == videoId) {
                it.copy(title = newTitle)
            } else {
                it
            }
        }
    }

    fun compressVideo(videoId: Long) {
        _scannedVideos.value = _scannedVideos.value.map {
            if (it.id == videoId) {
                it.copy(size = (it.size * 0.55).toLong())
            } else {
                it
            }
        }
    }

    fun removeVideoFromScanned(videoId: Long) {
        _scannedVideos.value = _scannedVideos.value.filter { it.id != videoId }
    }


    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSortOrder(order: VideoSortOrder) {
        _sortOrder.value = order
        viewModelScope.launch(Dispatchers.IO) {
            try {
                getApplication<Application>().dataStore.edit { preferences ->
                    preferences[SORT_ORDER_KEY] = order.name
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun setFilterType(type: VideoFilterType) {
        _filterType.value = type
        viewModelScope.launch(Dispatchers.IO) {
            try {
                getApplication<Application>().dataStore.edit { preferences ->
                    preferences[FILTER_TYPE_KEY] = type.name
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun groupVideosIntoFolders(videos: List<ScannedVideo>): List<VideoFolder> {
        return videos.groupBy { video ->
            val file = File(video.path)
            val parentFile = file.parentFile
            parentFile?.absolutePath ?: "Unknown"
        }.map { (folderPath, folderVideos) ->
            val folderName = File(folderPath).name.ifEmpty { "Root" }
            val latestVideo = folderVideos.firstOrNull()
            val totalSize = folderVideos.sumOf { it.size }
            VideoFolder(
                path = folderPath,
                name = folderName,
                videoCount = folderVideos.size,
                totalSize = totalSize,
                latestVideoThumbnail = latestVideo?.thumbnailUrl,
                latestVideoDateAdded = latestVideo?.dateAdded ?: 0L,
                videos = folderVideos
            )
        }.sortedByDescending { it.latestVideoDateAdded }
    }

    companion object {
        fun formatSize(sizeInBytes: Long): String {
            if (sizeInBytes <= 0) return "0 B"
            val units = arrayOf("B", "KB", "MB", "GB", "TB")
            val digitGroups = (Math.log10(sizeInBytes.toDouble()) / Math.log10(1024.0)).toInt()
            return String.format("%.2f %s", sizeInBytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
        }

        fun ScannedVideo.toMediaEntity(): MediaEntity {
            return MediaEntity(
                id = "scanned_$id",
                title = title,
                url = uriString,
                duration = duration,
                artist = formatSize(size),
                thumbnailUrl = thumbnailUrl,
                category = "Movies"
            )
        }
    }
}

class MediaStoreViewModelFactory(
    private val application: Application,
    private val repository: MediaStoreRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MediaStoreViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MediaStoreViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
