package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalIsLightTheme
import java.io.File

fun getFileNameFromUri(context: android.content.Context, uri: Uri): String {
    var result: String? = null
    if (uri.scheme == "content") {
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        try {
            if (cursor != null && cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0) {
                    result = cursor.getString(nameIndex)
                }
            }
        } finally {
            cursor?.close()
        }
    }
    if (result == null) {
        result = uri.path
        val cut = result?.lastIndexOf('/') ?: -1
        if (cut != -1) {
            result = result?.substring(cut + 1)
        }
    }
    return result ?: "subtitle.srt"
}

// Subtitle Cue Entity
data class SubtitleCue(
    val startTimeMs: Long,
    val endTimeMs: Long,
    val text: String
)

// Parse timestamp (supports SRT HH:MM:SS,mmm, VTT HH:MM:SS.mmm, ASS/SSA H:MM:SS.cs)
fun parseTimestampToMs(timeStr: String): Long {
    try {
        val cleanStr = timeStr.trim().replace(',', '.')
        val parts = cleanStr.split(":")
        if (parts.size < 2) return 0L

        val hours: Long
        val minutes: Long
        val secondsAndMsStr: String
        if (parts.size == 3) {
            hours = parts[0].toLongOrNull() ?: 0L
            minutes = parts[1].toLongOrNull() ?: 0L
            secondsAndMsStr = parts[2]
        } else {
            hours = 0L
            minutes = parts[0].toLongOrNull() ?: 0L
            secondsAndMsStr = parts[1]
        }

        val subParts = secondsAndMsStr.split(".")
        val seconds = subParts[0].toLongOrNull() ?: 0L
        var ms = 0L
        if (subParts.size > 1) {
            val msStr = subParts[1]
            ms = msStr.toLongOrNull() ?: 0L
            if (msStr.length == 1) ms *= 100
            else if (msStr.length == 2) ms *= 10
        }
        return (hours * 3600 + minutes * 60 + seconds) * 1000 + ms
    } catch (e: Exception) {
        return 0L
    }
}

// SRT and VTT File Parser
fun parseSrtOrVtt(content: String): List<SubtitleCue> {
    val cues = mutableListOf<SubtitleCue>()
    val lines = content.lines()
    var i = 0
    while (i < lines.size) {
        val line = lines[i].trim()
        if (line.contains("-->")) {
            val times = line.split("-->")
            if (times.size == 2) {
                val start = parseTimestampToMs(times[0])
                val end = parseTimestampToMs(times[1])
                val textBuilder = StringBuilder()
                i++
                while (i < lines.size && lines[i].trim().isNotEmpty() && !lines[i].contains("-->")) {
                    if (textBuilder.isNotEmpty()) textBuilder.append("\n")
                    textBuilder.append(lines[i].trim())
                    i++
                }
                cues.add(SubtitleCue(start, end, textBuilder.toString()))
            }
        }
        i++
    }
    return cues
}

// ASS and SSA File Parser
fun parseAssOrSsa(content: String): List<SubtitleCue> {
    val cues = mutableListOf<SubtitleCue>()
    for (line in content.lines()) {
        val trimmed = line.trim()
        if (trimmed.startsWith("Dialogue:", ignoreCase = true)) {
            val rest = trimmed.substring("Dialogue:".length)
            val parts = rest.split(",", limit = 10)
            if (parts.size >= 10) {
                val start = parseTimestampToMs(parts[1])
                val end = parseTimestampToMs(parts[2])
                var text = parts[9]
                // Strip tags like {\pos(10,20)} or {\i1}
                text = text.replace(Regex("\\{[^}]*\\}"), "")
                // Replace \N with actual newline
                text = text.replace("\\N", "\n", ignoreCase = true)
                cues.add(SubtitleCue(start, end, text))
            }
        }
    }
    return cues
}

// Master Subtitle File Parser
fun parseSubtitleFile(file: File): List<SubtitleCue> {
    return try {
        val content = file.readText(Charsets.UTF_8)
        val ext = file.extension.lowercase()
        if (ext == "ass" || ext == "ssa") {
            parseAssOrSsa(content)
        } else {
            parseSrtOrVtt(content)
        }
    } catch (e: Exception) {
        e.printStackTrace()
        emptyList()
    }
}

// Helper to safely parse color hex codes
fun parseHexColor(hex: String, opacity: Float = 1.0f, fallback: Color = Color.White): Color {
    return try {
        val parsed = android.graphics.Color.parseColor(hex)
        Color(parsed).copy(alpha = opacity)
    } catch (e: Exception) {
        fallback.copy(alpha = opacity)
    }
}

@Composable
fun SubtitleTextRenderer(
    text: String,
    size: Float,
    fontFamily: String,
    fontWeight: String,
    textColorHex: String,
    bgColorHex: String,
    bgOpacity: Float,
    outlineColorHex: String,
    outlineWidth: Float,
    modifier: Modifier = Modifier
) {
    val family = when (fontFamily) {
        "Sans-serif" -> FontFamily.SansSerif
        "Serif" -> FontFamily.Serif
        "Monospace" -> FontFamily.Monospace
        else -> FontFamily.Default
    }

    val weight = when (fontWeight) {
        "Bold" -> FontWeight.Bold
        else -> FontWeight.Normal
    }

    val fgColor = parseHexColor(textColorHex, 1.0f, Color.White)
    val bgColor = parseHexColor(bgColorHex, bgOpacity, Color.Black.copy(alpha = 0.5f))
    val outColor = parseHexColor(outlineColorHex, 1.0f, Color.Black)

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        if (outlineWidth > 0f) {
            Text(
                text = text,
                textAlign = TextAlign.Center,
                style = TextStyle(
                    fontSize = size.sp,
                    fontFamily = family,
                    fontWeight = weight,
                    color = outColor,
                    drawStyle = Stroke(
                        width = outlineWidth * 2f,
                        join = StrokeJoin.Round
                    )
                )
            )
        }
        Text(
            text = text,
            textAlign = TextAlign.Center,
            style = TextStyle(
                fontSize = size.sp,
                fontFamily = family,
                fontWeight = weight,
                color = fgColor
            )
        )
    }
}

@Composable
fun SubtitleLayoutContainer(
    text: String,
    size: Float,
    fontFamily: String,
    fontWeight: String,
    textColorHex: String,
    bgColorHex: String,
    bgOpacity: Float,
    outlineColorHex: String,
    outlineWidth: Float,
    bottomPadding: Float,
    position: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(
                top = if (position == "Top") bottomPadding.dp else 16.dp,
                bottom = if (position == "Bottom") bottomPadding.dp else 16.dp,
                start = 16.dp,
                end = 16.dp
            ),
        contentAlignment = when (position) {
            "Top" -> Alignment.TopCenter
            "Center" -> Alignment.Center
            else -> Alignment.BottomCenter
        }
    ) {
        SubtitleTextRenderer(
            text = text,
            size = size,
            fontFamily = fontFamily,
            fontWeight = fontWeight,
            textColorHex = textColorHex,
            bgColorHex = bgColorHex,
            bgOpacity = bgOpacity,
            outlineColorHex = outlineColorHex,
            outlineWidth = outlineWidth
        )
    }
}

@Composable
fun SubtitleManagerSheetContent(
    media: com.example.data.model.MediaEntity,
    viewModel: com.example.ui.viewmodel.MediaViewModel,
    activeSubtitleTrackName: String,
    onSelectTrackName: (String) -> Unit,
    subtitleTracks: List<SubtitleTrackInfo>,
    exoPlayer: androidx.media3.exoplayer.ExoPlayer,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf(0) } // 0: Tracks & Sync, 1: Style & Colors, 2: Border & Position

    // Observe States from ViewModel
    val isSubEnabled by viewModel.subtitleEnabled.collectAsState()
    val subSize by viewModel.subtitleSize.collectAsState()
    val subDelay by viewModel.subtitleDelay.collectAsState()
    val subFontFamily by viewModel.subtitleFontFamily.collectAsState()
    val subFontWeight by viewModel.subtitleFontWeight.collectAsState()
    val subTextColor by viewModel.subtitleTextColor.collectAsState()
    val subBgColor by viewModel.subtitleBgColor.collectAsState()
    val subBgOpacity by viewModel.subtitleBgOpacity.collectAsState()
    val subOutlineColor by viewModel.subtitleOutlineColor.collectAsState()
    val subOutlineWidth by viewModel.subtitleOutlineWidth.collectAsState()
    val subBottomPadding by viewModel.subtitleBottomPadding.collectAsState()
    val subPosition by viewModel.subtitlePosition.collectAsState()
    val customSubPath by viewModel.activeCustomSubtitlePath.collectAsState()

    var subtitleErrorMessage by remember { mutableStateOf<String?>(null) }

    // Subtitle File Picker Launcher
    val subtitlePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val originalName = getFileNameFromUri(context, uri)
            val ext = originalName.substringAfterLast(".").lowercase()
            if (ext == "srt" || ext == "vtt" || ext == "ass" || ext == "ssa") {
                val localPath = viewModel.importExternalSubtitle(context, media.id, uri, originalName)
                if (localPath != null) {
                    subtitleErrorMessage = null
                    onSelectTrackName(originalName)
                    // Disable native subtitle track to let custom renderer take over
                    val newParams = exoPlayer.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true)
                        .build()
                    exoPlayer.trackSelectionParameters = newParams
                } else {
                    subtitleErrorMessage = "Failed to import subtitle file."
                }
            } else {
                subtitleErrorMessage = "Unsupported file format (.${ext.uppercase()}). Only SRT, VTT, ASS, and SSA files are supported."
            }
        }
    }

    val isLight = LocalIsLightTheme.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.85f)
            .background(if (isLight) Color(0xFFF8FAFC) else Color(0xFF161622))
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = androidx.compose.material.icons.Icons.Rounded.Subtitles,
                    contentDescription = null,
                    tint = com.example.ui.theme.ElectricBlue,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Subtitle Pro Manager",
                    color = if (isLight) Color.Black else Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
            IconButton(onClick = onDismiss) {
                Icon(
                    imageVector = androidx.compose.material.icons.Icons.Rounded.Close,
                    contentDescription = "Close",
                    tint = if (isLight) Color.Black else Color.White
                )
            }
        }

        // Tabs Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
                .background(if (isLight) Color.Black.copy(alpha = 0.05f) else Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                .padding(4.dp)
        ) {
            val tabs = listOf("Tracks & Sync", "Style & Colors", "Border & Position")
            tabs.forEachIndexed { index, title ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (activeTab == index) com.example.ui.theme.ElectricBlue else Color.Transparent)
                        .clickable { activeTab = index }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = title,
                        color = if (activeTab == index) Color.Black else (if (isLight) Color.DarkGray else Color.White.copy(alpha = 0.7f)),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Subtitle Error Message Warning Card
        if (subtitleErrorMessage != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF7F1D1D)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = androidx.compose.material.icons.Icons.Rounded.Close,
                        contentDescription = "Error",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(subtitleErrorMessage!!, color = Color.White, fontSize = 12.sp)
                }
            }
        }

        // Tab Content
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (activeTab) {
                0 -> { // Tracks & Sync
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp)
                    ) {
                        item {
                            Spacer(modifier = Modifier.height(10.dp))
                            // Subtitle Master Switch
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Enable Subtitles", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Show or hide subtitle captions", color = Color.Gray, fontSize = 11.sp)
                                }
                                Switch(
                                    checked = isSubEnabled,
                                    onCheckedChange = { viewModel.setSubtitleEnabled(it) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.Black,
                                        checkedTrackColor = com.example.ui.theme.ElectricBlue,
                                        uncheckedThumbColor = Color.Gray,
                                        uncheckedTrackColor = Color.White.copy(alpha = 0.1f)
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(16.dp))

                            Text("AVAILABLE SUBTITLE TRACKS", color = com.example.ui.theme.ElectricBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                        }

                        // Native Embedded Tracks List
                        items(subtitleTracks) { track ->
                            val isSelected = activeSubtitleTrackName == track.name || 
                                             (track.name != "None" && activeSubtitleTrackName == "${track.name} (${track.language})")
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(
                                        if (isSelected) com.example.ui.theme.ElectricBlue.copy(alpha = 0.1f) else Color.Transparent,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        onSelectTrackName(track.name)
                                        if (track.group == null) {
                                            val newParams = exoPlayer.trackSelectionParameters.buildUpon()
                                                .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true)
                                                .build()
                                            exoPlayer.trackSelectionParameters = newParams
                                        } else {
                                            val newParams = exoPlayer.trackSelectionParameters.buildUpon()
                                                .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, false)
                                                .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_TEXT)
                                                .addOverride(androidx.media3.common.TrackSelectionOverride(track.group.mediaTrackGroup, track.trackIndex))
                                                .build()
                                            exoPlayer.trackSelectionParameters = newParams
                                        }
                                    }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = androidx.compose.material.icons.Icons.Rounded.Subtitles,
                                        contentDescription = null,
                                        tint = if (isSelected) com.example.ui.theme.ElectricBlue else Color.Gray,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = if (track.name == "None") "None (Disabled)" else "${track.name} [${track.language.uppercase()}]",
                                        color = if (isSelected) Color.White else Color.White.copy(alpha = 0.8f),
                                        fontSize = 14.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                                if (isSelected) {
                                    Icon(
                                        imageVector = androidx.compose.material.icons.Icons.Rounded.Check,
                                        contentDescription = "Selected",
                                        tint = com.example.ui.theme.ElectricBlue,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        // Manual Subtitle Track List (If exists)
                        if (customSubPath != null) {
                            item {
                                val originalName = customSubPath!!.substringAfterLast("/")
                                val isSelected = activeSubtitleTrackName == originalName
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .background(
                                            if (isSelected) com.example.ui.theme.ElectricBlue.copy(alpha = 0.1f) else Color.Transparent,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable {
                                            onSelectTrackName(originalName)
                                            // Disable native subtitle track to let manual custom parser run
                                            val newParams = exoPlayer.trackSelectionParameters.buildUpon()
                                                .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true)
                                                .build()
                                            exoPlayer.trackSelectionParameters = newParams
                                        }
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Icon(
                                            imageVector = androidx.compose.material.icons.Icons.Rounded.FolderOpen,
                                            contentDescription = null,
                                            tint = if (isSelected) com.example.ui.theme.ElectricBlue else Color.Gray,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = "$originalName (External)",
                                            color = if (isSelected) Color.White else Color.White.copy(alpha = 0.8f),
                                            fontSize = 14.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            maxLines = 1
                                        )
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (isSelected) {
                                            Icon(
                                                imageVector = androidx.compose.material.icons.Icons.Rounded.Check,
                                                contentDescription = "Selected",
                                                tint = com.example.ui.theme.ElectricBlue,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                        }
                                        IconButton(
                                            onClick = {
                                                viewModel.saveLastSubtitleForVideo(media.id, null)
                                                if (isSelected) {
                                                    onSelectTrackName("None")
                                                }
                                            },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                imageVector = androidx.compose.material.icons.Icons.Rounded.Delete,
                                                contentDescription = "Delete",
                                                tint = Color.Red.copy(alpha = 0.8f),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Import Local Subtitle Button
                        item {
                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = { subtitlePickerLauncher.launch(arrayOf("*/*")) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.08f)),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = androidx.compose.material.icons.Icons.Rounded.FolderOpen,
                                    contentDescription = null,
                                    tint = com.example.ui.theme.ElectricBlue,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("📂 Load Local Subtitle File (.SRT/.VTT/.ASS/.SSA)", color = Color.White, fontSize = 13.sp)
                            }
                            Spacer(modifier = Modifier.height(20.dp))

                            // Subtitle Delay Offset Sync Section
                            Text("SUBTITLE TIMING DELAY", color = com.example.ui.theme.ElectricBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp))
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Sync Delay: ${if (subDelay > 0) "+" else ""}${subDelay} ms (${String.format("%.1f", subDelay / 1000f)}s)",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text("Adjust to fix subtitle sync issues", color = Color.Gray, fontSize = 11.sp)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Slow-coarse down
                                    Button(
                                        onClick = { viewModel.setSubtitleDelay((subDelay - 1000).coerceAtLeast(-10000)) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.08f)),
                                        contentPadding = PaddingValues(0.dp),
                                        modifier = Modifier.size(36.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("-1s", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.width(4.dp))
                                    // Fine down
                                    Button(
                                        onClick = { viewModel.setSubtitleDelay((subDelay - 250).coerceAtLeast(-10000)) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.08f)),
                                        contentPadding = PaddingValues(0.dp),
                                        modifier = Modifier.size(36.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("-", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    // Fine up
                                    Button(
                                        onClick = { viewModel.setSubtitleDelay((subDelay + 250).coerceAtMost(10000)) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.08f)),
                                        contentPadding = PaddingValues(0.dp),
                                        modifier = Modifier.size(36.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("+", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.width(4.dp))
                                    // Slow-coarse up
                                    Button(
                                        onClick = { viewModel.setSubtitleDelay((subDelay + 1000).coerceAtMost(10000)) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.08f)),
                                        contentPadding = PaddingValues(0.dp),
                                        modifier = Modifier.size(36.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("+1s", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(20.dp))
                        }
                    }
                }

                1 -> { // Style & Colors
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp)
                    ) {
                        item {
                            Spacer(modifier = Modifier.height(10.dp))

                            // Text Size Slider
                            Text("FONT SIZE (${subSize.toInt()} sp)", color = com.example.ui.theme.ElectricBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("10sp", color = Color.Gray, fontSize = 11.sp)
                                Slider(
                                    value = subSize,
                                    onValueChange = { viewModel.setSubtitleSize(it) },
                                    valueRange = 10f..36f,
                                    modifier = Modifier.weight(1f),
                                    colors = SliderDefaults.colors(
                                        thumbColor = com.example.ui.theme.ElectricBlue,
                                        activeTrackColor = com.example.ui.theme.ElectricBlue,
                                        inactiveTrackColor = Color.White.copy(alpha = 0.1f)
                                    )
                                )
                                Text("36sp", color = Color.Gray, fontSize = 11.sp)
                            }
                            Spacer(modifier = Modifier.height(16.dp))

                            // Font Family Selector
                            Text("FONT FAMILY", color = com.example.ui.theme.ElectricBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val fontFamilies = listOf("Sans-serif", "Serif", "Monospace", "Default")
                                fontFamilies.forEach { font ->
                                    val isSelected = subFontFamily == font
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) com.example.ui.theme.ElectricBlue else Color.White.copy(alpha = 0.05f))
                                            .clickable { viewModel.setSubtitleFontFamily(font) }
                                            .padding(vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = font,
                                            color = if (isSelected) Color.Black else Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))

                            // Font Weight Selector
                            Text("FONT WEIGHT", color = com.example.ui.theme.ElectricBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val weights = listOf("Normal", "Bold")
                                weights.forEach { weight ->
                                    val isSelected = subFontWeight == weight
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) com.example.ui.theme.ElectricBlue else Color.White.copy(alpha = 0.05f))
                                            .clickable { viewModel.setSubtitleFontWeight(weight) }
                                            .padding(vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = weight,
                                            color = if (isSelected) Color.Black else Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))

                            // Text Color Palette Selector
                            Text("TEXT COLOR", color = com.example.ui.theme.ElectricBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                val colorsMap = mapOf(
                                    "White" to "#FFFFFF",
                                    "Yellow" to "#FFFF00",
                                    "Blue" to "#3B82F6",
                                    "Green" to "#10B981",
                                    "Red" to "#EF4444",
                                    "Black" to "#000000"
                                )
                                colorsMap.forEach { (name, hex) ->
                                    val isSelected = subTextColor.equals(hex, ignoreCase = true)
                                    val col = parseHexColor(hex, 1.0f, Color.White)
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(20.dp))
                                            .background(col)
                                            .border(
                                                2.dp,
                                                if (isSelected) com.example.ui.theme.ElectricBlue else Color.White.copy(alpha = 0.2f),
                                                RoundedCornerShape(20.dp)
                                            )
                                            .clickable { viewModel.setSubtitleTextColor(hex) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isSelected) {
                                            Icon(
                                                imageVector = androidx.compose.material.icons.Icons.Rounded.Check,
                                                contentDescription = "Selected",
                                                tint = if (name == "White" || name == "Yellow") Color.Black else Color.White,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))

                            // Background Color Palette Selector
                            Text("BACKGROUND COLOR", color = com.example.ui.theme.ElectricBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                val bgColorsMap = mapOf(
                                    "Black" to "#000000",
                                    "Dark Gray" to "#1F2937",
                                    "Gray" to "#6B7280",
                                    "Blue" to "#1D4ED8",
                                    "Transparent" to "#00000000"
                                )
                                bgColorsMap.forEach { (name, hex) ->
                                    val isSelected = subBgColor.equals(hex, ignoreCase = true)
                                    val col = if (name == "Transparent") Color.Transparent else parseHexColor(hex, 1.0f, Color.Black)
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(20.dp))
                                            .background(if (name == "Transparent") Color.White.copy(alpha = 0.05f) else col)
                                            .border(
                                                2.dp,
                                                if (isSelected) com.example.ui.theme.ElectricBlue else Color.White.copy(alpha = 0.2f),
                                                RoundedCornerShape(20.dp)
                                            )
                                            .clickable { viewModel.setSubtitleBgColor(hex) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (name == "Transparent") {
                                            Box(
                                                modifier = Modifier
                                                    .size(20.dp)
                                                    .border(1.dp, Color.Red, RoundedCornerShape(10.dp))
                                            )
                                        }
                                        if (isSelected) {
                                            Icon(
                                                imageVector = androidx.compose.material.icons.Icons.Rounded.Check,
                                                contentDescription = "Selected",
                                                tint = com.example.ui.theme.ElectricBlue,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))

                            // Background Opacity Slider
                            Text("BACKGROUND OPACITY (${(subBgOpacity * 100).toInt()}%)", color = com.example.ui.theme.ElectricBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("0%", color = Color.Gray, fontSize = 11.sp)
                                Slider(
                                    value = subBgOpacity,
                                    onValueChange = { viewModel.setSubtitleBgOpacity(it) },
                                    valueRange = 0f..1f,
                                    modifier = Modifier.weight(1f),
                                    colors = SliderDefaults.colors(
                                        thumbColor = com.example.ui.theme.ElectricBlue,
                                        activeTrackColor = com.example.ui.theme.ElectricBlue,
                                        inactiveTrackColor = Color.White.copy(alpha = 0.1f)
                                    )
                                )
                                Text("100%", color = Color.Gray, fontSize = 11.sp)
                            }
                            Spacer(modifier = Modifier.height(20.dp))
                        }
                    }
                }

                2 -> { // Border & Position
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp)
                    ) {
                        item {
                            Spacer(modifier = Modifier.height(10.dp))

                            // Outline Color Palette
                            Text("OUTLINE / BORDER COLOR", color = com.example.ui.theme.ElectricBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                val outlineColorsMap = mapOf(
                                    "Black" to "#000000",
                                    "White" to "#FFFFFF",
                                    "Red" to "#EF4444",
                                    "Yellow" to "#FFFF00"
                                )
                                outlineColorsMap.forEach { (name, hex) ->
                                    val isSelected = subOutlineColor.equals(hex, ignoreCase = true)
                                    val col = parseHexColor(hex, 1.0f, Color.Black)
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(20.dp))
                                            .background(col)
                                            .border(
                                                2.dp,
                                                if (isSelected) com.example.ui.theme.ElectricBlue else Color.White.copy(alpha = 0.2f),
                                                RoundedCornerShape(20.dp)
                                            )
                                            .clickable { viewModel.setSubtitleOutlineColor(hex) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isSelected) {
                                            Icon(
                                                imageVector = androidx.compose.material.icons.Icons.Rounded.Check,
                                                contentDescription = "Selected",
                                                tint = if (name == "White" || name == "Yellow") Color.Black else Color.White,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))

                            // Outline Width Slider
                            Text("OUTLINE WIDTH (${String.format("%.1f", subOutlineWidth)} dp)", color = com.example.ui.theme.ElectricBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("0dp", color = Color.Gray, fontSize = 11.sp)
                                Slider(
                                    value = subOutlineWidth,
                                    onValueChange = { viewModel.setSubtitleOutlineWidth(it) },
                                    valueRange = 0f..4f,
                                    modifier = Modifier.weight(1f),
                                    colors = SliderDefaults.colors(
                                        thumbColor = com.example.ui.theme.ElectricBlue,
                                        activeTrackColor = com.example.ui.theme.ElectricBlue,
                                        inactiveTrackColor = Color.White.copy(alpha = 0.1f)
                                    )
                                )
                                Text("4dp", color = Color.Gray, fontSize = 11.sp)
                            }
                            Spacer(modifier = Modifier.height(16.dp))

                            // Bottom Padding Slider
                            Text("BOTTOM PADDING / MARGIN (${subBottomPadding.toInt()} dp)", color = com.example.ui.theme.ElectricBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("10dp", color = Color.Gray, fontSize = 11.sp)
                                Slider(
                                    value = subBottomPadding,
                                    onValueChange = { viewModel.setSubtitleBottomPadding(it) },
                                    valueRange = 10f..120f,
                                    modifier = Modifier.weight(1f),
                                    colors = SliderDefaults.colors(
                                        thumbColor = com.example.ui.theme.ElectricBlue,
                                        activeTrackColor = com.example.ui.theme.ElectricBlue,
                                        inactiveTrackColor = Color.White.copy(alpha = 0.1f)
                                    )
                                )
                                Text("120dp", color = Color.Gray, fontSize = 11.sp)
                            }
                            Spacer(modifier = Modifier.height(16.dp))

                            // Screen Position Grid Selector
                            Text("SCREEN POSITION", color = com.example.ui.theme.ElectricBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val positions = listOf("Top", "Center", "Bottom")
                                positions.forEach { pos ->
                                    val isSelected = subPosition.equals(pos, ignoreCase = true)
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) com.example.ui.theme.ElectricBlue else Color.White.copy(alpha = 0.05f))
                                            .clickable { viewModel.setSubtitlePosition(pos) }
                                            .padding(vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = pos,
                                            color = if (isSelected) Color.Black else Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(20.dp))
                        }
                    }
                }
            }
        }

        // Live Preview Box At the Bottom of the sheet (Requirement 8)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .background(Color.Black, RoundedCornerShape(12.dp))
                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "LIVE SUBTITLE STYLE PREVIEW",
                color = Color.White.copy(alpha = 0.4f),
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .background(Color(0xFF13131A), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                SubtitleTextRenderer(
                    text = "Vidiopen Offline Subtitles",
                    size = subSize,
                    fontFamily = subFontFamily,
                    fontWeight = subFontWeight,
                    textColorHex = subTextColor,
                    bgColorHex = subBgColor,
                    bgOpacity = subBgOpacity,
                    outlineColorHex = subOutlineColor,
                    outlineWidth = subOutlineWidth
                )
            }
        }
    }
}
