package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AestheticThemeBackground(
    themeId: String,
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        when (themeId) {
            "cyber_neon_feel" -> CyberNeonFeelThemeView(isPlaying = isPlaying)
            "moonlight_night" -> MoonlightNightThemeView(isPlaying = isPlaying)
            "foggy_city" -> FoggyCityThemeView(isPlaying = isPlaying)
            "glowing_notes" -> GlowingNotesThemeView(isPlaying = isPlaying)
            "headphones_wave" -> HeadphonesWaveThemeView(isPlaying = isPlaying)
            "dark_collage" -> DarkCollageThemeView(isPlaying = isPlaying)
            else -> CyberNeonFeelThemeView(isPlaying = isPlaying)
        }
    }
}

// --------------------------------------------------------------------------------------------------
// THEME 1: Moonlight Night (Full Moon + Silhouetted Branches + Frame Box + Heart)
// --------------------------------------------------------------------------------------------------
@Composable
fun MoonlightNightThemeView(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "MoonlightAnim")
    
    // Moon pulse animation
    val moonPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "MoonPulse"
    )

    // Star twinkle phase
    val starPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "StarPhase"
    )

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF070A12))) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Dark night gradient background
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF050811),
                        Color(0xFF0D1322),
                        Color(0xFF080C16)
                    )
                )
            )

            // 2. Twinkling stars
            val starPositions = listOf(
                Offset(w * 0.15f, h * 0.12f), Offset(w * 0.82f, h * 0.18f),
                Offset(w * 0.25f, h * 0.28f), Offset(w * 0.75f, h * 0.35f),
                Offset(w * 0.10f, h * 0.55f), Offset(w * 0.88f, h * 0.62f),
                Offset(w * 0.20f, h * 0.78f), Offset(w * 0.80f, h * 0.85f)
            )
            starPositions.forEachIndexed { i, pos ->
                val alpha = (0.3f + 0.5f * sin(starPhase + i * 1.2f)).coerceIn(0.1f, 1f)
                drawCircle(color = Color.White.copy(alpha = alpha), radius = 2f, center = pos)
            }

            // 3. Glowing Full Moon
            val moonCenter = Offset(w * 0.52f, h * 0.32f)
            val moonRadius = 24.dp.toPx() * moonPulse

            // Radial Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.85f),
                        Color(0xFFFFF8E7).copy(alpha = 0.35f),
                        Color(0xFFE2E8F0).copy(alpha = 0.10f),
                        Color.Transparent
                    ),
                    center = moonCenter,
                    radius = moonRadius * 3.5f
                ),
                radius = moonRadius * 3.5f,
                center = moonCenter
            )

            // Moon disc
            drawCircle(
                color = Color(0xFFFFFFF0),
                radius = moonRadius,
                center = moonCenter
            )

            // 4. White rectangular frame outline in center (Matching Image 1)
            val frameMargin = w * 0.12f
            val frameTop = h * 0.16f
            val frameSize = w - (frameMargin * 2)
            val frameRect = Rect(frameMargin, frameTop, frameMargin + frameSize, frameTop + frameSize)

            drawRect(
                color = Color.White,
                topLeft = Offset(frameRect.left, frameRect.top),
                size = Size(frameRect.width, frameRect.height),
                style = Stroke(width = 3.dp.toPx())
            )

            // 5. Silhouetted Tree Branches & Leaves across screen
            val branchPath = Path().apply {
                // Main diagonal branch
                moveTo(w * 0.95f, h * 0.10f)
                cubicTo(w * 0.80f, h * 0.25f, w * 0.65f, h * 0.38f, w * 0.35f, h * 0.65f)
                cubicTo(w * 0.25f, h * 0.75f, w * 0.15f, h * 0.85f, 0f, h * 0.95f)
            }
            drawPath(
                path = branchPath,
                color = Color(0xFF04060B),
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )

            // Leaf clusters along branch
            val leafCenters = listOf(
                Offset(w * 0.70f, h * 0.28f), Offset(w * 0.60f, h * 0.35f),
                Offset(w * 0.50f, h * 0.44f), Offset(w * 0.42f, h * 0.52f),
                Offset(w * 0.32f, h * 0.60f)
            )
            leafCenters.forEach { lc ->
                drawOval(
                    color = Color(0xFF04060A),
                    topLeft = Offset(lc.x - 18.dp.toPx(), lc.y - 10.dp.toPx()),
                    size = Size(36.dp.toPx(), 20.dp.toPx())
                )
            }
        }

        // 6. Red Heart Icon at Bottom Right of Frame
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 120.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .width(300.dp)
                    .height(300.dp),
                contentAlignment = Alignment.BottomEnd
            ) {
                Icon(
                    imageVector = Icons.Rounded.Favorite,
                    contentDescription = "Heart",
                    tint = Color(0xFFFF2D55),
                    modifier = Modifier
                        .size(32.dp)
                        .padding(end = 12.dp, bottom = 12.dp)
                )
            }
        }
    }
}

// --------------------------------------------------------------------------------------------------
// THEME 2: Foggy City (Misty Sunset/Street light + Silhouette + Sound Wave + Heart)
// --------------------------------------------------------------------------------------------------
@Composable
fun FoggyCityThemeView(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "FoggyCityAnim")

    // Dynamic visualizer bars height
    val barPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "BarPhase"
    )

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF0F141E))) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Foggy city gradient background (Warm top glow to misty blue-grey)
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF131922),
                        Color(0xFF1E2838),
                        Color(0xFFE3C3A2), // Foggy sunset light breaking through
                        Color(0xFF2B3A4C),
                        Color(0xFF0D121B)
                    )
                )
            )

            // 2. Soft streetlamp/sun light glow in upper-middle
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFFFF2D6).copy(alpha = 0.70f),
                        Color(0xFFE8C59C).copy(alpha = 0.30f),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.5f, h * 0.35f),
                    radius = w * 0.4f
                ),
                center = Offset(w * 0.5f, h * 0.35f),
                radius = w * 0.4f
            )

            // 3. City Skyscrapers Silhouettes on left & right
            val skylineLeft = Path().apply {
                moveTo(0f, h)
                lineTo(0f, h * 0.15f)
                lineTo(w * 0.28f, h * 0.15f)
                lineTo(w * 0.28f, h * 0.40f)
                lineTo(w * 0.38f, h * 0.40f)
                lineTo(w * 0.38f, h)
                close()
            }
            drawPath(path = skylineLeft, color = Color(0xFF0B1017).copy(alpha = 0.85f))

            val skylineRight = Path().apply {
                moveTo(w, h)
                lineTo(w, h * 0.10f)
                lineTo(w * 0.78f, h * 0.10f)
                lineTo(w * 0.78f, h * 0.38f)
                lineTo(w * 0.65f, h * 0.38f)
                lineTo(w * 0.65f, h)
                close()
            }
            drawPath(path = skylineRight, color = Color(0xFF0B1017).copy(alpha = 0.85f))

            // 4. Center Square Frame Outline
            val frameMargin = w * 0.15f
            val frameTop = h * 0.20f
            val frameSize = w - (frameMargin * 2)

            drawRect(
                color = Color.Black,
                topLeft = Offset(frameMargin, frameTop),
                size = Size(frameSize, frameSize),
                style = Stroke(width = 3.5.dp.toPx())
            )

            // 5. Silhouette of Walking Figure at bottom street
            val figureCenter = Offset(w * 0.5f, h * 0.82f)
            // Head
            drawCircle(color = Color(0xFF05080C), radius = 8.dp.toPx(), center = Offset(figureCenter.x, figureCenter.y - 20.dp.toPx()))
            // Body
            drawRoundRect(
                color = Color(0xFF05080C),
                topLeft = Offset(figureCenter.x - 10.dp.toPx(), figureCenter.y - 10.dp.toPx()),
                size = Size(20.dp.toPx(), 35.dp.toPx()),
                cornerRadius = CornerRadius(4.dp.toPx())
            )
        }

        // 6. Sound Wave Visualizer Graphic + Heart Icon in Center (Matching Image 2)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(110.dp))

            // Audio Waveform Graphic Bars (Black minimalist visualizer)
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.height(36.dp)
            ) {
                // Circle logo icon
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.GraphicEq,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Waveform vertical bars
                val barHeights = listOf(0.4f, 0.7f, 0.3f, 0.9f, 0.5f, 0.8f, 0.4f, 0.95f, 0.6f, 0.3f, 0.7f, 0.5f, 0.8f)
                barHeights.forEachIndexed { idx, hFactor ->
                    val animatedFactor = if (isPlaying) {
                        (hFactor + 0.3f * sin(barPhase + idx * 0.8f)).coerceIn(0.15f, 1f)
                    } else hFactor * 0.4f

                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height((28 * animatedFactor).dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color.Black)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Solid Black Heart
            Icon(
                imageVector = Icons.Rounded.Favorite,
                contentDescription = "Heart",
                tint = Color.Black,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

// --------------------------------------------------------------------------------------------------
// THEME 3: Glowing Score Notes (Cinematic Sheet Music + Floating 3D Music Notes)
// --------------------------------------------------------------------------------------------------
@Composable
fun GlowingNotesThemeView(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "ScoreNotesAnim")

    val floatAnim by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(3500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "FloatAnim"
    )

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF001F24))) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Dual-tone cinematic gradient (Teal Blue top left to Amber Gold bottom right)
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF00E5FF).copy(alpha = 0.30f),
                        Color(0xFF00363A),
                        Color(0xFF121212),
                        Color(0xFF4E2600).copy(alpha = 0.70f)
                    ),
                    center = Offset(w * 0.3f, h * 0.3f),
                    radius = w * 1.2f
                )
            )

            // Warm bottom right glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFFFB74D).copy(alpha = 0.60f),
                        Color(0xFFFF8F00).copy(alpha = 0.20f),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.85f, h * 0.75f),
                    radius = w * 0.7f
                ),
                center = Offset(w * 0.85f, h * 0.75f),
                radius = w * 0.7f
            )

            // 2. Perspective Stave Sheet Music Lines
            for (stave in 0 until 3) {
                val startY = h * (0.45f + stave * 0.18f)
                for (line in 0 until 5) {
                    val y = startY + line * 8.dp.toPx()
                    drawLine(
                        color = Color.White.copy(alpha = 0.25f),
                        start = Offset(0f, y - 20.dp.toPx()),
                        end = Offset(w, y + 20.dp.toPx()),
                        strokeWidth = 1.5.dp.toPx()
                    )
                }
            }
        }

        // 3. Floating 3D Musical Notes Overlay (Matching Image 3)
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val note1Offset = if (isPlaying) (12 * sin(floatAnim)).dp else 0.dp
            val note2Offset = if (isPlaying) (14 * cos(floatAnim + 1.5f)).dp else 0.dp

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Note 1 (♪)
                Text(
                    text = "♪",
                    fontSize = 80.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFFD54F),
                    style = androidx.compose.ui.text.TextStyle(
                        shadow = Shadow(Color(0xFF00E5FF), blurRadius = 16f)
                    ),
                    modifier = Modifier.offset(y = note1Offset, x = (-30).dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Note 2 (♫)
                Text(
                    text = "♫",
                    fontSize = 96.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFE0F7FA),
                    style = androidx.compose.ui.text.TextStyle(
                        shadow = Shadow(Color(0xFFFF8F00), blurRadius = 24f)
                    ),
                    modifier = Modifier.offset(y = note2Offset, x = 30.dp)
                )
            }
        }
    }
}

// --------------------------------------------------------------------------------------------------
// THEME 4: Headphones Wave (White Line-art Headphones + Center Sound Wave)
// --------------------------------------------------------------------------------------------------
@Composable
fun HeadphonesWaveThemeView(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "HeadphonesWaveAnim")

    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "WavePhase"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val cx = w / 2f
            val cy = h * 0.42f

            // 1. Headphones Headband (Arch)
            val headbandPath = Path().apply {
                moveTo(cx - 100.dp.toPx(), cy + 20.dp.toPx())
                cubicTo(
                    cx - 100.dp.toPx(), cy - 120.dp.toPx(),
                    cx + 100.dp.toPx(), cy - 120.dp.toPx(),
                    cx + 100.dp.toPx(), cy + 20.dp.toPx()
                )
            }
            drawPath(
                path = headbandPath,
                color = Color.White,
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )

            // Headband Cushion bumps
            for (b in -2..2) {
                drawCircle(
                    color = Color.White,
                    radius = 4.dp.toPx(),
                    center = Offset(cx + (b * 16).dp.toPx(), cy - 92.dp.toPx())
                )
            }

            // 2. Left Earcup Outline
            val leftCup = Path().apply {
                addRoundRect(
                    androidx.compose.ui.geometry.RoundRect(
                        rect = Rect(cx - 120.dp.toPx(), cy - 20.dp.toPx(), cx - 80.dp.toPx(), cy + 70.dp.toPx()),
                        cornerRadius = CornerRadius(16.dp.toPx())
                    )
                )
            }
            drawPath(path = leftCup, color = Color.White, style = Stroke(width = 3.dp.toPx()))

            // 3. Right Earcup Outline
            val rightCup = Path().apply {
                addRoundRect(
                    androidx.compose.ui.geometry.RoundRect(
                        rect = Rect(cx + 80.dp.toPx(), cy - 20.dp.toPx(), cx + 120.dp.toPx(), cy + 70.dp.toPx()),
                        cornerRadius = CornerRadius(16.dp.toPx())
                    )
                )
            }
            drawPath(path = rightCup, color = Color.White, style = Stroke(width = 3.dp.toPx()))
        }

        // 4. Center Audio Sound Wave Equalizer (Inside Headphones)
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .height(80.dp)
                .offset(y = (-40).dp)
        ) {
            val barHeights = listOf(0.2f, 0.4f, 0.7f, 0.9f, 0.5f, 1.0f, 0.6f, 0.8f, 0.4f, 0.9f, 0.3f, 0.6f, 0.2f)
            barHeights.forEachIndexed { i, factor ->
                val dynamicH = if (isPlaying) {
                    (factor + 0.35f * sin(wavePhase + i * 0.7f)).coerceIn(0.1f, 1f)
                } else factor * 0.3f

                Box(
                    modifier = Modifier
                        .width(4.dp)
                        .height((50 * dynamicH).dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color.White)
                )
            }
        }
    }
}

// --------------------------------------------------------------------------------------------------
// THEME 5: Music Collage (Monochrome Grid + Floating Player Frame Card)
// --------------------------------------------------------------------------------------------------
@Composable
fun DarkCollageThemeView(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "CollageAnim")

    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseGlow"
    )

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF101010))) {
        // 1. Monochrome Grid background tiles
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            for (row in 0..4) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (col in 0..2) {
                        Box(
                            modifier = Modifier
                                .size(100.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.03f))
                                .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if ((row + col) % 2 == 0) Icons.Rounded.Album else Icons.Rounded.Headphones,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.12f),
                                modifier = Modifier.size(40.dp)
                            )
                        }
                    }
                }
            }
        }

        // 2. Floating Smartphone Glassmorphic Frame in Center (Matching Image 5)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 60.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .width(280.dp)
                    .height(340.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xFF222222).copy(alpha = 0.92f))
                    .border(1.5.dp, Color.White.copy(alpha = 0.20f), RoundedCornerShape(28.dp))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Inner Screen Placeholder
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        // Pulsing status dot
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(if (isPlaying) Color(0xFF2ECC71).copy(alpha = pulseGlow) else Color.Gray)
                        )
                    }

                    // Device label
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Phone", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Icon(Icons.Rounded.Cast, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                    }

                    // Timeline line
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.2f))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(if (isPlaying) 0.45f else 0.1f)
                                .background(Color.White)
                        )
                    }

                    // Playback icons row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.SkipPrevious, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                        Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
                        Icon(Icons.Rounded.SkipNext, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                }
            }
        }
    }
}

// --------------------------------------------------------------------------------------------------
// PREMIUM THEME: Cyber Neon Feel (Vibrant Audio Spectrum Waves + Space Nebula Glow + Neon Heart)
// --------------------------------------------------------------------------------------------------
@Composable
fun CyberNeonFeelThemeView(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "CyberNeonAnim")

    // Wave phase animation for visualizer bars (active only when isPlaying)
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "WavePhase"
    )

    // Glow pulse for outer neon border
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "GlowPulse"
    )

    val currentWavePhase = if (isPlaying) wavePhase else 0f

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF060212))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Cosmic Deep Sky Gradient
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF060212),
                        Color(0xFF13062B),
                        Color(0xFF1B0A3A),
                        Color(0xFF0D031F),
                        Color(0xFF060111)
                    )
                )
            )

            // 2. Center Ambient Glowing Aura behind Album Art
            val auraCenter = Offset(w * 0.5f, h * 0.36f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFBD00FF).copy(alpha = 0.35f * glowPulse),
                        Color(0xFF00F0FF).copy(alpha = 0.20f * glowPulse),
                        Color.Transparent
                    ),
                    center = auraCenter,
                    radius = w * 0.55f
                ),
                center = auraCenter,
                radius = w * 0.55f
            )

            // 3. Starry Nebula Dust Twinkling
            val starPositions = listOf(
                Offset(w * 0.12f, h * 0.08f), Offset(w * 0.88f, h * 0.12f),
                Offset(w * 0.22f, h * 0.22f), Offset(w * 0.80f, h * 0.28f),
                Offset(w * 0.08f, h * 0.52f), Offset(w * 0.92f, h * 0.58f),
                Offset(w * 0.18f, h * 0.72f), Offset(w * 0.82f, h * 0.78f)
            )
            starPositions.forEachIndexed { i, pos ->
                val alpha = (0.3f + 0.5f * sin(currentWavePhase + i * 1.5f)).coerceIn(0.1f, 1f)
                drawCircle(
                    color = if (i % 2 == 0) Color(0xFF00F0FF).copy(alpha = alpha) else Color(0xFFFF00D6).copy(alpha = alpha),
                    radius = 2.5f,
                    center = pos
                )
            }

            // 4. Left Neon Visualizer Waves (Magenta / Purple)
            val leftXStart = w * 0.04f
            val leftXEnd = w * 0.18f
            val barCount = 10
            val barSpacing = (leftXEnd - leftXStart) / barCount
            val centerY = h * 0.36f
            val maxBarH = h * 0.16f

            for (i in 0 until barCount) {
                val x = leftXStart + i * barSpacing
                val factor = listOf(0.3f, 0.6f, 0.9f, 0.4f, 0.8f, 0.5f, 1.0f, 0.7f, 0.4f, 0.8f)[i % 10]
                val hFactor = if (isPlaying) {
                    (factor + 0.35f * sin(currentWavePhase + i * 0.8f)).coerceIn(0.15f, 1f)
                } else factor * 0.35f

                val barH = maxBarH * hFactor
                val alpha = (0.6f + 0.4f * hFactor).coerceIn(0.3f, 1f)

                drawLine(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFFFF00D6).copy(alpha = alpha),
                            Color(0xFFBD00FF).copy(alpha = alpha),
                            Color(0xFF7000FF).copy(alpha = alpha * 0.5f)
                        )
                    ),
                    start = Offset(x, centerY - barH / 2f),
                    end = Offset(x, centerY + barH / 2f),
                    strokeWidth = 3.5.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // 5. Right Neon Visualizer Waves (Cyan / Electric Blue)
            val rightXStart = w * 0.82f
            val rightXEnd = w * 0.96f
            val rightSpacing = (rightXEnd - rightXStart) / barCount

            for (i in 0 until barCount) {
                val x = rightXStart + i * rightSpacing
                val factor = listOf(0.7f, 0.4f, 0.8f, 1.0f, 0.5f, 0.9f, 0.3f, 0.8f, 0.6f, 0.3f)[i % 10]
                val hFactor = if (isPlaying) {
                    (factor + 0.35f * cos(currentWavePhase + i * 0.8f)).coerceIn(0.15f, 1f)
                } else factor * 0.35f

                val barH = maxBarH * hFactor
                val alpha = (0.6f + 0.4f * hFactor).coerceIn(0.3f, 1f)

                drawLine(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF00F0FF).copy(alpha = alpha),
                            Color(0xFF0080FF).copy(alpha = alpha),
                            Color(0xFF0033FF).copy(alpha = alpha * 0.5f)
                        )
                    ),
                    start = Offset(x, centerY - barH / 2f),
                    end = Offset(x, centerY + barH / 2f),
                    strokeWidth = 3.5.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }
    }
}
