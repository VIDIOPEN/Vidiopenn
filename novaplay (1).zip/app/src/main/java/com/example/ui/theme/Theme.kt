package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle

val LocalIsLightTheme = staticCompositionLocalOf { false }

private val DarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    secondary = RoyalPurple,
    background = PureBlack,
    surface = DarkGray,
    onPrimary = PureBlack,
    onSecondary = TextPrimary,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

private val LightColorScheme = lightColorScheme(
    primary = ElectricBlue,
    secondary = RoyalPurple,
    background = Color(0xFFF8FAFC),
    surface = Color(0xFFFFFFFF),
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = Color.Black,
    onSurface = Color.Black
)

@Composable
fun MyApplicationTheme(
    isLightTheme: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (isLightTheme) LightColorScheme else DarkColorScheme

    CompositionLocalProvider(
        LocalIsLightTheme provides isLightTheme,
        LocalContentColor provides (if (isLightTheme) Color.Black else TextPrimary),
        LocalTextStyle provides TextStyle(color = if (isLightTheme) Color.Black else Color.White)
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}

