package com.example.ui.viewmodel

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.VaultEntity
import com.example.data.repository.MediaRepository
import com.example.utils.CryptoManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID

class VaultViewModel(
    application: Application,
    private val repository: MediaRepository
) : AndroidViewModel(application) {

    private val context = application.applicationContext

    // Unlock Preferred Method: "PIN", "PATTERN", "PASSWORD"
    private val _unlockMethod = MutableStateFlow("PIN")
    val unlockMethod: StateFlow<String> = _unlockMethod.asStateFlow()

    // Unlock Status
    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    // KeyStore Hashed Credentials
    private val _vaultPinHash = MutableStateFlow<String?>(null)
    private val _vaultPatternHash = MutableStateFlow<String?>(null)
    private val _vaultPasswordHash = MutableStateFlow<String?>(null)

    // Public getters for credentials existence
    private val _hasPin = MutableStateFlow(false)
    val hasPin: StateFlow<Boolean> = _hasPin.asStateFlow()

    private val _hasPattern = MutableStateFlow(false)
    val hasPattern: StateFlow<Boolean> = _hasPattern.asStateFlow()

    private val _hasPassword = MutableStateFlow(false)
    val hasPassword: StateFlow<Boolean> = _hasPassword.asStateFlow()

    // Biometric Preferences
    private val _isBiometricEnabled = MutableStateFlow(false)
    val isBiometricEnabled: StateFlow<Boolean> = _isBiometricEnabled.asStateFlow()

    // Auto-Lock Timeout Preference (in seconds: 0 = immediate, 15, 30, 60, 300)
    private val _autoLockTimeout = MutableStateFlow(0)
    val autoLockTimeout: StateFlow<Int> = _autoLockTimeout.asStateFlow()

    // Active Section: "HOME", "VIDEOS", "PHOTOS", "AUDIO", "DOCUMENTS", "FAVORITES", "RECENT"
    private val _activeSection = MutableStateFlow("HOME")
    val activeSection: StateFlow<String> = _activeSection.asStateFlow()

    // Current playing/viewing decrypted temporary media
    private val _activeDecryptedFile = MutableStateFlow<File?>(null)
    val activeDecryptedFile: StateFlow<File?> = _activeDecryptedFile.asStateFlow()

    private val _activeDecryptedItem = MutableStateFlow<VaultEntity?>(null)
    val activeDecryptedItem: StateFlow<VaultEntity?> = _activeDecryptedItem.asStateFlow()

    private val _isDecrypting = MutableStateFlow(false)
    val isDecrypting: StateFlow<Boolean> = _isDecrypting.asStateFlow()

    // All items from local Room Database
    val vaultItems: StateFlow<List<VaultEntity>> = repository.vaultItems
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Filtered lists for Vault Home Sections
    val videos: StateFlow<List<VaultEntity>> = vaultItems
        .map { items -> items.filter { it.type == "VIDEO" } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val photos: StateFlow<List<VaultEntity>> = vaultItems
        .map { items -> items.filter { it.type == "PHOTO" } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val audio: StateFlow<List<VaultEntity>> = vaultItems
        .map { items -> items.filter { it.type == "AUDIO" } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val documents: StateFlow<List<VaultEntity>> = vaultItems
        .map { items -> items.filter { it.type == "DOCUMENT" } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val favorites: StateFlow<List<VaultEntity>> = vaultItems
        .map { items -> items.filter { it.isFavorite } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val recentlyAdded: StateFlow<List<VaultEntity>> = vaultItems
        .map { items -> items.sortedByDescending { it.addedDate }.take(10) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Tracks background/foreground times for timeout lock
    private var backgroundTimestamp: Long = 0L

    // Screen-off BroadcastReceiver
    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                Timber.d("VaultViewModel: Screen off detected, locking vault.")
                lock()
            }
        }
    }

    init {
        loadSettings()
        registerScreenOffReceiver()
    }

    private fun loadSettings() {
        viewModelScope.launch {
            _unlockMethod.value = repository.getConfig("vault_unlock_method") ?: "PIN"
            _vaultPinHash.value = repository.getConfig("vault_pin_hash")
            _vaultPatternHash.value = repository.getConfig("vault_pattern_hash")
            _vaultPasswordHash.value = repository.getConfig("vault_password_hash")
            _isBiometricEnabled.value = (repository.getConfig("vault_biometric_enabled") ?: "false").toBoolean()
            _autoLockTimeout.value = (repository.getConfig("vault_auto_lock_timeout") ?: "0").toInt()

            _hasPin.value = !_vaultPinHash.value.isNullOrEmpty()
            _hasPattern.value = !_vaultPatternHash.value.isNullOrEmpty()
            _hasPassword.value = !_vaultPasswordHash.value.isNullOrEmpty()

            Timber.d("VaultViewModel: Loaded secure settings. Method: %s, Biometric: %s, Timeout: %d", 
                _unlockMethod.value, _isBiometricEnabled.value, _autoLockTimeout.value)
        }
    }

    private fun registerScreenOffReceiver() {
        try {
            val filter = IntentFilter(Intent.ACTION_SCREEN_OFF)
            context.registerReceiver(screenOffReceiver, filter)
        } catch (e: Exception) {
            Timber.e(e, "VaultViewModel: Failed to register screen off receiver")
        }
    }

    override fun onCleared() {
        super.onCleared()
        try {
            context.unregisterReceiver(screenOffReceiver)
        } catch (e: Exception) {
            // Already unregistered
        }
        cleanUpDecryptedTempFiles()
    }

    // --- Preferred Method Actions ---
    fun setUnlockMethod(method: String) {
        viewModelScope.launch {
            repository.setConfig("vault_unlock_method", method)
            _unlockMethod.value = method
        }
    }

    fun setBiometricEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setConfig("vault_biometric_enabled", enabled.toString())
            _isBiometricEnabled.value = enabled
        }
    }

    fun setAutoLockTimeout(timeoutSeconds: Int) {
        viewModelScope.launch {
            repository.setConfig("vault_auto_lock_timeout", timeoutSeconds.toString())
            _autoLockTimeout.value = timeoutSeconds
        }
    }

    // --- Hash Helper (SHA-256 for credentials verification) ---
    private fun hashCredential(value: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(value.toByteArray(Charsets.UTF_8))
            hash.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            Timber.e(e, "VaultViewModel: SHA-256 hashing failed")
            value // Fallback (should never happen)
        }
    }

    fun savePin(pin: String) {
        viewModelScope.launch {
            val hashed = hashCredential(pin)
            repository.setConfig("vault_pin_hash", hashed)
            _vaultPinHash.value = hashed
            _hasPin.value = true
            _isUnlocked.value = true
        }
    }

    fun savePattern(pattern: String) {
        viewModelScope.launch {
            val hashed = hashCredential(pattern)
            repository.setConfig("vault_pattern_hash", hashed)
            _vaultPatternHash.value = hashed
            _hasPattern.value = true
            _isUnlocked.value = true
        }
    }

    fun savePassword(password: String) {
        viewModelScope.launch {
            val hashed = hashCredential(password)
            repository.setConfig("vault_password_hash", hashed)
            _vaultPasswordHash.value = hashed
            _hasPassword.value = true
            _isUnlocked.value = true
        }
    }

    fun resetPin() {
        viewModelScope.launch {
            repository.setConfig("vault_pin_hash", "")
            _vaultPinHash.value = ""
            _hasPin.value = false
            _isUnlocked.value = false
        }
    }

    // --- Credentials Verification ---
    fun verifyUnlock(attempt: String): Boolean {
        val expectedHash = when (_unlockMethod.value) {
            "PIN" -> _vaultPinHash.value
            "PATTERN" -> _vaultPatternHash.value
            "PASSWORD" -> _vaultPasswordHash.value
            else -> null
        }
        val attemptHash = hashCredential(attempt)
        val matches = expectedHash != null && expectedHash == attemptHash
        if (matches) {
            _isUnlocked.value = true
            Timber.d("VaultViewModel: Unlock verification succeeded using %s", _unlockMethod.value)
        } else {
            Timber.d("VaultViewModel: Unlock verification failed")
        }
        return matches
    }

    fun verifyBiometricSuccess() {
        _isUnlocked.value = true
        Timber.d("VaultViewModel: Unlock verification succeeded via Biometrics")
    }

    // --- Lock and Auto-Lock LifeCycle Hooks ---
    fun lock() {
        _isUnlocked.value = false
        _activeDecryptedFile.value = null
        _activeDecryptedItem.value = null
        cleanUpDecryptedTempFiles()
        Timber.d("VaultViewModel: Vault has been locked.")
    }

    fun unlockDirectly() {
        _isUnlocked.value = true
    }

    private var isLockingSuspended = false

    fun suspendLocking(suspend: Boolean) {
        isLockingSuspended = suspend
        Timber.d("VaultViewModel: suspendLocking = $suspend")
    }

    fun onAppGoToBackground() {
        if (isLockingSuspended) {
            Timber.d("VaultViewModel: App going to background, but locking is suspended (e.g., file picker active).")
            return
        }
        backgroundTimestamp = System.currentTimeMillis()
        if (_autoLockTimeout.value == 0) {
            Timber.d("VaultViewModel: App going to background with immediate lock timeout.")
            lock()
        }
    }

    fun onAppReturnToForeground() {
        backgroundTimestamp = System.currentTimeMillis()
        if (isLockingSuspended) {
            Timber.d("VaultViewModel: Returning from suspended lock (e.g., file picker active).")
            return
        }
        if (!_isUnlocked.value) return // Already locked, nothing to do
        val elapsedSeconds = (System.currentTimeMillis() - backgroundTimestamp) / 1000
        if (_autoLockTimeout.value > 0 && elapsedSeconds >= _autoLockTimeout.value) {
            Timber.d("VaultViewModel: Background timeout of %d seconds exceeded (%d seconds elapsed). Locking vault.", 
                _autoLockTimeout.value, elapsedSeconds)
            lock()
        }
    }

    // --- Section Nav ---
    fun setActiveSection(section: String) {
        _activeSection.value = section
    }

    // --- Encryption / Decryption Vault File Imports ---
    fun importFileFromUri(
        uri: Uri,
        type: String, // "VIDEO", "PHOTO", "AUDIO", "DOCUMENT"
        customTitle: String? = null,
        onImportSuccess: ((deleteOriginalAction: () -> Unit) -> Unit)? = null,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Try taking persistable permission if possible
                try {
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) {
                    // Ignore if not supported for this Uri
                }

                val contentResolver = context.contentResolver
                var fileName = "imported_file_${System.currentTimeMillis()}"
                var fileSize = 0L
                var originalPath: String? = null

                // Query metadata and real data path if available
                try {
                    val projection = arrayOf(
                        OpenableColumns.DISPLAY_NAME,
                        OpenableColumns.SIZE,
                        android.provider.MediaStore.MediaColumns.DATA
                    )
                    contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                        if (cursor.moveToFirst()) {
                            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                            val dataIdx = cursor.getColumnIndex(android.provider.MediaStore.MediaColumns.DATA)
                            if (nameIdx != -1) cursor.getString(nameIdx)?.let { if (it.isNotEmpty()) fileName = it }
                            if (sizeIdx != -1) fileSize = cursor.getLong(sizeIdx)
                            if (dataIdx != -1) originalPath = cursor.getString(dataIdx)
                        }
                    }
                } catch (e: Exception) {
                    Timber.e(e, "VaultViewModel: Metadata query error")
                }

                if (originalPath.isNullOrEmpty()) {
                    if (uri.scheme == "file") {
                        originalPath = uri.path
                    } else if (uri.path?.contains("/storage/") == true) {
                        val p = uri.path!!
                        originalPath = if (p.contains(":/")) {
                            "/storage/emulated/0/" + p.substringAfter(":/")
                        } else if (p.startsWith("/storage/")) {
                            p
                        } else {
                            "/storage/emulated/0/" + p.substringAfter("/document/", "").substringAfter(":")
                        }
                    }
                }

                val finalTitle = customTitle ?: fileName

                // Destination secure file in vault folder
                val vaultDir = File(context.filesDir, "vidiopen_vault")
                if (!vaultDir.exists()) vaultDir.mkdirs()

                val secureFileName = "enc_${UUID.randomUUID()}"
                val secureDestFile = File(vaultDir, secureFileName)

                var success = false
                try {
                    contentResolver.openInputStream(uri)?.use { inputStream ->
                        success = CryptoManager.encryptStream(inputStream, secureDestFile)
                    }
                } catch (e: Exception) {
                    Timber.e(e, "VaultViewModel: InputStream encryption error")
                }

                if (!success || !secureDestFile.exists() || secureDestFile.length() == 0L) {
                    if (secureDestFile.exists()) secureDestFile.delete()
                    withContext(Dispatchers.Main) {
                        onError("Failed to encrypt and secure file.")
                    }
                    return@launch
                }

                if (fileSize == 0L) {
                    fileSize = secureDestFile.length()
                }

                val newItem = VaultEntity(
                    title = finalTitle,
                    path = secureDestFile.absolutePath,
                    type = type,
                    size = fileSize,
                    isFavorite = false,
                    addedDate = System.currentTimeMillis()
                )
                repository.insertVaultItem(newItem)

                // Helper lambda to delete original unencrypted file permanently so it disappears from gallery & phone
                val deleteOriginalAction: () -> Unit = {
                    viewModelScope.launch(Dispatchers.IO) {
                        // 1. ContentResolver delete
                        try {
                            if (uri.scheme == "content") {
                                contentResolver.delete(uri, null, null)
                            }
                        } catch (e: Exception) {
                            Timber.e(e, "Failed to delete uri from ContentResolver")
                        }

                        // 2. Physical file delete and MediaScanner scan
                        try {
                            val pathToDelete = originalPath
                            if (!pathToDelete.isNullOrEmpty()) {
                                val origFile = File(pathToDelete)
                                if (origFile.exists()) {
                                    origFile.delete()
                                }
                                try {
                                    android.media.MediaScannerConnection.scanFile(
                                        context,
                                        arrayOf(pathToDelete),
                                        null,
                                        null
                                    )
                                } catch (e: Exception) {
                                    Timber.e(e, "Failed to rescan deleted file")
                                }
                            }
                        } catch (e: Exception) {
                            Timber.e(e, "Failed to delete original file from disk")
                        }

                        // 3. Remove matching media items from repository / mediaDao
                        try {
                            val uriStr = uri.toString()
                            val mediaList = repository.allMedia.firstOrNull() ?: emptyList()
                            for (media in mediaList) {
                                if (media.url == uriStr || 
                                    (originalPath != null && media.url == originalPath) || 
                                    media.title == fileName ||
                                    media.title == finalTitle ||
                                    (fileName.contains(".") && media.title == fileName.substringBeforeLast(".")) ||
                                    (finalTitle.contains(".") && media.title == finalTitle.substringBeforeLast("."))
                                ) {
                                    repository.deleteMedia(media.id)
                                }
                            }
                        } catch (e: Exception) {
                            Timber.e(e, "Failed to remove item from mediaDao")
                        }
                    }
                }

                withContext(Dispatchers.Main) {
                    if (onImportSuccess != null) {
                        onImportSuccess(deleteOriginalAction)
                    } else {
                        deleteOriginalAction()
                    }
                }

                Timber.d("VaultViewModel: Successfully imported %s securely.", fileName)
            } catch (e: Exception) {
                Timber.e(e, "VaultViewModel: File import failed")
                withContext(Dispatchers.Main) {
                    onError(e.localizedMessage ?: "Unknown file import error.")
                }
            }
        }
    }

    private fun isUnencryptedMediaFile(file: File): Boolean {
        if (!file.exists() || file.length() < 8) return false
        try {
            val header = ByteArray(12)
            FileInputStream(file).use { fis ->
                val read = fis.read(header, 0, 12)
                if (read < 8) return false
            }
            // JPEG: FF D8 FF
            if ((header[0].toInt() and 0xFF) == 0xFF && (header[1].toInt() and 0xFF) == 0xD8 && (header[2].toInt() and 0xFF) == 0xFF) return true
            // PNG: 89 50 4E 47
            if ((header[0].toInt() and 0xFF) == 0x89 && header[1] == 'P'.code.toByte() && header[2] == 'N'.code.toByte() && header[3] == 'G'.code.toByte()) return true
            // GIF: GIF
            if (header[0] == 'G'.code.toByte() && header[1] == 'I'.code.toByte() && header[2] == 'F'.code.toByte()) return true
            // RIFF (WEBP / WAV / AVI)
            if (header[0] == 'R'.code.toByte() && header[1] == 'I'.code.toByte() && header[2] == 'F'.code.toByte() && header[3] == 'F'.code.toByte()) return true
            // ftyp (MP4, MOV, 3GP)
            if (header.size >= 8 && header[4] == 'f'.code.toByte() && header[5] == 't'.code.toByte() && header[6] == 'y'.code.toByte() && header[7] == 'p'.code.toByte()) return true
            if (header[0] == 0.toByte() && header[1] == 0.toByte() && header[2] == 0.toByte()) return true
            // MKV / WEBM: 1A 45 DF A3
            if ((header[0].toInt() and 0xFF) == 0x1A && (header[1].toInt() and 0xFF) == 0x45) return true
            // ID3 (MP3)
            if (header[0] == 'I'.code.toByte() && header[1] == 'D'.code.toByte() && header[2] == '3'.code.toByte()) return true
            // MP3 sync frame: FF FB / FF F3 / FF F2
            if ((header[0].toInt() and 0xFF) == 0xFF && ((header[1].toInt() and 0xE0) == 0xE0)) return true
            // PDF: %PDF
            if (header[0] == '%'.code.toByte() && header[1] == 'P'.code.toByte() && header[2] == 'D'.code.toByte() && header[3] == 'F'.code.toByte()) return true
            // FLAC: fLaC
            if (header[0] == 'f'.code.toByte() && header[1] == 'L'.code.toByte() && header[2] == 'a'.code.toByte() && header[3] == 'C'.code.toByte()) return true
            // OGG: OggS
            if (header[0] == 'O'.code.toByte() && header[1] == 'g'.code.toByte() && header[2] == 'g'.code.toByte() && header[3] == 'S'.code.toByte()) return true
        } catch (e: Exception) {
            // Ignore
        }
        return false
    }

    // --- Play / View directly inside Vault ---
    fun selectItemForPlaybackOrView(item: VaultEntity, onError: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val playDir = File(context.cacheDir, "temp_vault_play")
                if (!playDir.exists()) playDir.mkdirs()

                // Determine correct file extension for media players/decoders
                var ext = if (item.title.contains(".")) item.title.substringAfterLast(".").lowercase() else ""
                if (ext.isEmpty() || ext.length > 5) {
                    ext = when (item.type) {
                        "VIDEO" -> "mp4"
                        "PHOTO" -> "jpg"
                        "AUDIO" -> "mp3"
                        "DOCUMENT" -> "pdf"
                        else -> "bin"
                    }
                }

                val itemHash = item.id.hashCode()
                val encryptedFile = File(item.path)

                if (!encryptedFile.exists() && item.path.startsWith("content://")) {
                    val tempPlayFile = File(playDir, "play_${itemHash}.$ext")
                    if (tempPlayFile.exists() && tempPlayFile.length() > 0L) {
                        _activeDecryptedFile.value = tempPlayFile
                        _activeDecryptedItem.value = item
                        return@launch
                    }
                    _isDecrypting.value = true
                    try {
                        val uri = android.net.Uri.parse(item.path)
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            FileOutputStream(tempPlayFile).use { output ->
                                input.copyTo(output)
                            }
                        }
                    } catch (e: Exception) {
                        Timber.e(e, "Content Uri copy failed")
                    } finally {
                        _isDecrypting.value = false
                    }
                    if (tempPlayFile.exists() && tempPlayFile.length() > 0L) {
                        _activeDecryptedFile.value = tempPlayFile
                        _activeDecryptedItem.value = item
                    } else {
                        withContext(Dispatchers.Main) { onError("Failed to load file.") }
                    }
                    return@launch
                }

                if (!encryptedFile.exists()) {
                    withContext(Dispatchers.Main) { onError("Vault file does not exist.") }
                    return@launch
                }

                // Check if file is already unencrypted (e.g. standard MP4, JPG, PNG, MP3)
                if (isUnencryptedMediaFile(encryptedFile)) {
                    val tempPlayFile = File(playDir, "play_${itemHash}_${encryptedFile.lastModified()}.$ext")
                    if (tempPlayFile.exists() && tempPlayFile.length() > 0L) {
                        _activeDecryptedFile.value = tempPlayFile
                        _activeDecryptedItem.value = item
                        return@launch
                    }

                    // Try creating hard link (instant 0.001s, zero copy)
                    var linked = false
                    try {
                        android.system.Os.link(encryptedFile.absolutePath, tempPlayFile.absolutePath)
                        linked = tempPlayFile.exists() && tempPlayFile.length() > 0L
                    } catch (e: Exception) {
                        linked = false
                    }

                    if (!linked) {
                        try {
                            encryptedFile.copyTo(tempPlayFile, overwrite = true)
                        } catch (e: Exception) {
                            Timber.e(e, "Copy unencrypted file failed")
                        }
                    }

                    val finalFile = if (tempPlayFile.exists() && tempPlayFile.length() > 0L) tempPlayFile else encryptedFile
                    _activeDecryptedFile.value = finalFile
                    _activeDecryptedItem.value = item
                    return@launch
                }

                // File is AES encrypted - check cache first
                val tempPlayFile = File(playDir, "play_${itemHash}_${encryptedFile.lastModified()}.$ext")
                if (tempPlayFile.exists() && tempPlayFile.length() > 0L) {
                    _activeDecryptedFile.value = tempPlayFile
                    _activeDecryptedItem.value = item
                    return@launch
                }

                // Decrypt file asynchronously with progress indication
                _isDecrypting.value = true
                var success = false
                try {
                    success = CryptoManager.decryptFile(encryptedFile, tempPlayFile)
                    if (!success || tempPlayFile.length() == 0L) {
                        encryptedFile.copyTo(tempPlayFile, overwrite = true)
                        success = tempPlayFile.exists() && tempPlayFile.length() > 0L
                    }
                } catch (e: Exception) {
                    Timber.e(e, "Decryption error")
                } finally {
                    _isDecrypting.value = false
                }

                if (success && tempPlayFile.exists() && tempPlayFile.length() > 0L) {
                    _activeDecryptedFile.value = tempPlayFile
                    _activeDecryptedItem.value = item
                    Timber.d("VaultViewModel: Decrypted item for immediate play/view: %s", tempPlayFile.absolutePath)
                } else {
                    withContext(Dispatchers.Main) { onError("Failed to load vault file.") }
                }
            } catch (e: Exception) {
                Timber.e(e, "VaultViewModel: Playback preparation failed")
                _isDecrypting.value = false
                withContext(Dispatchers.Main) { onError(e.localizedMessage ?: "Unknown decryption error.") }
            }
        }
    }

    fun dismissActiveViewer() {
        _activeDecryptedFile.value = null
        _activeDecryptedItem.value = null
        cleanUpDecryptedTempFiles()
    }

    private fun cleanUpDecryptedTempFiles() {
        try {
            val playDir = File(context.cacheDir, "temp_vault_play")
            if (playDir.exists()) {
                playDir.listFiles()?.forEach { file ->
                    file.delete()
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "VaultViewModel: Failed to clean up temp decrypted cache")
        }
    }

    // --- Toggle Favorite ---
    fun toggleVaultFavorite(item: VaultEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleVaultFavorite(item.id, !item.isFavorite)
        }
    }

    // --- Delete Vault Item ---
    fun deleteVaultItem(item: VaultEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = File(item.path)
                if (file.exists()) {
                    file.delete()
                }
                repository.deleteVaultItem(item.id)
                Timber.d("VaultViewModel: Deleted vault item and its encrypted file: %s", item.title)
            } catch (e: Exception) {
                Timber.e(e, "VaultViewModel: Failed to delete vault item %s", item.title)
            }
        }
    }

    // --- Export Vault Item back to public storage / standard cache ---
    fun exportVaultItem(item: VaultEntity, exportDir: File, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (!exportDir.exists()) exportDir.mkdirs()
                val destFile = File(exportDir, item.title)
                val sourceFile = File(item.path)

                val success = CryptoManager.decryptFile(sourceFile, destFile)
                if (success) {
                    withContext(Dispatchers.Main) {
                        onSuccess("Successfully exported to: ${destFile.absolutePath}")
                    }
                    Timber.d("VaultViewModel: Successfully decrypted and exported %s", destFile.absolutePath)
                } else {
                    withContext(Dispatchers.Main) {
                        onError("Failed to decrypt and export file.")
                    }
                }
            } catch (e: Exception) {
                Timber.e(e, "VaultViewModel: Export failed")
                withContext(Dispatchers.Main) {
                    onError(e.localizedMessage ?: "Unknown export error.")
                }
            }
        }
    }
}

class VaultViewModelFactory(
    private val application: Application,
    private val repository: MediaRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(VaultViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return VaultViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
