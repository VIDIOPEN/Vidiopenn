package com.example.utils

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import timber.log.Timber

fun Context.findActivity(): Activity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}

object StartAppInterstitialHelper {

    fun isNetworkAvailable(context: Context): Boolean {
        return try {
            val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager ?: return false
            val activeNetwork = connectivityManager.activeNetwork ?: return false
            val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
            capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            false
        }
    }

    fun initAndLoad(context: Context) {
        // Ads removed
    }

    fun loadAd() {
        // Ads removed
    }

    fun showAd(context: Context, onAdClosed: () -> Unit = {}) {
        try {
            onAdClosed()
        } catch (e: Throwable) {
            Timber.e(e, "StartAppInterstitial: Error in onAdClosed callback")
        }
    }

    fun showMultipleAds(context: Context, count: Int, onComplete: () -> Unit = {}) {
        try {
            onComplete()
        } catch (e: Throwable) {
            Timber.e(e, "StartAppInterstitial: Error in showMultipleAds onComplete")
        }
    }

    fun showRewardedVideoAd(context: Context, onRewarded: () -> Unit) {
        try {
            onRewarded()
        } catch (e: Throwable) {
            Timber.e(e, "StartAppRewarded: Error in onRewarded callback")
        }
    }
}

