package com.example.utils

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.example.data.model.TransferFile
import timber.log.Timber
import java.io.File

object FileScannerUtil {

    fun scanFiles(context: Context, category: String): List<TransferFile> {
        return when (category) {
            "VIDEO" -> scanVideos(context)
            "PHOTO" -> scanPhotos(context)
            "MUSIC" -> scanMusic(context)
            "DOCUMENT" -> scanDocuments(context)
            "APK" -> scanApks(context)
            else -> emptyList()
        }
    }

    private fun scanVideos(context: Context): List<TransferFile> {
        val result = mutableListOf<TransferFile>()
        val uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.DATE_MODIFIED
        )
        context.contentResolver.query(uri, projection, null, null, "${MediaStore.Video.Media.DATE_MODIFIED} DESC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)

            while (cursor.moveToNext()) {
                val path = cursor.getString(dataCol) ?: continue
                val file = File(path)
                if (file.exists() && file.length() > 0) {
                    val ext = file.extension.lowercase()
                    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "video/*"
                    result.add(
                        TransferFile(
                            id = cursor.getString(idCol),
                            name = cursor.getString(nameCol) ?: file.name,
                            size = cursor.getLong(sizeCol),
                            path = path,
                            type = "VIDEO",
                            mimeType = mime,
                            dateModified = cursor.getLong(dateCol) * 1000
                        )
                    )
                }
            }
        }
        return result
    }

    private fun scanPhotos(context: Context): List<TransferFile> {
        val result = mutableListOf<TransferFile>()
        val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.DATA,
            MediaStore.Images.Media.DATE_MODIFIED
        )
        context.contentResolver.query(uri, projection, null, null, "${MediaStore.Images.Media.DATE_MODIFIED} DESC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)

            while (cursor.moveToNext()) {
                val path = cursor.getString(dataCol) ?: continue
                val file = File(path)
                if (file.exists() && file.length() > 0) {
                    val ext = file.extension.lowercase()
                    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "image/*"
                    result.add(
                        TransferFile(
                            id = cursor.getString(idCol),
                            name = cursor.getString(nameCol) ?: file.name,
                            size = cursor.getLong(sizeCol),
                            path = path,
                            type = "PHOTO",
                            mimeType = mime,
                            dateModified = cursor.getLong(dateCol) * 1000
                        )
                    )
                }
            }
        }
        return result
    }

    private fun scanMusic(context: Context): List<TransferFile> {
        val result = mutableListOf<TransferFile>()
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_MODIFIED
        )
        val selection = "${MediaStore.Audio.Media.IS_RINGTONE} = 0 AND ${MediaStore.Audio.Media.IS_NOTIFICATION} = 0 AND ${MediaStore.Audio.Media.IS_ALARM} = 0"
        context.contentResolver.query(uri, projection, selection, null, "${MediaStore.Audio.Media.DATE_MODIFIED} DESC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)

            while (cursor.moveToNext()) {
                val path = cursor.getString(dataCol) ?: continue
                val lowerPath = path.lowercase()
                if (lowerPath.contains("/ringtones/") || lowerPath.contains("/ringtone/") ||
                    lowerPath.contains("/notifications/") || lowerPath.contains("/system/media/") ||
                    lowerPath.contains("/audiotrimmer/") || File(path).name.lowercase().startsWith("ringtone_")
                ) {
                    continue
                }
                val file = File(path)
                if (file.exists() && file.length() > 0) {
                    val ext = file.extension.lowercase()
                    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "audio/*"
                    result.add(
                        TransferFile(
                            id = cursor.getString(idCol),
                            name = cursor.getString(nameCol) ?: file.name,
                            size = cursor.getLong(sizeCol),
                            path = path,
                            type = "MUSIC",
                            mimeType = mime,
                            dateModified = cursor.getLong(dateCol) * 1000
                        )
                    )
                }
            }
        }
        return result
    }

    private fun scanDocuments(context: Context): List<TransferFile> {
        val result = mutableListOf<TransferFile>()
        val uri = MediaStore.Files.getContentUri("external")
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.DATA,
            MediaStore.Files.FileColumns.DATE_MODIFIED,
            MediaStore.Files.FileColumns.MIME_TYPE
        )

        val docExtensions = listOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "zip", "rar")
        val selectionMimeTypes = docExtensions.mapNotNull { 
            MimeTypeMap.getSingleton().getMimeTypeFromExtension(it)
        }

        val selection = selectionMimeTypes.joinToString(" OR ") { "${MediaStore.Files.FileColumns.MIME_TYPE} = ?" }
        val selectionArgs = selectionMimeTypes.toTypedArray()

        context.contentResolver.query(
            uri, 
            projection, 
            if (selection.isNotEmpty()) selection else null, 
            if (selectionArgs.isNotEmpty()) selectionArgs else null, 
            "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)

            while (cursor.moveToNext()) {
                val path = cursor.getString(dataCol) ?: continue
                val file = File(path)
                if (file.exists() && file.length() > 0) {
                    result.add(
                        TransferFile(
                            id = cursor.getString(idCol),
                            name = cursor.getString(nameCol) ?: file.name,
                            size = cursor.getLong(sizeCol),
                            path = path,
                            type = "DOCUMENT",
                            mimeType = cursor.getString(mimeCol),
                            dateModified = cursor.getLong(dateCol) * 1000
                        )
                    )
                }
            }
        }

        // If no items returned (some Android devices restrict Files database queries), let's scan Downloads folder directly as a robust fallback!
        if (result.isEmpty()) {
            val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
            downloadsDir.listFiles()?.forEach { file ->
                if (file.isFile && docExtensions.contains(file.extension.lowercase())) {
                    val ext = file.extension.lowercase()
                    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                    result.add(
                        TransferFile(
                            id = file.hashCode().toString(),
                            name = file.name,
                            size = file.length(),
                            path = file.absolutePath,
                            type = "DOCUMENT",
                            mimeType = mime,
                            dateModified = file.lastModified()
                        )
                    )
                }
            }
        }

        return result
    }

    private fun scanApks(context: Context): List<TransferFile> {
        val result = mutableListOf<TransferFile>()
        
        // 1. Get installed user apps (extremely useful!)
        val pm = context.packageManager
        try {
            val apps = pm.getInstalledPackages(0)
            for (pkg in apps) {
                val appInfo = pkg.applicationInfo ?: continue
                val isSystem = (appInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
                if (!isSystem) {
                    val file = File(appInfo.publicSourceDir)
                    if (file.exists()) {
                        val label = pm.getApplicationLabel(appInfo).toString()
                        result.add(
                            TransferFile(
                                id = pkg.packageName,
                                name = "$label.apk",
                                size = file.length(),
                                path = file.absolutePath,
                                type = "APK",
                                mimeType = "application/vnd.android.package-archive",
                                dateModified = file.lastModified()
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Error scanning installed packages")
        }

        // 2. Fallback or addition: scan files ending in .apk in standard Downloads folder
        val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
        downloadsDir.listFiles()?.forEach { file ->
            if (file.isFile && file.extension.lowercase() == "apk") {
                result.add(
                    TransferFile(
                        id = file.hashCode().toString(),
                        name = file.name,
                        size = file.length(),
                        path = file.absolutePath,
                        type = "APK",
                        mimeType = "application/vnd.android.package-archive",
                        dateModified = file.lastModified()
                    )
                )
            }
        }

        return result.distinctBy { it.path }
    }
}
