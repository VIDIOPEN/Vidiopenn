package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.database.AppDatabase
import com.example.data.repository.MediaRepository
import com.example.ui.components.*
import com.example.ui.components.Text
import com.example.ui.components.Icon
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.LocalIsLightTheme
import com.example.ui.viewmodel.MediaViewModel
import com.example.ui.viewmodel.MediaViewModelFactory
import com.example.ui.viewmodel.MediaStoreViewModel
import com.example.ui.viewmodel.MediaStoreViewModelFactory
import com.example.ui.viewmodel.SmartCollectionsViewModel
import com.example.ui.viewmodel.SmartCollectionsViewModelFactory
import com.example.ui.viewmodel.MusicViewModel
import com.example.ui.viewmodel.MusicViewModelFactory
import com.example.ui.viewmodel.WifiTransferViewModel
import com.example.ui.viewmodel.WifiTransferViewModelFactory

class MainActivity : androidx.fragment.app.FragmentActivity() {
    private lateinit var viewModel: MediaViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Use manual Dependency Injection via Application Container
        val appContainer = (application as VidiopenApplication).container
        val repository = appContainer.mediaRepository
        val factory = MediaViewModelFactory(application, repository)
        viewModel = ViewModelProvider(this, factory)[MediaViewModel::class.java]

        val mediaStoreRepository = appContainer.mediaStoreRepository
        val mediaStoreFactory = MediaStoreViewModelFactory(application, mediaStoreRepository)
        val mediaStoreViewModel = ViewModelProvider(this, mediaStoreFactory)[MediaStoreViewModel::class.java]

        val smartCollectionsFactory = SmartCollectionsViewModelFactory(application, repository)
        val smartCollectionsViewModel = ViewModelProvider(this, smartCollectionsFactory)[SmartCollectionsViewModel::class.java]

        val musicRepository = appContainer.musicRepository
        val musicPlayerManager = appContainer.musicPlayerManager
        val musicThemeRepository = appContainer.musicThemeRepository
        val musicFactory = MusicViewModelFactory(application, musicRepository, musicPlayerManager, musicThemeRepository)
        val musicViewModel = ViewModelProvider(this, musicFactory)[MusicViewModel::class.java]

        val wifiTransferRepository = appContainer.wifiTransferRepository
        val wifiTransferFactory = WifiTransferViewModelFactory(application, wifiTransferRepository)
        val wifiTransferViewModel = ViewModelProvider(this, wifiTransferFactory)[WifiTransferViewModel::class.java]

        setContent {
            val selectedThemeId by viewModel.selectedThemeId.collectAsState()
            val musicCustomThemeUri by musicViewModel.customThemeImageUri.collectAsState()
            val musicThemeState by musicViewModel.currentTheme.collectAsState()
            val customBackgroundUri by viewModel.customBackgroundUri.collectAsState()

            val effectiveCustomBackgroundUri = if (customBackgroundUri.isNotEmpty()) customBackgroundUri else (musicCustomThemeUri ?: "")
            val effectiveThemeId = if (selectedThemeId == "custom_image" || musicThemeState.id == "custom_image" || effectiveCustomBackgroundUri.isNotEmpty()) {
                "custom_image"
            } else {
                selectedThemeId
            }

            MyApplicationTheme(isLightTheme = effectiveThemeId == "light_color") {
                VidiopenAppFrame(
                    viewModel = viewModel,
                    mediaStoreViewModel = mediaStoreViewModel,
                    smartCollectionsViewModel = smartCollectionsViewModel,
                    musicViewModel = musicViewModel,
                    wifiTransferViewModel = wifiTransferViewModel
                )
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (::viewModel.isInitialized) {
            val isPlayingVideo = viewModel.currentPlayingMedia.value != null && 
                                 viewModel.currentPlayingMedia.value?.category != "Music"
            val autoEnter = viewModel.autoEnterPip.value
            if (isPlayingVideo && autoEnter) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    val params = android.app.PictureInPictureParams.Builder().build()
                    enterPictureInPictureMode(params)
                }
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (::viewModel.isInitialized) {
            viewModel.setIsInPictureInPictureMode(isInPictureInPictureMode)
        }
    }
}

sealed class Screen(val route: String, val title: String, val activeIcon: ImageVector, val inactiveIcon: ImageVector) {
    object Home : Screen("home", "Home", Icons.Filled.Home, Icons.Outlined.Home)
    object Videos : Screen("videos", "VIDEO", Icons.Filled.Movie, Icons.Outlined.Movie)
    object Music : Screen("music", "MUSIC", Icons.Filled.MusicNote, Icons.Outlined.MusicNote)
    object Files : Screen("files", "Files", Icons.Filled.Folder, Icons.Outlined.Folder)
    object Settings : Screen("settings", "Me", Icons.Filled.Person, Icons.Outlined.Person)
    object Vault : Screen("vault", "Privacy", Icons.Filled.Lock, Icons.Outlined.Lock) // Separate route
}

@Composable
fun VidiopenAppFrame(
    viewModel: MediaViewModel,
    mediaStoreViewModel: MediaStoreViewModel,
    smartCollectionsViewModel: com.example.ui.viewmodel.SmartCollectionsViewModel,
    musicViewModel: MusicViewModel,
    wifiTransferViewModel: WifiTransferViewModel
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val context = androidx.compose.ui.platform.LocalContext.current

    val currentPlayingMedia by viewModel.currentPlayingMedia.collectAsState()
    val appLanguage by viewModel.appLanguage.collectAsState()
    val customBackgroundUri by viewModel.customBackgroundUri.collectAsState()
    val selectedThemeId by viewModel.selectedThemeId.collectAsState()
    val offlineCurrentPlayingSong by musicViewModel.currentPlayingSong.collectAsState()
    var isMusicPlaying by remember { mutableStateOf(false) }
    var isMusicExpanded by remember { mutableStateOf(false) }
    var showSplash by remember { mutableStateOf(true) }
    var showRingtonePermissionDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("app_settings_ringtone", android.content.Context.MODE_PRIVATE)
        val hasPrompted = prefs.getBoolean("ringtone_perm_prompted", false)
        if (!hasPrompted) {
            prefs.edit().putBoolean("ringtone_perm_prompted", true).apply()
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && !android.provider.Settings.System.canWrite(context)) {
                showRingtonePermissionDialog = true
            }
        }
    }

    val isVideoPlaying = currentPlayingMedia != null && currentPlayingMedia?.category != "Music"
    val isFloatingMode by viewModel.isFloatingMode.collectAsState()

    androidx.activity.compose.BackHandler(enabled = isMusicExpanded) {
        isMusicExpanded = false
    }

    androidx.activity.compose.BackHandler(enabled = isVideoPlaying && !isFloatingMode) {
        val activeMedia = currentPlayingMedia
        if (activeMedia != null) {
            val lastPos = try {
                viewModel.getOrCreatePlayer(context).currentPosition
            } catch (e: Exception) {
                0L
            }
            viewModel.updatePlaybackPosition(activeMedia.id, lastPos)
            viewModel.closePlayer()
        }
    }

    val scannedVideos by mediaStoreViewModel.scannedVideos.collectAsState()
    LaunchedEffect(scannedVideos) {
        smartCollectionsViewModel.updateScannedVideos(scannedVideos)
    }

    if (showRingtonePermissionDialog) {
        AlertDialog(
            onDismissRequest = { showRingtonePermissionDialog = false },
            title = {
                Text(
                    if (appLanguage == "hi") "रिंगटोन अनुमति (Ringtone Permission)" else "Ringtone & System Permission",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    if (appLanguage == "hi") 
                        "किसी भी गाने को अपनी फ़ोन रिंगटोन पर सेट करने या क्रॉप करने के लिए सिस्टम अनुमतियों की आवश्यकता है। क्या आप अभी अनुमति देना चाहते हैं?" 
                    else 
                        "To set any song or cut audio clip as your phone ringtone, 'Write System Settings' permission is required. Would you like to grant it now?",
                    color = Color.LightGray
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showRingtonePermissionDialog = false
                        try {
                            val intent = android.content.Intent(android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                                data = android.net.Uri.parse("package:${context.packageName}")
                                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (_: Exception) {}
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8A2BE2))
                ) {
                    Text(if (appLanguage == "hi") "अनुमति दें (Allow)" else "Allow Permission", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRingtonePermissionDialog = false }) {
                    Text(if (appLanguage == "hi") "बाद में" else "Later", color = Color.Gray)
                }
            },
            containerColor = if (LocalIsLightTheme.current) Color.White else Color(0xFF1E1E2C)
        )
    }

    // Navigation items
    val navigationItems = listOf(
        Screen.Videos,
        Screen.Music,
        Screen.Settings
    )

    val musicCustomThemeUri by musicViewModel.customThemeImageUri.collectAsState()
    val musicThemeState by musicViewModel.currentTheme.collectAsState()

    val customThemeScaleType by viewModel.customThemeScaleType.collectAsState()
    val customThemeZoom by viewModel.customThemeZoom.collectAsState()
    val customThemeOpacity by viewModel.customThemeOpacity.collectAsState()
    val customThemeAlignment by viewModel.customThemeAlignment.collectAsState()

    val effectiveCustomBackgroundUri = if (customBackgroundUri.isNotEmpty()) {
        customBackgroundUri
    } else {
        musicCustomThemeUri ?: ""
    }

    val effectiveThemeId = if (selectedThemeId == "custom_image" || musicThemeState.id == "custom_image" || effectiveCustomBackgroundUri.isNotEmpty()) {
        "custom_image"
    } else {
        selectedThemeId
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (!showSplash) {
            AppThemeBackground(
                selectedThemeId = effectiveThemeId,
                customBackgroundUri = effectiveCustomBackgroundUri,
                scaleType = customThemeScaleType,
                zoomScale = customThemeZoom,
                overlayOpacity = customThemeOpacity,
                alignment = customThemeAlignment
            )
        }
        if (showSplash) {
            SplashAnimationScreen(
                appLanguage = appLanguage,
                onFinished = { showSplash = false }
            )
        } else {
            Scaffold(
            bottomBar = {
                // Only show bottom navigation if a full screen video player is NOT open
                val isMusicTrackPlaying = offlineCurrentPlayingSong != null
                val isVideoPlaying = currentPlayingMedia != null && currentPlayingMedia?.category != "Music"
                val isHideBottomBarRoute = currentRoute == "vault" || currentRoute == "wifi_transfer"

                if (!isVideoPlaying && !isHideBottomBarRoute) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                    ) {
                        // Persistently present mini player if a music track is active and not expanded
                        if (isMusicTrackPlaying && !isMusicExpanded) {
                            MusicMiniPlayer(
                                musicViewModel = musicViewModel,
                                onExpand = { isMusicExpanded = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 8.dp)
                            )
                        }

                        // Glassmorphic navigation bar
                        val isLightNav = LocalIsLightTheme.current
                        NavigationBar(
                            containerColor = if (isLightNav) Color.White.copy(alpha = 0.95f) else Color.Black.copy(alpha = 0.85f),
                            tonalElevation = 8.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(64.dp)
                                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                                .testTag("bottom_nav_bar")
                        ) {
                            navigationItems.forEach { screen ->
                                val selected = currentRoute == screen.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = {
                                        navController.navigate(screen.route) {
                                            popUpTo(navController.graph.findStartDestination().id) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) screen.activeIcon else screen.inactiveIcon,
                                            contentDescription = screen.title,
                                            tint = if (selected) (if (isLightNav) Color.Black else Color(0xFF10B981)) else (if (isLightNav) Color.DarkGray else Color.Gray)
                                        )
                                    },
                                    label = {
                                        val translatedLabel = when (screen.title) {
                                            "VIDEO" -> if (appLanguage == "hi") "वीडियो" else "VIDEO"
                                            "MUSIC" -> if (appLanguage == "hi") "संगीत" else "MUSIC"
                                            "ME", "Me" -> if (appLanguage == "hi") "मैं" else "Me"
                                            else -> screen.title
                                        }
                                        Text(
                                            text = translatedLabel,
                                            color = if (selected) (if (isLightNav) Color.Black else Color(0xFF10B981)) else (if (isLightNav) Color.DarkGray else Color.Gray),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        indicatorColor = if (isLightNav) Color.Black.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.1f)
                                    ),
                                    modifier = Modifier.testTag("nav_item_${screen.route}")
                                )
                            }
                        }
                    }
                }
            },
            containerColor = Color.Transparent
        ) { innerPadding ->
            // Sub-screen navigations
            NavHost(
                navController = navController,
                startDestination = Screen.Videos.route,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = if (currentPlayingMedia != null || currentRoute == "vault" || currentRoute == "wifi_transfer") 0.dp else innerPadding.calculateBottomPadding())
            ) {
                composable(Screen.Home.route) {
                    HomeScreen(
                        viewModel = viewModel,
                        smartCollectionsViewModel = smartCollectionsViewModel,
                        onNavigateToSection = { category ->
                            if (category.startsWith("collection/")) {
                                navController.navigate(category)
                            } else if (category == "movies" || category == "tvshows") {
                                navController.navigate("videos/$category")
                            } else {
                                navController.navigate(category)
                            }
                        },
                        onPlayVideo = { video -> viewModel.playMedia(video) },
                        onOpenVault = { navController.navigate("vault") },
                        onAddCustomVideo = { viewModel.addLocalVideo("Cinema", "", 120000) }
                    )
                }

                composable("collection/{collectionId}") { backStackEntry ->
                    val collectionId = backStackEntry.arguments?.getString("collectionId") ?: ""
                    CollectionDetailScreen(
                        collectionId = collectionId,
                        viewModel = viewModel,
                        smartCollectionsViewModel = smartCollectionsViewModel,
                        onBack = { navController.popBackStack() },
                        onPlayVideo = { video -> viewModel.playMedia(video) }
                    )
                }

                composable("videos") {
                    VideosScreen(
                        viewModel = viewModel,
                        mediaStoreViewModel = mediaStoreViewModel,
                        initialCategory = "movies",
                        smartCollectionsViewModel = smartCollectionsViewModel,
                        onNavigateToSection = { category -> navController.navigate(category) }
                    ) { video ->
                        viewModel.playMedia(video)
                    }
                }

                composable("videos/{category}") { backStackEntry ->
                    val category = backStackEntry.arguments?.getString("category") ?: "movies"
                    VideosScreen(
                        viewModel = viewModel,
                        mediaStoreViewModel = mediaStoreViewModel,
                        initialCategory = category,
                        smartCollectionsViewModel = smartCollectionsViewModel,
                        onNavigateToSection = { cat -> navController.navigate(cat) }
                    ) { video ->
                        viewModel.playMedia(video)
                    }
                }

                composable(Screen.Music.route) {
                    MusicScreen(
                        viewModel = viewModel,
                        musicViewModel = musicViewModel
                    ) { track ->
                        viewModel.playMedia(track)
                        isMusicPlaying = true
                    }
                }

                composable(Screen.Files.route) {
                    FilesScreen(
                        viewModel = viewModel,
                        mediaStoreViewModel = mediaStoreViewModel
                    )
                }

                composable(Screen.Settings.route) {
                    SettingsScreen(
                        viewModel = viewModel,
                        musicViewModel = musicViewModel,
                        onNavigateToSection = { route -> navController.navigate(route) },
                        onOpenVault = { navController.navigate("vault") }
                    )
                }

                composable("vault") {
                    PrivateVaultScreen(
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable("wifi_transfer") {
                    WifiTransferScreen(
                        wifiTransferViewModel = wifiTransferViewModel,
                        mediaViewModel = viewModel,
                        musicViewModel = musicViewModel,
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }

        // Expanded full-screen Music Player Layer
        val isMusicTrackActive = offlineCurrentPlayingSong != null
        AnimatedVisibility(
            visible = isMusicTrackActive && isMusicExpanded,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            MusicExpandedPlayer(
                musicViewModel = musicViewModel,
                mediaViewModel = viewModel,
                onCollapse = { isMusicExpanded = false }
            )
        }

        // Full Screen Video Player Layer
        val isVideoPlaying = currentPlayingMedia != null && currentPlayingMedia?.category != "Music"
        val isFloatingMode by viewModel.isFloatingMode.collectAsState()

        AnimatedVisibility(
            visible = isVideoPlaying && !isFloatingMode,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            val activeMedia = currentPlayingMedia
            if (activeMedia != null) {
                VideoPlayerView(
                    media = activeMedia,
                    viewModel = viewModel,
                    onClose = { lastPos ->
                        viewModel.updatePlaybackPosition(activeMedia.id, lastPos)
                        viewModel.closePlayer()
                    },
                    onAudioConverted = {
                        musicViewModel.scanMusicFiles()
                    },
                    onNavigateToMusic = {
                        navController.navigate(Screen.Music.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    musicViewModel = musicViewModel
                )
            }
        }

        // Floating Window Video Player Layer
        val activeFloatingMedia = currentPlayingMedia
        if (isFloatingMode && isVideoPlaying && activeFloatingMedia != null) {
            FloatingVideoPlayer(
                media = activeFloatingMedia,
                viewModel = viewModel,
                onClose = {
                    viewModel.closePlayer()
                },
                onReturnToFull = {
                    viewModel.setFloatingMode(false)
                }
            )
        }

        // First launch language selection overlay
        if (appLanguage.isEmpty()) {
            com.example.ui.components.LanguageSelectionOverlay(
                onLanguageSelected = { lang ->
                    viewModel.setAppLanguage(lang)
                }
            )
        }
        }
    }
}

@Composable
fun AppThemeBackground(
    selectedThemeId: String,
    customBackgroundUri: String,
    scaleType: String = "CROP",
    zoomScale: Float = 1.0f,
    overlayOpacity: Float = 0.55f,
    alignment: String = "CENTER"
) {
    Box(modifier = Modifier.fillMaxSize()) {
        when (selectedThemeId) {
            "light_color" -> {
                // Light color vibrant abstract gradient theme
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFFF1F5F9),
                                    Color(0xFFF8FAFC),
                                    Color(0xFFEFF6FF)
                                )
                            )
                        )
                ) {
                    // Soft vibrant ambient wave glows
                    androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                        drawCircle(
                            color = Color(0xFF38BDF8).copy(alpha = 0.15f),
                            radius = size.width * 0.7f,
                            center = androidx.compose.ui.geometry.Offset(size.width * 0.9f, size.height * 0.15f)
                        )
                        drawCircle(
                            color = Color(0xFFA855F7).copy(alpha = 0.12f),
                            radius = size.width * 0.8f,
                            center = androidx.compose.ui.geometry.Offset(-size.width * 0.1f, size.height * 0.5f)
                        )
                        drawCircle(
                            color = Color(0xFF10B981).copy(alpha = 0.14f),
                            radius = size.width * 0.7f,
                            center = androidx.compose.ui.geometry.Offset(size.width * 0.8f, size.height * 0.85f)
                        )
                    }
                }
            }
            "custom_image" -> {
                if (customBackgroundUri.isNotEmpty()) {
                    val fileModel = remember(customBackgroundUri) {
                        if (customBackgroundUri.startsWith("file://")) {
                            val path = android.net.Uri.parse(customBackgroundUri).path
                            if (path != null) java.io.File(path) else customBackgroundUri
                        } else if (customBackgroundUri.startsWith("/")) {
                            java.io.File(customBackgroundUri)
                        } else {
                            customBackgroundUri
                        }
                    }

                    val contentScale = when (scaleType) {
                        "FIT" -> androidx.compose.ui.layout.ContentScale.Fit
                        "FILL_BOUNDS" -> androidx.compose.ui.layout.ContentScale.FillBounds
                        "INSIDE" -> androidx.compose.ui.layout.ContentScale.Inside
                        else -> androidx.compose.ui.layout.ContentScale.Crop
                    }

                    val contentAlignment = when (alignment) {
                        "TOP" -> androidx.compose.ui.Alignment.TopCenter
                        "BOTTOM" -> androidx.compose.ui.Alignment.BottomCenter
                        else -> androidx.compose.ui.Alignment.Center
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black),
                        contentAlignment = androidx.compose.ui.Alignment.Center
                    ) {
                        coil.compose.AsyncImage(
                            model = fileModel,
                            contentDescription = "Custom theme background",
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer(
                                    scaleX = zoomScale.coerceIn(0.5f, 3.0f),
                                    scaleY = zoomScale.coerceIn(0.5f, 3.0f)
                                ),
                            contentScale = contentScale,
                            alignment = contentAlignment
                        )

                        // High contrast vertical gradient scrim & opacity overlay
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = overlayOpacity.coerceIn(0.05f, 0.95f)))
                        )
                    }
                } else {
                    // Fallback to dark_color
                    DarkStarryBackground()
                }
            }
            else -> { // "dark_color" or default
                DarkStarryBackground()
            }
        }
    }
}

@Composable
fun DarkStarryBackground() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F172A),
                        Color(0xFF0D0E15),
                        Color(0xFF050508)
                    )
                )
            )
    ) {
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            // Vibrant cosmic aurora ambient radial glows
            drawCircle(
                color = Color(0xFF00D9FF).copy(alpha = 0.12f),
                radius = size.width * 0.75f,
                center = androidx.compose.ui.geometry.Offset(size.width * 0.85f, size.height * 0.12f)
            )
            drawCircle(
                color = Color(0xFF7C4DFF).copy(alpha = 0.14f),
                radius = size.width * 0.85f,
                center = androidx.compose.ui.geometry.Offset(-size.width * 0.1f, size.height * 0.45f)
            )
            drawCircle(
                color = Color(0xFFFF2E93).copy(alpha = 0.08f),
                radius = size.width * 0.6f,
                center = androidx.compose.ui.geometry.Offset(size.width * 0.5f, size.height * 0.25f)
            )
            drawCircle(
                color = Color(0xFF10B981).copy(alpha = 0.18f),
                radius = size.width * 0.7f,
                center = androidx.compose.ui.geometry.Offset(size.width * 0.6f, size.height * 1.05f)
            )
            drawCircle(
                color = Color(0xFF047857).copy(alpha = 0.25f),
                radius = size.width * 0.45f,
                center = androidx.compose.ui.geometry.Offset(size.width * 0.6f, size.height * 1.05f)
            )

            // Draw stars
            val starPositions = listOf(
                androidx.compose.ui.geometry.Offset(size.width * 0.15f, size.height * 0.08f),
                androidx.compose.ui.geometry.Offset(size.width * 0.35f, size.height * 0.12f),
                androidx.compose.ui.geometry.Offset(size.width * 0.72f, size.height * 0.05f),
                androidx.compose.ui.geometry.Offset(size.width * 0.85f, size.height * 0.18f),
                androidx.compose.ui.geometry.Offset(size.width * 0.5f, size.height * 0.15f),
                androidx.compose.ui.geometry.Offset(size.width * 0.25f, size.height * 0.22f),
                androidx.compose.ui.geometry.Offset(size.width * 0.62f, size.height * 0.28f),
                androidx.compose.ui.geometry.Offset(size.width * 0.9f, size.height * 0.35f),
                androidx.compose.ui.geometry.Offset(size.width * 0.1f, size.height * 0.4f),
                androidx.compose.ui.geometry.Offset(size.width * 0.45f, size.height * 0.04f)
            )
            starPositions.forEachIndexed { i, pos ->
                val radius = if (i % 3 == 0) 3.5f else 2f
                val alpha = if (i % 2 == 0) 0.85f else 0.5f
                drawCircle(
                    color = Color.White.copy(alpha = alpha),
                    radius = radius,
                    center = pos
                )
            }
            
            // Draw a bright sparkling star (diamond shape)
            val centerStarX = size.width * 0.55f
            val centerStarY = size.height * 0.1f
            val path = androidx.compose.ui.graphics.Path().apply {
                moveTo(centerStarX, centerStarY - 10f)
                lineTo(centerStarX + 4f, centerStarY - 2f)
                lineTo(centerStarX + 10f, centerStarY)
                lineTo(centerStarX + 4f, centerStarY + 2f)
                lineTo(centerStarX, centerStarY + 10f)
                lineTo(centerStarX - 4f, centerStarY + 2f)
                lineTo(centerStarX - 10f, centerStarY)
                lineTo(centerStarX - 4f, centerStarY - 2f)
                close()
            }
            drawPath(path, Color.White.copy(alpha = 0.95f))

            drawCircle(
                color = Color.White.copy(alpha = 0.15f),
                radius = 18f,
                center = androidx.compose.ui.geometry.Offset(centerStarX, centerStarY)
            )
        }
    }
}
